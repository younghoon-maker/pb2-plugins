# DANA&PETA Page Builder

Automated product detail page generator for DANA&PETA brand.

**Pipeline**: Google Sheets (96 columns) → Product Data (JSON) → HTML Pages (Original + Editable)

---

## Features

✨ **DANA&PETA Brand Template** - Custom-designed template matching Figma specifications

🎨 **Smart Color Extraction** - V13 algorithm with K-means clustering for accurate color detection

📐 **96-Column Google Sheets** - Comprehensive data structure supporting:
- 4 colors per product (with 2x2 grid layout)
- 4 detail points with images
- 8 gallery images
- 4 product shots
- Fabric info with 5 properties table
- Complete size information (top/bottom)
- 2 model information entries

🖼️ **Dual Output Modes**:
- **원본 (Original)**: Static HTML with Base64-embedded images
- **에디터블 (Editable)**: Interactive HTML with image crop controls + text editing

📱 **Responsive Design** - Mobile-first approach with clean, modern UI

🚀 **Automated Workflow** - One command to go from Google Sheets to deployed pages

---

## Quick Start

### 1. Prerequisites

```bash
# Python 3.7+
python3 --version

# Install dependencies
pip3 install google-auth google-auth-oauthlib google-auth-httplib2 google-api-python-client Pillow numpy
```

### 2. Setup Credentials

1. Download Service Account JSON from Google Cloud Console
2. Save to `credentials/service-account.json`
3. Share your Google Sheet with the Service Account email
4. Share your Google Drive folder with the Service Account email

### 3. Configure

Edit `scripts/config.py`:

```python
SHEET_ID = "your_google_sheet_id_here"
SHEET_NAME = "dana_products"
SHEET_RANGE = "A2:CR100"  # 96 columns
```

### 4. Validate Environment

```bash
cd /Users/younghoonjung/ai-project/pb_dana_page_builder

# Run validation
python3 -c "
import sys
sys.path.insert(0, 'scripts')
from config import SHEET_ID, BRAND_NAME
print(f'✅ Config loaded')
print(f'   Brand: {BRAND_NAME}')
print(f'   Sheet ID: {SHEET_ID}')
"
```

Or use the slash command:
```bash
/dana-validate
```

### 5. Load Data from Google Sheets

```bash
python3 scripts/load_from_sheets.py
```

Or use the slash command:
```bash
/dana-load-sheets
```

**Expected output**:
```
✅ Successfully loaded 3 products
✅ 40개 이미지 다운로드 완료
✅ Extracted dominant color from DN25FW001_color_1.jpg: #d4c5b8
✅ Products data saved: data/products.json
```

### 6. Generate HTML Pages

```bash
python3 scripts/generate_pages_dana.py
python3 scripts/generate_index.py
```

Or use the complete build command:
```bash
/dana-build-all
```

**Expected output**:
```
✅ Build pipeline completed!

📂 Generated files:
   - 원본 HTML: output/2025-10-13/원본/
   - 에디터블 HTML: output/2025-10-13/에디터블/
   - Index page: output/index.html
```

### 7. Preview Pages

```bash
python3 -m http.server 8000

# Open browser:
# http://localhost:8000/output/index.html
# http://localhost:8000/output/2025-10-13/에디터블/DN25FW001_editable.html
```

### 8. Export Edited Pages (HTML & JPG)

```bash
python3 scripts/server.py  # Runs on http://localhost:5001
```

1. 브라우저에서 `http://localhost:5001` 접속 → 에디터블 파일 선택  
2. 크롭/텍스트를 수정한 뒤 **HTML 저장** 또는 **JPG 저장** 버튼 클릭  
3. 결과 파일은 `output/YYYY-MM-DD/익스포트/`에 자동 저장

> **Note**  
> 2025-10-15 버전부터는 캔버스 플래튼 파이프라인을 적용해 히어로·디테일 포인트·패브릭·로고 그룹 이미지가 HTML과 동일한 비율로 내보내집니다. (html2canvas의 `object-fit`/transform 해석 이슈 해결)

---

## Project Structure

```
pb_dana_page_builder/
├── .claude/
│   └── commands/          # Slash commands
│       ├── dana-validate.md
│       ├── dana-load-sheets.md
│       └── dana-build-all.md
├── credentials/
│   └── service-account.json  # Google API credentials (create this)
├── data/
│   ├── templates/
│   │   └── dana_product_template.json
│   └── products.json      # Generated product data
├── docs/
│   └── DANA_SHEET_TEMPLATE.md  # 96-column sheet documentation
├── output/
│   ├── YYYY-MM-DD/
│   │   ├── 원본/          # Original HTML pages
│   │   └── 에디터블/      # Editable HTML pages
│   ├── assets/
│   │   └── images/        # Downloaded product images
│   └── index.html         # Product index page
├── scripts/
│   ├── config.py          # Configuration
│   ├── load_from_sheets.py    # Data loader
│   ├── generate_pages_dana.py # HTML generator
│   └── generate_index.py      # Index generator
└── README.md              # This file
```

---

## DANA&PETA Template Sections

The generated HTML pages include 10 distinct sections:

1. **Hero Section**
   - Brand logo (queenit made)
   - Product title
   - 3 selling points (numbered 01, 02, 03)
   - Main product image (with crop adjustment in editable mode)
   - 2×2 color grid (4 colors)

2. **DETAIL POINT**
   - 4 detail point images
   - Descriptions for each point
   - 2×2 grid layout

3. **Gallery**
   - 8 product images
   - 2-column grid layout

4. **PRODUCT SHOT**
   - 4 product shot images
   - 2×2 grid layout
   - Notice text below

5. **FABRIC INFO**
   - Fabric close-up image
   - Fabric name and description
   - Composition details
   - Properties table (5 rows)

6. **PRODUCT INFO**
   - 6 care instruction items
   - Bulleted list format

7. **SIZE INFO**
   - Size tables (top/bottom)
   - 8 measurements each

8. **MODEL INFO**
   - 2 model entries
   - Height, size, and color info

9. **SIZE RECOMMENDATION**
   - Sizing guidance text

10. **Footer**
    - Brand information
    - Version info

---

## Slash Commands

### /dana-validate
Validate system environment and dependencies.

Checks:
- Python 3.7+
- Required packages
- Service Account credentials
- Google Sheets access
- Directory structure
- 96-column configuration

### /dana-load-sheets
Load product data from Google Sheets (96 columns).

Features:
- Authenticate with Google APIs
- Download images from Google Drive
- Extract colors using V13 algorithm (K-means clustering)
- Generate `data/products.json`

Options:
- `--verify`: Verify data after load

### /dana-build-all
Complete build pipeline orchestration.

Steps:
1. Validate environment
2. Load data from Google Sheets
3. Generate 원본 HTML pages
4. Generate 에디터블 HTML pages
5. Generate index page

Options:
- `--skip-load`: Use existing `data/products.json`
- `--product [CODE]`: Build specific product only
- `--skip-index`: Skip index generation

---

## Color Extraction (V13 Algorithm)

DANA&PETA uses the proven V13 color extraction algorithm from pb_figma_exp:

**Process**:
1. **Center crop** (30%) - Focus on product, remove background
2. **Brightness filter** (< 240) - Remove white/gray background pixels
3. **K-means clustering** (k=3) - Group similar colors
4. **Select dominant cluster** - Choose cluster with most pixels
5. **Return HEX code** - Convert RGB to #RRGGBB

**Why it works**:
- Avoids extracting background color (#f8f8f8 bug)
- Focuses on actual product color in center
- Handles shadows, highlights, variations
- Returns most representative color

**Example**:
```
Input: DN25FW001_color_1.jpg (knit on white background)
Output: #d4c5b8 (accurate beige color, not #f8f8f8)
```

---

## Editable Mode Features

The 에디터블 (Editable) HTML pages include:

### 1. Image Crop Controls

**Control Panel** (fixed top-right):
- **Pan X**: Horizontal position (-50 to +50)
- **Pan Y**: Vertical position (-50 to +50)
- **Zoom**: Zoom level (100% to 500%)

Real-time preview of adjustments on main product image.

### 2. Text Editing

All text elements are `contenteditable`:
- Product title
- Selling points
- Detail point descriptions
- Fabric information
- Size tables
- Model info
- Notices

Simply click any text to edit directly in browser.

### 3. Export Function

**Export Button** (fixed bottom-right):
- Removes control panel
- Removes contenteditable attributes
- Generates clean HTML file
- Downloads as `{productCode}_exported.html`

---

## Google Sheets Structure

DANA&PETA uses **96 columns** (A~CR):

### Column Breakdown

| Range | Category | Count | Description |
|-------|----------|-------|-------------|
| A~C | Basic Info | 3 | Product code, title, tagline |
| D~F | Selling Points | 3 | Three selling points |
| G | Main Image | 1 | Main product image |
| H~K | Color Images | 4 | Four color variant images |
| L~AA | Color Info | 16 | 4 colors × 4 fields (name, hex, image, desc) |
| AB~AI | Detail Points | 8 | 4 points × 2 fields (image, text) |
| AJ~AQ | Gallery | 8 | Eight gallery images |
| AR~AU | Product Shots | 4 | Four product shot images |
| AV~BA | Fabric Info | 6 | Image, name, desc, composition + reserved |
| BB~BF | Fabric Properties | 5 | Transparency, stretch, lining, thickness, season |
| BG~BL | Product Info | 6 | Six care instruction lines |
| BM~BT | Top Size | 8 | Eight size measurements |
| BU~CB | Bottom Size | 8 | Eight size measurements |
| CC~CF | Model Info | 4 | 2 models × 2 fields (info, color) |
| CG~CH | Shot Notice | 2 | Two notice lines |
| CI | Size Recommendation | 1 | Sizing guidance |
| CJ~CR | Reserved | 11 | Future expansion |

**Total**: 96 columns (85 used, 11 reserved)

See `docs/DANA_SHEET_TEMPLATE.md` for detailed field descriptions.

---

## Key Differences from pb_figma_exp

| Feature | pb_figma_exp | DANA&PETA | Notes |
|---------|--------------|-----------|-------|
| **Columns** | 227 (A~HO) | 96 (A~CR) | Simplified structure |
| **Colors** | 3 | 4 | 2×2 grid layout |
| **Detail Points** | 3 | 4 | 2×2 grid layout |
| **Gallery** | Variable | 8 | Fixed count |
| **Product Shots** | Variable | 4 | Fixed count |
| **Fabric Properties** | N/A | 5-row table | New feature |
| **Brand** | Generic | DANA&PETA | Custom template |
| **Sections** | 7 | 10 | More comprehensive |
| **Color Extraction** | V13 | V13 | Same algorithm |

---

## Configuration

### scripts/config.py

Key settings:

```python
# Google Sheets
SHEET_ID = "YOUR_SHEET_ID_HERE"
SHEET_NAME = "dana_products"
SHEET_RANGE = "A2:CR100"

# Brand
BRAND_NAME = "DANA&PETA"
BRAND_LOGO_TEXT = "queenit made"

# Color Extraction
COLOR_EXTRACTION_CROP_PERCENT = 0.3
COLOR_EXTRACTION_BRIGHTNESS_THRESHOLD = 240
COLOR_EXTRACTION_KMEANS_CLUSTERS = 3
```

---

## Troubleshooting

### Service Account Error

**Error**: `❌ Service Account file not found`

**Fix**:
```bash
# Download from Google Cloud Console
# Save to credentials/service-account.json
ls credentials/service-account.json
```

### Google Sheets Access Denied

**Error**: `❌ Authentication failed: 403 Forbidden`

**Fix**:
1. Open Google Sheet in browser
2. Click "Share"
3. Add Service Account email (from `credentials/service-account.json` → `client_email`)
4. Grant "Viewer" permissions

### Background Color Extracted

**Error**: Colors show `#f8f8f8` instead of product colors

**Fix**: V13 algorithm should handle this automatically. Verify:
- Images have product in center
- Product is not pure white (#ffffff)
- Image has sufficient color variation

### Missing Sections

**Error**: Not all 10 sections rendered

**Fix**: Check `data/products.json` has all required fields:
- colors (array with 4 items)
- detailPoints (array with 4 items)
- gallery (array with 8 items)
- productShots (array with 4 items)
- fabricInfo (object with properties)

---

## Performance

**Typical execution time** (3 products):
- Data load: ~15 seconds (includes image download)
- HTML generation: ~5 seconds
- **Total**: ~20 seconds

**Bottlenecks**:
- Image download from Google Drive
- Color extraction (K-means clustering)

**Optimization**:
- Images cached (skip re-download)
- K-means limited to 10 iterations

---

## License

Private project for DANA&PETA brand.

© 2025 All Rights Reserved

---

## Support

For issues or questions:

1. Check `/dana-validate` for environment issues
2. Review `dana_page_generation.log` for errors
3. Consult `docs/DANA_SHEET_TEMPLATE.md` for data structure
4. Verify Google Sheets permissions

---

## Version

**v1.0.0** - Initial release

**Built with**:
- Python 3.7+
- Google Sheets API
- Google Drive API
- Pillow (image processing)
- NumPy (K-means clustering)

**Based on**: pb_figma_exp V13 architecture
