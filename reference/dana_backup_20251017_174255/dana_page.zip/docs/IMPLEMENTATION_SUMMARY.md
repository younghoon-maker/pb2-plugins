# DANA&PETA Page Builder - Implementation Summary (2025-10-15)

## 1. Project Snapshot
- **Scope**: Google Sheets → Product assets → HTML (Original & Editable) → Export (HTML/JPG)
- **Latest Release**: 2025-10-15 `pb_dana_page_builder_export_image_flatten_fix`
- **Core Achievement**: Unified 302-column template + canvas 플래튼 기반 익스포트 파이프라인

## 2. Milestone Timeline
| 날짜 | Phase | 주요 내용 |
|------|-------|-----------|
| 2025-02 ~ 2025-08 | Phase 0-2 | 기존 96컬럼 구조 분석, 하이브리드 시트 프로토타입, 에디터 UI 구축 |
| 2025-09-10 | Phase 3 | 에디터블 모드 리뉴얼 (컨트롤 패널, 로컬스토리지 자동 저장) |
| 2025-10-13 | Phase 4 | 다중 상품 배치 생성, 출력 폴더 구조 표준화 |
| 2025-10-14 | Phase 5 | Flask 로컬 서버로 Export (HTML/JPG) 저장 자동화 |
| **2025-10-15** | **Phase 6** | Unified Template (302컬럼) 도입 + 캔버스 플래튼 파이프라인으로 JPG 왜곡 해소 |

## 3. Current Pipeline
1. **데이터 로딩**  
   `python3 scripts/load_from_sheets.py`  
   - Google Service Account 인증  
   - 템플릿 탭(`템플릿!A2:KP100`)에서 Hyperlink 추출  
   - 이미지 다운로드 + V13 색상 추출  
   - `data/products.json` 생성

2. **페이지 생성**  
   `python3 scripts/generate_pages_dana.py`  
   - Original / Editable HTML 렌더링  
   - 에디터 스크립트에 로컬스토리지·이미지 크롭 기능 포함  
   - 캔버스 플래튼 헬퍼 (`loadImage`, `generateFlattenedImageData`, `createFlattenedImageMap`)

3. **인덱스 생성**  
   `python3 scripts/generate_index.py` → `output/index.html`

4. **익스포트 서버**  
   `python3 scripts/server.py` (Port 5001)  
   - `/` : 에디터블 파일 목록  
   - `/editable/<product>` : HTML 서빙  
   - `/save-html`, `/save-jpg` : 플래튼 버전 Export 저장

## 4. Unified Template (302 Columns)
- 단일 **"템플릿"** 탭에서 모든 데이터를 관리  
- 주요 그룹 (A~KP):
  1. **기본 정보** (A~F): 상품코드, 제목, 셀링포인트, MD 코멘트  
  2. **메인 이미지** (G)  
  3. **색상 이름/HEX** (H~O) 1~4컬러  
  4. **디테일 포인트** (P~W) 4세트  
  5. **컬러별 갤러리** (X~AO) 8컬러 × 12컷  
  6. **컬러별 제품샷** (AP~AW) 8컬러  
  7. **제품샷 텍스트/Notice** (AX~BD)  
  8. **패브릭 & 제품 정보** (BE~BZ) + 5 Property Table  
  9. **사이즈 이미지 옵션** (CA~CG)  
 10. **사이즈 데이터** (CH~FU) : 상·하의 통합 6세트 × 11측정치 + 사이즈 코멘트  
 11. **모델 정보** (FV~GC) 2명  
 12. **여분/Reserved 필드** (GD~GP) : 확장용  

> 상세 컬럼 매핑은 `scripts/config.py::TEMPLATE_COLUMNS` 및 `docs/DANA_SHEET_TEMPLATE.md` 참고

## 5. Export Flatten Pipeline (Phase 6)
- **문제**: html2canvas가 `object-fit` + `translate/scale` 조합을 정확히 반영하지 못해 JPG가 찌그러짐  
- **해결**: 캔버스에 프레임/크롭 정보를 직접 재렌더링 후 Base64 PNG로 치환
  - HTML Export 시 클론 DOM에 플래튼 이미지를 주입 → 편집 화면과 완전 동일한 정적 결과  
  - JPG Export 시 DOM 이미지를 일시적으로 플래튼 데이터로 교체 → 캡처 후 복원  
  - 로고 그룹, 히어로, 디테일 포인트, 패브릭, 사이즈 이미지 전부 확인 완료

## 6. Quick Start (New Environment)
```bash
# 1. Install dependencies
pip3 install google-auth google-auth-oauthlib google-auth-httplib2 google-api-python-client Pillow numpy

# 2. Configure credentials/service-account.json
# 3. Update scripts/config.py if Sheet ID differs

python3 scripts/load_from_sheets.py
python3 scripts/generate_pages_dana.py
python3 scripts/generate_index.py
python3 scripts/server.py  # optional, for export workflow
```

## 7. Hand-off Checklist
- ✅ `README.md`, `claude.md` (최신 상태)  
- ✅ `scripts/` (templates + flatten logic 반영)  
- ✅ `credentials/service-account.json` (또는 공유 절차 안내)  
- ⬜ `output/assets/images/` 캐시 (선택)  
- ⬜ `data/products.json` (선택)  
- ⬜ `docs/` (본 파일 포함)  

> 위 항목을 제공하면 다른 환경/LLM에서도 동일 프로세스를 재현할 수 있습니다.
