# Legacy 96-Column vs Unified 302-Column Template (2025-10-15)

## 1. Executive Summary
- **Legacy(96)**: 분리된 데이터 구조 + 제한된 이미지/사이즈 지원  
- **Unified(302)**: 단일 탭, 컬러/갤러리 확장, 사이즈 6세트, 플래튼 익스포트 대응  
- 결과: 오늘부로 모든 파이프라인이 Unified Template 기준으로 통합됨

---

## 2. Structural Comparison

| 항목 | 96 Columns (A~CR) | 302 Columns (A~KP) | 비고 |
|------|-------------------|--------------------|------|
| 탭 구조 | 단일 탭 (텍스트+이미지 혼합) | 단일 탭 (템플릿) | 하이브리드 2탭은 폐기 |
| 컬러 수 | 4 | 8 (표준은 4, 옵션 4) | |
| 컬러당 갤러리 | 8 | 12 (+로고 그룹) | 로고 그룹 자동 삽입 |
| 디테일 포인트 | 3 | 4 | 2×2 카드 |
| 제품샷 | 4 | 8 (컬러별 1) | |
| 패브릭 Properties | 5 | 5 (동일) | |
| 사이즈 세트 | 상/하의 1세트 | 최대 6세트 × 11 측정치 | |
| 사이즈 코멘트 | 추천 1개 | 55/66/77 + 추천 | |
| 모델 정보 | 2명 | 2명 (확장 필드 포함) | |
| 이미지 필드 | 제한적 | 전체 파이프라인 대응 (Hero, Fabric, Logo Group 등) | 플래튼 활용 |

---

## 3. Why Unified?
1. **데이터 진입 장벽 감소**: 한 탭에 모든 필드가 존재, VLOOKUP 필요 없음  
2. **Export 품질**: 플래튼 파이프라인과 매칭되는 이미지 세트 확보  
3. **확장성**: 컬러/갤러리/사이즈/모델 정보를 필요에 따라 자유롭게 추가  
4. **코드 단순화**: `load_from_sheets.py`가 단일 맵만 로딩 → 유지보수 용이

---

## 4. Migration Notes
- 기존 하이브리드(요청서/이미지) 시트를 Unified Template으로 변환 필요
- 필드 매핑 참고:
  - 요청서 기본 정보 → A~F
  - 이미지 탭 → main/detail/gallery/productShot/fabric 등 이미지 컬럼
  - 사이즈 호칭 1~6 → size1~size6 세트로 전환
  - 55/66/77 코멘트 → sizeComment55/66/77
- HEX, Description 등 신규 필드는 빈 칸 허용 (자동 계산 또는 스킵)

---

## 5. Impact on Codebase

| 파일 | 변경 사항 |
|------|-----------|
| `scripts/config.py` | `TEMPLATE_COLUMNS` 대폭 확장 (A~KP) |
| `scripts/load_from_sheets.py` | Unified Template 파서 + Hyperlink 추출 + 이미지 캐시 |
| `scripts/generate_pages_dana.py` | 갤러리/로고 그룹/사이즈/플래튼 로직 대응 |
| `scripts/server.py` | 변경 없음 (익스포트 경로만 사용) |
| `docs/*.md` | 본 문서 및 가이드 전체 갱신 |

---

## 6. Export Quality Fix (Phase 6)
- 문제: html2canvas에서 Hero / Detail / Fabric / Logo 이미지가 찌그러짐  
- 원인: `object-fit` + CSS transform을 캔버스가 재현하지 못함  
- 해결: Export 전에 모든 이미지를 캔버스에서 재렌더링하여 Base64로 재치환  
- 효과: HTML ↔ JPG 결과가 완전히 동일해짐 (2025-10-15 테스트 확인)

---

## 7. When to Reference Legacy Docs?
- 과거 프로젝트 회고 또는 96컬럼 기반 스프레드시트를 유지해야 하는 경우  
- 신규 개발/운영은 **반드시 Unified Template** 문서(`docs/DANA_SHEET_TEMPLATE.md`, `docs/HYBRID_SYSTEM_GUIDE.md`)를 참조

---

### Last Updated: 2025-10-15  
Prepared by: Codex Team
