# Unified Template Guide (2025-10-15)

> **Note**  
> 기존 “하이브리드 시스템(요청서 + 이미지 탭)” 문서는 폐기되었습니다. 현재 운영 버전은 **302컬럼 단일 템플릿 탭**을 사용하며, 이 문서는 그 구조와 작성 요령을 정리합니다.

---

## 1. 개요
- 시트명: **`템플릿`**
- 범위: **A2:KP100** (302 Columns, 최대 100개 상품)
- 특징:
  - 모든 텍스트·이미지·사이즈 정보를 한 탭에서 관리
  - 컬러 최대 8개, 컬러별 갤러리 12컷, 제품샷 8컷
  - 사이즈 6세트 × 11측정치 + 사이즈별 코멘트
  - 플래튼 파이프라인을 위한 크롭/이미지 일원화

---

## 2. 섹션 요약 (열 범위)

| 범위 | 그룹 | 주요 필드 |
|------|------|-----------|
| **A ~ F** | Basic Info | productCode, title, sellingPoint1~3, mdComment |
| **G** | Main Image | mainImage (Google Drive URL) |
| **H ~ O** | Color Meta | 색상명/HEX (1~4컬러) |
| **P ~ W** | Detail Points | detailPoint1~4Image / Text |
| **X ~ AO** | Galleries | Color1~8 × 12 Images (logo 그룹 포함) |
| **AP ~ AW** | Product Shots | color1~8ProductShot |
| **AX ~ BD** | Shot Notices & Texts | shotNotice1~2, shotDescription 등 |
| **BE ~ BZ** | Fabric & Product Info | fabricImage, fabricName/Desc, properties table, productInfo1~6 |
| **CA ~ CG** | Size Image Options | 사이즈 가이드 이미지 선택값 |
| **CH ~ FU** | Size Blocks | 6세트 × (Label + 11 measurements) + 55/66/77 코멘트 + 추천 코멘트 |
| **FV ~ GC** | Model Info | model1/2 Name, Size, Color, Height, Body size |
| **GD ~ GP** | Reserve | 확장용 (현재 미사용, 비워둠) |

> 전체 컬럼 인덱스는 `scripts/config.py::TEMPLATE_COLUMNS`에 매핑되어 있습니다.

---

## 3. 작성 가이드

### 3.1 기본 규칙
- **상품코드**는 모든 행에서 필수 (중복 금지)
- 구글 드라이브 URL은 `https://drive.google.com/file/d/...` 형식
- 텍스트 필드에서 줄바꿈은 `Alt+Enter`로 입력 가능
- 빈 칸은 자동으로 스킵되며, 미입력 시 해당 섹션은 렌더링되지 않음

### 3.2 색상 & 갤러리
- Color1~4는 메인 컬러, Color5~8은 옵션컬러 확장용
- 각 컬러 블록:
  - `colorNGallery1~12`: 12컷 (4,5 / 7,8은 로고 그룹에 사용)
  - `colorNProductShot`: 제품 전체컷
- HEX 코드가 비어 있으면 이미지에서 자동 추출

### 3.3 Detail Points
- 이미지 4장 + 설명 4개
- HTML에서는 2×2 카드로 렌더링

### 3.4 Fabric & Product Info
- `fabricImage`는 히어로·디테일처럼 플래튼 후 삽입
- `fabricProperties1~5`: 5행 테이블로 렌더링 (제목/내용)
- `productInfo1~6`: Product Info 섹션의 bullet

### 3.5 Size Blocks
- 블록 순서: `Size1`(상의/하의 자유) → `Size6`
- 각 블록 구성:
  1. `sizeNLabel`
  2. 11 측정값 (어깨, 가슴, 허리, 엉덩이, 허벅지, 밑단, 밑위, 소매통, 소매길이, 총장, 기타)
- 55/66/77 코멘트는 착용 후기 텍스트, 비어 있으면 스킵
- 추천 코멘트는 페이지 하단 “SIZE RECOMMENDATION”에 표시

### 3.6 모델 정보
- 모델 1, 2 각각:
  - 모델명/신체 사이즈/착용 컬러
  - 참고 문구 (예: “167cm / 55size / Beige 착용”)

---

## 4. 검증 체크리스트
1. 상품코드 중복 없음
2. 반드시 필요한 URL (메인, 디테일, 갤러리) 존재 여부
3. HEX 코드 누락 시 자동 추출이 가능하도록 이미지 품질 확인
4. 사이즈 측정값에 숫자/단위 혼용 여부 확인 (HTML에 그대로 노출)
5. Shot Notice, Model Info 등 선택적 필드는 비워도 무방

---

## 5. FAQ
**Q. 기존 “요청서/이미지” 2탭 구조는 더 이상 지원하지 않나요?**  
A. 네. `scripts/load_from_sheets.py`는 `템플릿` 탭만 참조합니다. 과거 시트를 사용할 경우 템플릿 탭으로 마이그레이션해야 합니다.

**Q. 컬러가 2개 뿐인 상품도 작성 가능한가요?**  
A. 가능합니다. 필요한 컬럼만 채우면 되고, 나머지는 비워두면 코드가 자동으로 스킵합니다.

**Q. 사이즈 측정값이 3개뿐이라면?**  
A. 해당 블록에서 필요한 항목만 채우세요. 비어 있는 측정값은 렌더링하지 않습니다.

**Q. 이미지 URL 대신 로컬 경로를 넣으면 되나요?**  
A. 아니요. 서비스 계정이 접근 가능한 구글 드라이브 URL이어야 자동 다운로드가 동작합니다.

---

## 6. 관련 문서
- `docs/DANA_SHEET_TEMPLATE.md` – 컬럼 상세 설명
- `docs/IMPLEMENTATION_SUMMARY.md` – 전체 구현 히스토리/파이프라인 요약
- `claude.md` – 프로젝트 상태 로그
- `README.md` – 실행/설치 가이드

---

### 버전
- v2.0 (2025-10-15) – Unified Template + Flatten Export  
- 작성자: 프로젝트 Codex Team
