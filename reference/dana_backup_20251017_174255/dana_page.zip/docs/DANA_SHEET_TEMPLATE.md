# Unified Google Sheets Template (템플릿!A2:KP) – 2025-10-15

이 문서는 DANA&PETA 페이지 빌더가 사용하는 302컬럼 템플릿 탭 구조를 설명합니다.  
템플릿 헤더는 `scripts/config.py::TEMPLATE_COLUMNS`와 1:1 대응합니다.

---

## 1. High-level Layout

| 구간 | 열 범위 | 설명 |
|------|---------|------|
| A ~ F | Basic Info & Selling Points |
| G | Main Image |
| H ~ O | Color Meta (1~4) |
| P ~ W | Detail Points (1~4) |
| X ~ AO | Color Galleries (Color1~8, up to 12 images each) |
| AP ~ AW | Color Product Shots (Color1~8) |
| AX ~ BD | Shot Text / Notices |
| BE ~ BZ | Fabric Info & Product Info Table |
| CA ~ CG | Size Image Options |
| CH ~ FU | Size Blocks (6세트 × 11 measurements + 코멘트) |
| FV ~ GC | Model Info (2 entries) |
| GD ~ GP | Reserved / Future use |

---

## 2. Basic Info (A ~ F)
| Column | Field | Required | Description |
|--------|-------|----------|-------------|
| A | productCode | ✅ | Unique ID (`DN25SPT008`) |
| B | title | ✅ | 상품명 (줄바꿈 허용) |
| C | sellingPoint1 |  | Hero 섹션 01 |
| D | sellingPoint2 |  | Hero 섹션 02 |
| E | sellingPoint3 |  | Hero 섹션 03 |
| F | mdComment |  | MD 추천 코멘트 |

---

## 3. Images & Colors

### 3.1 Main Image
- **G**: `mainImage` – 구글 드라이브 공유 URL (Hero 배경)

### 3.2 Color Meta (H ~ O)
| 컬럼 | 설명 |
|------|------|
| H, J, L, N | color1~4Name |
| I, K, M, O | color1~4Hex (비우면 자동 추출) |

---

## 4. Detail Points (P ~ W)
| 세트 | 이미지 | 텍스트 |
|------|--------|---------|
| DetailPoint1 | P | Q |
| DetailPoint2 | R | S |
| DetailPoint3 | T | U |
| DetailPoint4 | V | W |

이미지는 1200×1200 기준, 텍스트는 2~3줄 권장.

---

## 5. Gallery (X ~ AO)

- 컬러당 최대 **12컷**을 지원
- 컬러 슬롯: 1~8 (총 8개)
- 파일 네이밍: `gallery_color{색상인덱스}_{컷번호}`
- **로고 그룹 규칙**  
  - 이미지 4,5 → 로고 그룹 1  
  - 이미지 7,8 → 로고 그룹 2  
  - 나머지는 일반 갤러리 컷

예시 (Color1):
| 열 | 필드 |
|----|------|
| X | color1Gallery1 |
| Y | color1Gallery2 |
| … | … |
| AJ | color1Gallery12 |

같은 패턴으로 Color8까지 반복.

---

## 6. Product Shots (AP ~ AW)
| 열 | 필드 |
|----|------|
| AP | color1ProductShot |
| AQ | color2ProductShot |
| … | … |
| AW | color8ProductShot |

> 갤러리를 채우지 않더라도 ProductShot이 존재하면 Product Shot 섹션에 렌더링됩니다.

---

## 7. Shot Text & Notices (AX ~ BD)
- AX ~ BB: shotDescription1~5 (선택)
- BC: `shotNotice1`
- BD: `shotNotice2`

---

## 8. Fabric & Product Info (BE ~ BZ)
| 필드 | 설명 |
|------|------|
| BE | fabricImage |
| BF | fabricName |
| BG | fabricDesc |
| BH~BM | fabricProperty1Title/Value ~ fabricProperty5Title/Value |
| BN | fabricComposition |
| BO | fabricLining |
| BP | fabricTransparency |
| BQ | fabricStretch |
| BR | fabricThickness |
| BS | fabricSeason |
| BT~BZ | productInfo1~6 (세탁/관리 등) |

---

## 9. Size Image Selection (CA ~ CG)
- `CA`: defaultSizeImage (예: “상의”)
- `CB~CG`: sizeImageOption1~6 (선택지)
- 에디터에서 드롭다운으로 제공, 선택값은 로컬스토리지에 저장

---

## 10. Size Blocks (CH ~ FU)

### 10.1 구조
각 세트는 다음 12필드로 구성 (예: Size1):
1. `size1Label`  
2. `size1Shoulder`  
3. `size1Bust`  
4. `size1Waist`  
5. `size1Hip`  
6. `size1Thigh`  
7. `size1Hem`  
8. `size1Rise`  
9. `size1SleeveOpening`  
10. `size1SleeveLength`  
11. `size1TotalLength`  
12. `size1Extra` (필요 시 사용)

동일 패턴이 `size2` ~ `size6`까지 반복됩니다.

### 10.2 사이즈 코멘트
- **FR**: sizeComment55  
- **FS**: sizeComment66  
- **FT**: sizeComment77  
- **FU**: sizeRecommendation

---

## 11. Model Info (FV ~ GC)
| 필드 | 설명 |
|------|------|
| FV | model1Name |
| FW | model1Info (예: 167cm / 55size) |
| FX | model1Color |
| FY | model1Note |
| FZ | model2Name |
| GA | model2Info |
| GB | model2Color |
| GC | model2Note |

---

## 12. Reserved Columns (GD ~ GP)
- 현재 비어 있음  
- 추후 확장 시 사용

---

## 13. Data Entry Tips
1. **이미지 URL**은 공유 권한 “Anyone with the link” + “Viewer” 이상  
2. HEX 코드가 정확할수록 색상 박스가 브랜드 컬러와 잘 맞습니다  
3. 사이즈 측정값은 숫자+단위 조합으로 작성 (예: `45cm`)  
4. 미사용 컬럼은 비워두면 코드가 자동으로 스킵  
5. 텍스트는 줄바꿈을 허용 (HTML에서 `<br>` 처리)  
6. `size1Label` 등에 “상의 / FREE”처럼 타입을 함께 써두면 가독성이 좋습니다

---

## 14. Validation Checklist
- [ ] 모든 행에 `productCode` 존재  
- [ ] 필수 이미지 (mainImage, detailPoint1~2, gallery 최소 4컷) 입력  
- [ ] Color Hex가 비어 있다면 이미지 대비 확인  
- [ ] 사이즈 블록 값이 숫자/텍스트 혼합 시 맞춤법 확인  
- [ ] shotNotice, modelInfo 등 선택 필드는 필요할 때만 입력

---

## 15. Reference
- `scripts/config.py` – 템플릿 인덱스 및 상수  
- `scripts/load_from_sheets.py` – 템플릿 로딩 로직  
- `docs/HYBRID_SYSTEM_GUIDE.md` – 작성 가이드 요약  
- `docs/IMPLEMENTATION_SUMMARY.md` – 히스토리 및 파이프라인  
- `claude.md` – 최신 변경 로그 (Phase 6 플래튼 파이프라인)

---

**Last Updated**: 2025-10-15 (Unified Template + Flatten Export)  
Maintainer: Codex Team
