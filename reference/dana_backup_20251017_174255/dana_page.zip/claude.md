# DANA&PETA 페이지 빌더 프로젝트 상태

## 최종 업데이트
- 날짜: 2025-10-15
- 세션 ID: pb_dana_page_builder_export_image_flatten_fix
- 상태: ✅ JPG/HTML 익스포트 이미지 비율 고정 (캔버스 플래튼 파이프라인 적용) 완료

---

## 📊 프로젝트 개요

### 목적
DANA&PETA 브랜드의 상품 상세 페이지를 자동으로 생성하는 시스템 구축
- Google Sheets에서 제품 데이터 로드
- Figma 디자인 스펙을 정확히 반영한 HTML 페이지 자동 생성
- 원본(Original) 및 에디터블(Editable) 버전 동시 생성
- Base64 인코딩을 통한 단일 파일 HTML (이미지 포함)

### 주요 기능
1. **Google Sheets 연동**: 하이퍼링크 이미지 URL 자동 추출
2. **이미지 자동 다운로드**: Google Drive 이미지 일괄 다운로드
3. **HTML 자동 생성**: Figma 디자인 기반 픽셀 퍼펙트 레이아웃
4. **에디터블 모드**: 브라우저에서 직접 수정 가능한 버전 제공
5. **Base64 인코딩**: 모든 이미지를 HTML에 임베드하여 단일 파일로 생성
6. **익스포트 플래튼 파이프라인**: html2canvas 한계를 우회하기 위해 캔버스 기반으로 이미지 크롭을 재작성하여 JPG/HTML 결과 일치

---

## ✅ 완료된 작업 (최신순)

### 2025-10-15: JPG/HTML 익스포트 이미지 비율 플래튼 처리 (Phase 6)

#### 개요
html2canvas가 `object-fit` + CSS 트랜스폼을 완전히 재현하지 못해 JPG 결과물의 히어로/디테일 포인트/패브릭/로고 그룹 이미지가 HTML과 다르게 찌그러지는 문제가 보고됨. 모든 에디터블 이미지에 대해 **캔버스 기반 플래튼 파이프라인**을 추가하여 브라우저 렌더링과 동일한 픽셀 데이터를 생성하도록 개선.

#### 1. 캔버스 플래튼 파이프라인 도입

- **추가 함수** (`scripts/generate_pages_dana.py`)
  - `loadImage`: 이미지 캐시 + 프리로드
  - `computeTransform`/`applyTransform`: 퍼센트 기반 크롭 값을 px로 변환해 DOM에 적용
  - `generateFlattenedImageData`: 프레임 크기를 기준으로 캔버스에 재렌더, Base64 PNG 반환
  - `createFlattenedImageMap`: 동일 설정 재사용을 위한 캐시 맵 구성

#### 2. HTML 내보내기 개선

- 플래튼 맵을 이용해 클론 DOM 내 `img.editable-image`의 `src`를 즉시 교체 → 내보낸 HTML은 편집 화면과 완전히 동일한 정적 상태
- 트랜스폼/트랜스폼-오리진을 필요 시 제거하거나 유지하는 로직 보강

#### 3. JPG 내보내기 개선

- 내보내기 직전 DOM의 이미지를 플래튼 데이터로 일시 교체 후 html2canvas 캡처 → 드래그/슬라이더로 만든 크롭이 그대로 반영
- 캡처 종료 후 원본 이미지/스타일 복원 (메모리 캐시에 의존)
- 로고 그룹·패브릭·디테일 포인트 등 문제 구간이 모두 해소됨 (2025-10-15 실사 확인)

#### 4. 실행 로그 (2025-10-15 14:23)

```
python3 scripts/load_from_sheets.py
python3 scripts/generate_pages_dana.py
python3 scripts/generate_index.py
# HTML/JPG 익스포트는 플래튼 적용 버전으로 확인 완료
```

---

### 2025-10-14: Flask 서버 기반 익스포트 시스템 구현 (Phase 5)

#### 개요
에디터블 HTML에서 편집한 내용을 JPG 및 HTML 형식으로 익스포트하는 기능을 구현했습니다. 브라우저의 파일 시스템 접근 제한을 Flask 로컬 서버로 해결하여 `output/날짜/익스포트/` 폴더에 자동 저장되도록 구현했습니다.

#### 1. Flask 로컬 서버 구현

##### 파일: `scripts/server.py` (NEW FILE)
Flask 웹 서버를 통해 브라우저가 수행할 수 없는 파일 시스템 작업을 서버 측에서 처리합니다.

##### 주요 엔드포인트
1. **`/` (GET)**: 사용 가능한 에디터블 파일 목록 표시
   - `output/날짜/에디터블/` 폴더 스캔
   - HTML 리스트로 표시
   - 각 파일을 클릭하여 에디터블 모드 열기

2. **`/editable/<product_code>` (GET)**: 에디터블 HTML 파일 제공
   - 예: `http://localhost:5001/editable/DN25SPT008`
   - `output/날짜/에디터블/{product_code}_editable.html` 제공

3. **`/save-html` (POST)**: HTML 파일 저장
   - 요청 본문: `{productCode, htmlContent}`
   - 저장 경로: `output/날짜/익스포트/{productCode}_exported_dana.html`
   - 중복 파일명 자동 처리 (suffix 추가)

4. **`/save-jpg` (POST)**: JPG 파일 저장
   - 요청 본문: `{productCode, imageData}` (base64)
   - 저장 경로: `output/날짜/익스포트/{productCode}_dana.jpg`
   - 중복 파일명 자동 처리 (suffix 추가)

##### 주요 기능
```python
def get_unique_filename(directory: Path, base_name: str, extension: str) -> Path:
    """Generate unique filename by adding numbers if file exists"""
    file_path = directory / f"{base_name}{extension}"

    if not file_path.exists():
        return file_path

    counter = 1
    while True:
        file_path = directory / f"{base_name}_{counter}{extension}"
        if not file_path.exists():
            return file_path
        counter += 1
```

##### 서버 실행
```bash
python3 scripts/server.py
# 🌐 Server URL: http://localhost:5001
```

##### 포트 설정
- **Port 5001** 사용 (5000은 macOS AirPlay Receiver가 점유)
- `app.run(host='0.0.0.0', port=5001, debug=True)`

#### 2. HTML 익스포트 기능

##### 파일: `scripts/generate_pages_dana.py` (lines 1326-1395)
에디터블 HTML에서 "HTML 다운로드" 버튼 클릭 시 서버로 POST 요청을 보내 저장합니다.

##### 구현 로직
```javascript
async function exportHTML() {
    const clone = document.documentElement.cloneNode(true);

    // Remove control panel
    const controlPanel = clone.querySelector('.control-panel');
    if (controlPanel) controlPanel.remove();

    // Remove scripts
    const scripts = clone.querySelectorAll('script');
    scripts.forEach(s => s.remove());

    // Apply inline styles to all images
    clone.querySelectorAll('.image-frame').forEach(frame => {
        const id = frame.getAttribute('data-id');
        const img = frame.querySelector('.editable-image');
        const settings = cropSettings.images[id];
        if (settings && img) {
            const scale = settings.scale / 100;
            const tx = settings.x - 100;
            const ty = settings.y - 100;
            img.style.transform = `translate(${tx}%, ${ty}%) scale(${scale})`;
        }
        frame.style.cursor = 'default';
        frame.classList.remove('selected');
    });

    // Remove contenteditable attributes
    clone.querySelectorAll('[contenteditable]').forEach(el => {
        el.removeAttribute('contenteditable');
    });

    // Remove body inline styles
    const body = clone.querySelector('body');
    if (body) body.removeAttribute('style');

    const htmlContent = '<!DOCTYPE html>\\n' + clone.outerHTML;

    // Send to server
    const response = await fetch('http://localhost:5001/save-html', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            productCode: '{product["productCode"]}',
            htmlContent: htmlContent
        })
    });

    if (response.ok) {
        const result = await response.json();
        alert(`✅ HTML 저장 완료\\n경로: ${result.path}`);
    }
}
```

##### 주요 처리
1. DOM 전체 복제 (`cloneNode(true)`)
2. 컨트롤 패널 제거
3. 스크립트 태그 제거
4. 이미지 transform을 인라인 스타일로 적용
5. contenteditable 속성 제거
6. 선택 상태 CSS 클래스 제거
7. 서버로 POST 전송
8. 저장 경로 알림 표시

#### 3. JPG 익스포트 기능

##### 파일: `scripts/generate_pages_dana.py` (lines 1397-1500)
html2canvas 라이브러리를 사용하여 전체 페이지를 JPG 이미지로 캡처하고 서버에 저장합니다.

##### html2canvas CDN 추가 (line 1507)
```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
```

##### 구현 로직
```javascript
async function exportAsJPG() {
    const controlPanel = document.querySelector('.control-panel');
    const container = document.querySelector('.container');
    const body = document.body;

    // Save original styles
    const originalTransform = container.style.transform;
    const originalHeight = container.style.height;
    const originalMinHeight = body.style.minHeight;

    // Save original selection state
    const selectedFrames = document.querySelectorAll('.image-frame.selected');
    const originalSelectedIds = Array.from(selectedFrames).map(f => f.getAttribute('data-id'));

    // Hide control panel
    if (controlPanel) controlPanel.style.display = 'none';

    try {
        // Reset container transform and height for capture
        container.style.transform = 'none';
        container.style.height = 'auto';
        body.style.minHeight = 'auto';

        // Remove all selection styles before capture
        document.querySelectorAll('.image-frame').forEach(frame => {
            frame.classList.remove('selected');
            frame.style.border = 'none';
            frame.style.outline = 'none';
            frame.style.boxShadow = 'none';
        });

        // Wait for layout and styles to settle
        await new Promise(resolve => setTimeout(resolve, 150));

        // Capture entire container as canvas
        const canvas = await html2canvas(container, {
            scale: 2,  // High resolution
            useCORS: true,
            backgroundColor: '#ffffff',
            logging: false,
            allowTaint: true,
            windowWidth: container.scrollWidth,
            windowHeight: container.scrollHeight,
            width: container.scrollWidth,
            height: container.scrollHeight
        });

        // Convert canvas to base64
        const base64Image = canvas.toDataURL('image/jpeg', 0.95);

        // Send to server
        const response = await fetch('http://localhost:5001/save-jpg', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                productCode: '{product["productCode"]}',
                imageData: base64Image
            })
        });

        if (response.ok) {
            const result = await response.json();
            alert(`✅ JPG 저장 완료\\n경로: ${result.path}`);
        }

    } finally {
        // Restore original styles
        container.style.transform = originalTransform;
        container.style.height = originalHeight;
        body.style.minHeight = originalMinHeight;

        // Restore selection state
        originalSelectedIds.forEach(id => {
            const frame = document.querySelector(`[data-id="${id}"]`);
            if (frame) {
                frame.classList.add('selected');
                frame.style.border = '';
                frame.style.outline = '';
                frame.style.boxShadow = '';
            }
        });

        // Restore control panel
        if (controlPanel) controlPanel.style.display = 'block';
    }
}
```

##### 주요 처리
1. 컨트롤 패널 숨김
2. 원본 스타일 저장 (transform, height)
3. **선택 상태 저장** (녹색 테두리 제거를 위해)
4. 컨테이너 transform 제거 (캡처용)
5. **모든 선택 스타일 제거** (border, outline, boxShadow)
6. 150ms 대기 (스타일 적용 시간)
7. html2canvas로 캡처 (scale: 2, 고해상도)
8. Base64 JPEG 변환 (quality: 0.95)
9. 서버로 POST 전송
10. **원본 스타일 복원** (finally 블록)
11. **선택 상태 복원** (사용자 경험 유지)

#### 4. 녹색 테두리 문제 해결

##### 문제
이미지를 선택한 상태(`.image-frame.selected`)에서 JPG 익스포트 시 녹색 테두리가 캡처됨.

##### 원인
- `.image-frame.selected` CSS:
  ```css
  border: 3px solid #4CAF50;
  box-shadow: 0 0 10px rgba(76, 175, 80, 0.5);
  ```
- html2canvas가 이 스타일을 그대로 캡처

##### 해결 방법
캡처 전 임시로 선택 스타일 제거, 캡처 후 복원:

```javascript
// Before capture: Save selection state
const selectedFrames = document.querySelectorAll('.image-frame.selected');
const originalSelectedIds = Array.from(selectedFrames).map(f => f.getAttribute('data-id'));

// Remove all selection styles
document.querySelectorAll('.image-frame').forEach(frame => {
    frame.classList.remove('selected');
    frame.style.border = 'none';
    frame.style.outline = 'none';
    frame.style.boxShadow = 'none';
});

// ... capture ...

// After capture: Restore selection state
originalSelectedIds.forEach(id => {
    const frame = document.querySelector(`[data-id="${id}"]`);
    if (frame) {
        frame.classList.add('selected');
        frame.style.border = '';  // Clear inline style (let CSS take over)
        frame.style.outline = '';
        frame.style.boxShadow = '';
    }
});
```

##### 결과
- ✅ JPG 익스포트에 녹색 테두리 없음
- ✅ 사용자 선택 상태는 유지됨
- ✅ 사용자 경험 손실 없음

#### 5. 익스포트 폴더 구조

##### config.py 수정
```python
# Folder names
ORIGINAL_FOLDER = "원본"
EDITABLE_FOLDER = "에디터블"
EXPORT_FOLDER = "익스포트"  # NEW
```

##### 폴더 구조
```
output/
└── 2025-10-14/
    ├── 원본/
    │   ├── DN25SPT008.html
    │   └── DN25SSK007.html
    ├── 에디터블/
    │   ├── DN25SPT008_editable.html
    │   └── DN25SSK007_editable.html
    └── 익스포트/         # NEW
        ├── DN25SPT008_exported_dana.html
        ├── DN25SPT008_dana.jpg
        ├── DN25SPT008_dana_1.jpg
        └── DN25SSK007_dana.jpg
```

##### 파일명 규칙
- **HTML**: `{productCode}_exported_dana.html`
- **JPG**: `{productCode}_dana.jpg`
- **중복 시**: `{productCode}_dana_1.jpg`, `{productCode}_dana_2.jpg`, ...

#### 6. 사용 워크플로우

##### Step 1: Flask 서버 시작
```bash
cd /Users/younghoonjung/ai-project/pb_dana_page_builder
python3 scripts/server.py
```

출력:
```
============================================================
🚀 DANA&PETA 에디터블 서버 시작
============================================================
📂 Output Directory: /Users/younghoonjung/ai-project/pb_dana_page_builder/output
🌐 Server URL: http://localhost:5001
============================================================
```

##### Step 2: 브라우저에서 서버 접속
```
http://localhost:5001
```

에디터블 파일 목록이 표시됨:
- DN25SPT008
- DN25SSK007

##### Step 3: 에디터블 HTML 열기
파일 링크 클릭 → 새 탭에서 에디터블 HTML 열림
```
http://localhost:5001/editable/DN25SPT008
```

##### Step 4: 이미지 편집
- 우측 컨트롤 패널에서 이미지 선택
- 줌/팬 조정 (슬라이더 또는 드래그)
- 페이지 줌 조정 (전체 뷰)
- 사이즈 이미지 선택

##### Step 5: 익스포트
- **HTML 다운로드** 버튼 클릭
  - 서버에 POST 요청
  - `output/2025-10-14/익스포트/DN25SPT008_exported_dana.html` 저장
  - 경로 알림 표시

- **JPG 다운로드** 버튼 클릭
  - html2canvas로 캡처
  - 서버에 POST 요청 (base64)
  - `output/2025-10-14/익스포트/DN25SPT008_dana.jpg` 저장
  - 경로 알림 표시

#### 7. 기술적 특징

##### 브라우저 보안 제한 우회
- JavaScript는 임의 경로에 파일 저장 불가 (보안 제한)
- Flask 로컬 서버로 해결:
  - 브라우저: Fetch API로 데이터 전송
  - 서버: 파일 시스템에 저장
  - CORS: flask-cors로 Cross-Origin 허용

##### html2canvas 최적화
- `scale: 2`: 고해상도 캡처 (Retina 대응)
- `useCORS: true`: 외부 이미지 포함 가능
- `backgroundColor: '#ffffff'`: 배경 보장
- `quality: 0.95`: JPEG 품질 (95%)

##### 임시 스타일 제거 패턴
- 캡처 전: 선택 스타일 제거
- 캡처 후: 원본 상태 복원
- finally 블록: 에러 발생 시에도 복원 보장

##### 파일명 중복 처리
- 파일 존재 확인
- 존재 시 suffix 자동 추가 (_1, _2, ...)
- 무한 루프로 빈 번호 탐색

##### Base64 이미지 전송
- Canvas → Base64 Data URL
- POST 요청 본문에 포함
- 서버에서 디코딩 후 저장

#### 8. 에러 처리

##### Port 5000 충돌 해결
- **문제**: Port 5000이 macOS AirPlay Receiver에 의해 점유됨
- **해결**: Port 5001로 변경
  - `server.py`: `app.run(port=5001)`
  - `generate_pages_dana.py`: `http://localhost:5001`

##### Flask 의존성 설치
```bash
pip3 install flask flask-cors
```

설치된 패키지:
- flask-3.1.2
- flask-cors-6.0.1
- werkzeug-3.1.3
- jinja2-3.1.6

##### 서버 연결 실패 처리
```javascript
catch (error) {
    console.error('Export error:', error);
    alert('❌ 서버 연결 실패. 서버가 실행 중인지 확인하세요.\\n(python3 scripts/server.py)');
}
```

#### 9. 실행 결과

##### 테스트 환경
- 제품: DN25SPT008 (라인 스판 반밴딩 와이드 슬랙스)
- 브라우저: Chrome 최신 버전
- 서버: Flask 3.1.2 (Port 5001)

##### 성공 로그
```
2025-10-14 18:45:23 - INFO - ✅ HTML saved: output/2025-10-14/익스포트/DN25SPT008_exported_dana.html
2025-10-14 18:45:45 - INFO - ✅ JPG saved: output/2025-10-14/익스포트/DN25SPT008_dana.jpg
```

##### 파일 생성 확인
- ✅ `DN25SPT008_exported_dana.html` (67MB, base64 이미지 포함)
- ✅ `DN25SPT008_dana.jpg` (2.3MB, 1200px 너비, 고해상도)
- ✅ 녹색 테두리 없음
- ✅ 이미지 편집 내용 정상 반영

#### 10. 기술 스택

##### Backend
- **Flask 3.1.2**: 로컬 웹 서버
- **Flask-CORS 6.0.1**: Cross-Origin 요청 허용
- **Python pathlib**: 파일 경로 처리
- **Python base64**: 이미지 디코딩

##### Frontend
- **Fetch API**: HTTP POST 요청
- **html2canvas 1.4.1**: DOM to Canvas 변환
- **Canvas API**: JPEG 인코딩
- **Data URL**: Base64 이미지 전송

##### 통신
- **HTTP POST**: JSON 본문
- **CORS**: 동일 출처 정책 우회
- **Content-Type**: application/json

### 2025-10-14: 에디터블 HTML 여백 문제 해결 (Phase 4)

#### 개요
에디터블 HTML에서 Product Info 섹션 아래에 발생하던 과도한 여백(whitespace) 문제를 근본적으로 해결했습니다.

#### 1. 문제 분석
- **증상**: 에디터블 HTML에서 Product Info 섹션 아래로 매우 긴 하얀 공간이 나타남
- **원인**: CSS `transform: scale(0.6)`가 시각적 크기만 축소하고, 문서 플로우는 원본 크기를 유지
  - 컨테이너 실제 높이: ~4823px
  - 시각적 높이 (60% 스케일): ~2894px
  - 빈 공간: ~1929px
- **근본 원인**: `applyPageZoom()` 함수가 transform만 적용하고 실제 높이를 조정하지 않음

#### 2. 해결 방법
- **파일**: `scripts/generate_pages_dana.py:1240-1251`
- **수정 내용**: `applyPageZoom()` 함수에 container height 자동 조정 로직 추가
```javascript
function applyPageZoom() {
    const container = document.querySelector('.container');
    if (container) {
        const scale = pageZoom / 100;
        container.style.transform = `scale(${scale})`;

        // Adjust container height to account for scale transform
        // This prevents excessive whitespace below scaled content
        const naturalHeight = container.scrollHeight;
        container.style.height = `${naturalHeight * scale}px`;
    }
}
```

#### 3. 작동 원리
- `scrollHeight`: 컨테이너의 실제 콘텐츠 높이 (~4823px)
- `scale`: 페이지 줌 비율 (기본 0.6)
- `height`: 스케일이 적용된 높이 (~2894px)
- 결과: 문서 높이가 시각적 높이와 일치하여 여백 제거

#### 4. 실행 결과
- ✅ DN25SPT008: 여백 문제 완전 해결
- ✅ DN25SSK007: 여백 문제 완전 해결
- ✅ 모든 페이지 줌 레벨(30-100%)에서 정상 작동
- ✅ LocalStorage 설정과 정상 연동

#### 5. 기술적 특징
- ✅ CSS Transform의 문서 플로우 특성 이해
- ✅ JavaScript scrollHeight 속성 활용
- ✅ 동적 높이 계산 및 적용
- ✅ 스케일 변경 시 실시간 높이 조정

### 2025-10-14: 다중 제품 생성 완료

#### 개요
Google Sheets에서 2개 제품 데이터를 로드하고 HTML을 성공적으로 생성했습니다.

#### 생성된 제품
1. **DN25SPT008** - 라인 스판 반밴딩 와이드 슬랙스
   - 컬러: 베이지(12장), 핑크(5장)
   - 이미지: 총 22장

2. **DN25SSK007** - 클래식 벨티드 플리츠 롱 스커트
   - 컬러: 인디고, 블랙
   - 이미지: 총 23장

#### 이미지 캐싱 시스템
- 60개 이미지 캐시 유지
- 캐시 히트율: 100% (다운로드 없이 모든 이미지 재사용)
- 다운로드 시간: 0초 (캐시 활용)

#### 생성된 파일
```
output/2025-10-14/
├── 원본/
│   ├── DN25SPT008.html  (67MB)
│   └── DN25SSK007.html  (65MB)
└── 에디터블/
    ├── DN25SPT008_editable.html  (67MB)
    └── DN25SSK007_editable.html  (65MB)
```

### 2025-10-14: 에디터블 모드 개선 완료 (Phase 3)

#### 개요
에디터블 HTML 파일의 사용성을 대폭 개선하여 이미지 편집, 페이지 뷰, 사이즈 이미지 선택 등의 기능을 완성했습니다.

#### 1. 히어로 이미지 표시 수정
- **문제**: 히어로 이미지가 1565px 섹션을 채우지 못하고 상단에만 표시됨
- **원인**: CSS 캐스케이드에서 `.image-frame { position: relative }`가 `.hero-image-frame { position: absolute }`를 덮어씀
- **해결**: `position: absolute !important`로 우선순위 강제
- **파일**: `scripts/generate_pages_dana.py:1408`
- **결과**: ✅ 히어로 이미지가 전체 섹션 채움 (1200px × 1565px)

#### 2. 페이지 줌 기능 추가
- **기능**: 30% ~ 100% 사이 페이지 확대/축소 (기본값 60%)
- **구현**:
  - CSS: `.container { transform: scale(zoom); transform-origin: top center; }`
  - UI: 줌 슬라이더 추가 (컨트롤 패널 상단)
  - 저장: localStorage에 줌 레벨 저장/복원
- **파일**:
  - CSS: `scripts/generate_pages_dana.py:1391-1396`
  - UI: `scripts/generate_pages_dana.py:1310-1320`
  - JavaScript: `scripts/generate_pages_dana.py:924-945, 1039-1050`
- **결과**: ✅ 전체 페이지를 축소하여 파악하기 쉬워짐

#### 3. 히어로 이미지 편집 활성화
- **문제**: 히어로 이미지 줌/팬 컨트롤이 작동하지 않음
- **해결 1**: 히어로 이미지 편집을 막는 3개 조건문 제거
- **해결 2**: `.hero-overlay`에 `pointer-events: none` 추가로 드래그 기능 활성화
- **파일**: `scripts/generate_pages_dana.py:1480`
- **결과**: ✅ 패널 슬라이더 + 클릭 드래그 모두 작동

#### 4. 갤러리 이미지 ID 시스템 개편
- **문제**: 모든 컬러가 동일한 ID 사용 (gallery1, gallery2...) → 중복 및 잘못된 선택
- **해결**: 컬러별 고유 ID 생성
  - 변경 전: `gallery1`, `gallery2`, ...
  - 변경 후: `gallery_color1_1`, `gallery_color1_2`, `gallery_color2_1`, ...
- **파일**: `scripts/generate_pages_dana.py:233, 275`
- **결과**: ✅ 각 컬러의 모든 이미지가 고유하게 식별됨

#### 5. 이미지 메뉴 완성 (전체 컬러 표시)
- **문제**: 컨트롤 패널 드롭다운에 Color 1 이미지만 표시됨
- **해결**: `imageList` 생성 로직 전면 재작성
  - 모든 컬러 반복 순회
  - 각 컬러의 모든 이미지 추가
  - 컬러명 포함 라벨 생성 (예: "베이지 - 갤러리 3")
- **파일**: `scripts/generate_pages_dana.py:758-794`
- **결과**: ✅ 모든 컬러의 모든 이미지가 드롭다운에 표시됨

#### 6. 갤러리 1번 이미지 기본값 유지
- **문제**: 각 컬러의 첫 번째 갤러리 이미지가 localStorage에서 로드되어 기본값 아님
- **해결**: `loadSettings()`에서 ID가 `_1`로 끝나는 이미지 스킵
- **파일**: `scripts/generate_pages_dana.py:1141-1143`
- **결과**: ✅ 모든 컬러의 첫 번째 갤러리 이미지는 항상 x:100%, y:100%, scale:100%

#### 7. 로고 그룹 CSS 셀렉터 수정
- **문제**: 갤러리 ID 변경 후 로고 그룹 레이아웃 깨짐 (이미지 겹침)
- **원인**: CSS가 구 ID 포맷 사용 (`[data-id="logoGroup1_1"]`)
- **해결**: Attribute 셀렉터로 변경 (`[data-id$="_1_1"]` - "ends with" 패턴)
- **파일**: `scripts/generate_pages_dana.py:1782, 1796, 1843, 1857`
- **결과**: ✅ 로고 그룹 레이아웃 정상 복구

#### 8. Fabric 이미지 너비 수정
- **문제**: Fabric 정보 이미지가 1120px (1200px 아님)
- **원인**: `.fabric-image-container`에 `padding: 40px` 적용 (좌우 80px 감소)
- **해결**: `padding: 40px` → `padding: 0`
- **파일**: `scripts/generate_pages_dana.py:1950`
- **결과**: ✅ Fabric 이미지 전체 너비 1200px

#### 9. Product Info 레이아웃 비율 조정
- **문제**: 왼쪽 이미지와 오른쪽 테이블이 약 50:50 비율
- **요구사항**: 30:70 비율로 변경 (테이블 더 넓게)
- **해결**: 이미지 너비 539px → 300px
- **파일**: `scripts/generate_pages_dana.py:2096`
- **결과**: ✅ 이미지:테이블 = 30:70 비율

#### 10. Product Info 헤더 너비 증가
- **문제**: 헤더 셀이 좁아서 4글자(예: "세탁방법") 줄바꿈 발생
- **요구사항**: 4글자까지 한 줄 표시
- **해결**: 헤더 너비 150px → 200px
- **파일**: `scripts/generate_pages_dana.py:2127`
- **결과**: ✅ 4글자 한국어도 한 줄에 표시

#### 11. 사이즈 이미지 선택 기능 추가
- **기능**: 에디터블 모드에서 Product Info 이미지 변경 가능
- **구현**:
  - Python: 모든 사이즈 이미지 Base64 인코딩 (`size_images/*.png`)
  - HTML: Product Info 이미지에 `id="product-info-image"` 추가
  - UI: 녹색 테마 드롭다운 섹션 추가 (📐 사이즈 이미지 선택)
  - JavaScript: `sizeImagesData` 객체에 이미지 데이터 임베드
  - 기능: 드롭다운 변경 시 이미지 교체 + localStorage 저장
- **파일**:
  - 이미지 로딩: `scripts/generate_pages_dana.py:443-467`
  - UI 섹션: `scripts/generate_pages_dana.py:1350-1360`
  - JavaScript 데이터: `scripts/generate_pages_dana.py:812, 824-826`
  - 드롭다운 초기화: `scripts/generate_pages_dana.py:864-876`
  - 이벤트 리스너: `scripts/generate_pages_dana.py:901-907`
  - 이미지 변경 함수: `scripts/generate_pages_dana.py:1276-1289`
  - 저장/복원: `scripts/generate_pages_dana.py:1186-1198, 1291-1297`
- **사이즈 이미지 목록**:
  - 상의.png
  - 팬츠.png
  - 스커트-H라인.png
  - 스커트-플레어.png
  - 아우터.png
  - 원피스.png
  - 점프수트.png
- **결과**: ✅ 사이즈 이미지를 브라우저에서 실시간 변경 가능 (기본값은 products.json의 sizeImage 필드)

#### 12. 기술적 특징
- ✅ CSS `!important`로 스타일 우선순위 제어
- ✅ CSS Transform으로 페이지 줌 (실제 픽셀은 유지)
- ✅ CSS Attribute Selector의 "ends-with" 패턴 활용
- ✅ JavaScript Event Handling (mousedown, wheel, drag)
- ✅ LocalStorage를 활용한 설정 영속성
- ✅ Base64 인코딩으로 단일 파일 HTML 유지
- ✅ Python f-string에서 `{{`로 중괄호 이스케이핑
- ✅ 동적 HTML/JavaScript 생성

### 2025-10-14: 갤러리 로고 그룹 기능 구현

#### 개요
갤러리 섹션에 DANA&PETA 브랜드 로고를 삽입하여 고급스러운 브랜드 이미지를 강조하는 기능을 구현했습니다.

#### 1. 갤러리 패턴 시스템
- **패턴 구조** (컬러별 독립 적용):
  - 이미지 1-3: 일반 표시
  - 이미지 4-5: **로고 그룹 1** (좌우 배치 + 로고 2개)
  - 이미지 6: 일반 표시
  - 이미지 7-8: **로고 그룹 2** (상하 배치 + 가로 로고 1개)
  - 이미지 9+: 일반 표시

- **컬러별 독립 패턴**:
  - Color1 (베이지): 12개 이미지 → 로고 그룹 1, 2 모두 표시
  - Color2 (핑크): 5개 이미지 → 로고 그룹 1만 표시
  - 각 컬러마다 이미지 개수가 다르더라도 패턴이 정상 작동

#### 2. 로고 그룹 1 (이미지 4-5)
- **레이아웃**: Grid 2열 × 2행 (600px × 1200px)
- **이미지 배치**:
  - 이미지 4: 좌측 상단 (600px × 600px)
  - 이미지 5: 우측 하단 (600px × 600px)
- **로고 배치**:
  - 우측 상단 로고: 373px × 47px, 45도 회전, transform-origin: bottom left
  - 좌측 하단 로고: 373px × 47px, -45도 회전, transform-origin: top right
- **시각 효과**: `filter: invert(1)` (흑백 반전)
- **파일**: `scripts/generate_pages_dana.py:316-368`

#### 3. 로고 그룹 2 (이미지 7-8)
- **레이아웃**: 세로 스택 (1200px × 1200px)
- **이미지 배치**:
  - 이미지 7: 상단 (1200px × 600px)
  - 이미지 8: 하단 (1200px × 600px)
- **로고 배치**:
  - 가로 중앙 로고: 775px × 98px, 수평 배치
- **시각 효과**: `filter: invert(1)` (흑백 반전)
- **파일**: `scripts/generate_pages_dana.py:369-417`

#### 4. CSS 구조
```css
.gallery-logo-group-1 {
    display: grid;
    grid-template-columns: 600px 600px;
    grid-template-rows: 600px 600px;
    width: 1200px;
    height: 1200px;
    position: relative;
}

.gallery-logo-right {
    width: 373px;
    height: 47px;
    transform: rotate(45deg);
    transform-origin: bottom left;
    filter: invert(1);
}

.gallery-logo-left {
    width: 373px;
    height: 47px;
    transform: rotate(-45deg);
    transform-origin: top right;
    filter: invert(1);
}

.gallery-logo-group-2 {
    display: flex;
    flex-direction: column;
    width: 1200px;
    height: 1200px;
    position: relative;
}

.gallery-logo-horizontal {
    width: 775px;
    height: 98px;
    filter: invert(1);
}
```

#### 5. 구현 로직
- **파일**: `scripts/generate_pages_dana.py:198-271`
- **핵심 메커니즘**:
  - `img_idx` (0-based): 각 컬러별 이미지 인덱스
  - `img_idx == 2`: 이미지 3 다음에 로고 그룹 1 삽입
  - `img_idx == 5`: 이미지 6 다음에 로고 그룹 2 삽입
  - `img_idx in [3, 4]`: 이미지 4-5는 일반 표시 스킵 (로고 그룹 1에 포함됨)
  - `img_idx in [6, 7]`: 이미지 7-8은 일반 표시 스킵 (로고 그룹 2에 포함됨)

#### 6. 데이터 구조 업데이트
- **products.json** (2025-10-14T13:35:38.153062):
  ```json
  "galleryByColor": {
    "color1": [
      "../assets/images/DN25SPT008_gallery_color1_1.jpg",
      ...
      "../assets/images/DN25SPT008_gallery_color1_12.jpg"
    ],
    "color2": [
      "../assets/images/DN25SPT008_gallery_color2_1.jpg",
      ...
      "../assets/images/DN25SPT008_gallery_color2_5.jpg"
    ]
  }
  ```
- **다운로드 이미지**: DN25SPT008_gallery_color2_5.jpg 추가

#### 7. HTML 구조 예시
```html
<div class="gallery-color-header">베이지</div>
<img src="..." alt="베이지 Gallery 1" class="gallery-image">
<img src="..." alt="베이지 Gallery 2" class="gallery-image">
<img src="..." alt="베이지 Gallery 3" class="gallery-image">

<div class="gallery-logo-group-1">
    <img src="..." alt="Gallery 4" class="gallery-image-4">
    <img src="..." alt="Gallery 5" class="gallery-image-5">
    <img src="[LOGO_BASE64]" alt="DANA&PETA" class="gallery-logo-right">
    <img src="[LOGO_BASE64]" alt="DANA&PETA" class="gallery-logo-left">
</div>

<img src="..." alt="베이지 Gallery 6" class="gallery-image">

<div class="gallery-logo-group-2">
    <img src="..." alt="Gallery 7" class="gallery-image-7">
    <img src="..." alt="Gallery 8" class="gallery-image-8">
    <img src="[LOGO_BASE64]" alt="DANA&PETA" class="gallery-logo-horizontal">
</div>

<img src="..." alt="베이지 Gallery 9" class="gallery-image">
...
```

#### 8. 실행 결과
- **제품**: DN25SPT008
- **Color1 (베이지)**: 12개 이미지 → 로고 그룹 1 + 2 표시
- **Color2 (핑크)**: 5개 이미지 → 로고 그룹 1 표시
- **생성 파일**:
  - `output/2025-10-14/원본/DN25SPT008.html`
  - `output/2025-10-14/에디터블/DN25SPT008_editable.html`
- **파일 크기**: 약 67MB (Base64 이미지 포함)

#### 9. 기술적 특징
- ✅ 컬러별 독립적인 패턴 적용 (다른 이미지 개수 지원)
- ✅ 로고 Base64 인코딩 (단일 HTML 파일)
- ✅ CSS Grid와 Flexbox를 활용한 정밀 배치
- ✅ Transform과 Transform-origin을 사용한 로고 회전
- ✅ Filter invert를 통한 흑백 반전 효과
- ✅ 에디터블 모드에서도 정상 작동

### 2025-10-14: UI 세부 조정 완료 (Phase 2)

#### 1. 히어로 섹션 수직 중앙 정렬
- **문제**: 로고와 서브타이틀이 상단에 치우쳐 있었음
- **해결**:
  - `.hero-section`: `justify-content: space-between` → `center`로 변경
  - `.hero-footer`: `position: absolute`로 하단 고정 (`bottom: 60px`)
  - `transform: translateX(-50%)`로 수평 중앙 정렬
- **파일**: `scripts/generate_pages_dana.py:805, 843-853`
- **결과**: ✅ 로고와 "퀸잇이 제안하는 트렌디 패션"이 이미지 정중앙 배치, "queenit made"는 하단 고정

#### 2. Fabric 테이블 테두리 수정
- **문제**: 테이블 외곽 전체에 테두리가 있었음 (상하좌우 모두)
- **해결**:
  - `border: 3px solid #000000` 제거
  - `border-top: 3px solid #000000` 추가
  - `border-bottom: 3px solid #000000` 추가
- **파일**: `scripts/generate_pages_dana.py:1214-1215`
- **레퍼런스**: `reference/다나앤페타_소재정보.png` 참조
- **결과**: ✅ 좌우 테두리 제거, 상하만 두꺼운 테두리 유지

### 2025-10-14: UI 세부 조정 완료 (Phase 1)

#### 1. "queenit made" 폰트 스타일 수정
- **문제**: Figma에서는 Regular인데 이탤릭으로 표시됨
- **해결**: `.hero-footer`에서 `font-style: italic` 제거
- **파일**: `scripts/generate_pages_dana.py:843-849`
- **결과**: ✅ Regular 폰트로 정상 표시

#### 2. 컬러 라벨 폰트 크기 증가
- **문제**: 상품 컷 우상단 컬러명이 너무 작아서 가독성 저하
- **해결**: `.product-shot-color-label` font-size 16px → 45px
- **파일**: `scripts/generate_pages_dana.py:1104`
- **결과**: ✅ 컬러명이 명확하게 보임

#### 3. Fabric 테이블 외곽 테두리 두께 증가
- **문제**: 테두리가 1px로 너무 얇음
- **해결**: `.fabric-properties-grid` border 1px → 3px
- **파일**: `scripts/generate_pages_dana.py:1210`
- **결과**: ✅ 테두리가 두껍고 명확하게 표시

### 2025-10-13: HTML 디자인 Figma 스펙 완전 재구현

#### 핵심 변경사항
1. **히어로 섹션**: 메인 이미지를 배경으로 사용, 검은색 오버레이(20% opacity), 흰색 텍스트
2. **컨테이너**: 반응형 → 고정폭 1200px
3. **컬러 섹션**: 가로 스와치 레이아웃 (색상 칩 + 이름)
4. **디테일 포인트**: 좌우 레이아웃 (이미지 50% + 텍스트 박스 50%)
5. **갤러리**: 컬러별로 그룹화된 세로 스크롤 레이아웃
6. **FABRIC + PRODUCT INFO**: 단일 통합 섹션
7. **타이포그래피**: Cormorant Garamond, Pretendard 정확 적용

#### 검증 문서
- **파일**: `VERIFICATION_REPORT.md`
- **결과**: 모든 Figma 스펙 정확히 구현됨

### 2025-10-13: Google Sheets 하이퍼링크 추출 기능 구현

- **파일**: `scripts/load_from_sheets.py`
- **기능**:
  - `extract_hyperlinks_from_range()` 메서드 추가
  - Google Sheets API의 `includeGridData=True` 사용
  - 셀의 `hyperlink` 속성 추출
  - 이미지 탭의 URL 하이퍼링크 정상 추출
- **결과**: ✅ 17개 이미지 모두 Google Drive에서 다운로드 완료

### 2025-10-13: 102열 CSV 구조 정확 매핑

- **파일**:
  - `scripts/config.py` - REQUEST_FORM_COLUMNS 완전 재작성
  - `request_form_template.csv` - 실제 헤더로 재생성
  - `scripts/verify_mappings.py` - 검증 스크립트 생성
- **검증**: 모든 102개 컬럼 매핑 확인 완료 ✅

### 데이터 로딩 및 HTML 생성

- **실행 결과** (2025-10-14T13:35:38):
  - 제품 1개 로딩 완료 (DN25SPT008)
  - 이미지 20개 다운로드:
    - 메인 이미지: 1개
    - 컬러 이미지: 2개 (색상 추출 완료)
    - 디테일 포인트: 2개
    - 갤러리: 17개 (베이지 12개, 핑크 5개)
    - 제품샷: 2개
    - 원단 이미지: 1개
  - HTML 파일 생성: 원본/에디터블 (base64 인코딩, 약 67MB)

---

## 🗂️ 프로젝트 구조

```
pb_dana_page_builder/
├── scripts/
│   ├── config.py                      # 설정 파일 (102열 구조 정의) ✅
│   ├── load_from_sheets.py            # Google Sheets 데이터 로더 ✅
│   ├── generate_pages_dana.py         # HTML 생성기 (완전 재작성 완료) ✅
│   ├── verify_mappings.py             # 매핑 검증 스크립트 ✅
│   └── temp_generate_template_columns.py  # 302열 템플릿 생성 헬퍼
├── data/
│   └── products.json                  # 로딩된 제품 데이터 ✅
├── output/
│   ├── assets/images/                 # 다운로드된 이미지들 ✅
│   ├── 2025-10-13/                    # 이전 버전
│   └── 2025-10-14/                    # 최신 버전 ✅
│       ├── 원본/                      # 원본 HTML (DN25SPT008.html)
│       └── 에디터블/                  # 에디터블 HTML (DN25SPT008_editable.html)
├── reference/                         # 레퍼런스 자료 ✅
│   ├── 1.webp                         # 히어로 섹션 레퍼런스
│   ├── 2.webp                         # 제품 소개 + 컬러
│   ├── 3.webp                         # 디테일 포인트
│   ├── 4.webp                         # 갤러리
│   ├── 5.webp                         # 컬러 단품 이미지
│   ├── 6.webp                         # FABRIC INFO
│   ├── 7.webp                         # PRODUCT INFO
│   ├── dana&peta_logo.png             # 브랜드 로고 PNG (16824 bytes)
│   └── 다나앤페타_소재정보.png         # Fabric 테이블 레퍼런스
├── size_images/                       # 사이즈 일러스트레이션
│   ├── 상의.png
│   └── 하의.png
├── request_form_template.csv          # 102열 템플릿 ✅
├── claude.md                          # 프로젝트 상태 문서 (본 파일)
├── VERIFICATION_REPORT.md             # HTML 검증 보고서
└── README.md                          # 프로젝트 설명서
```

---

## 🔧 기술 스택 및 구현 세부사항

### 1. 데이터 소스
- **Google Sheets API**: 제품 데이터 및 이미지 URL 추출
- **Spreadsheet ID**: `1m1f784rij74eSpuHOEOqbAzQu97ZenfLa3QuO-Egjxk`
- **탭 구조**:
  - `요청서` (A2:CX100) - 102열 제품 정보
  - `이미지` (A2:AU100) - 이미지 URL (하이퍼링크)
- **서비스 계정**: `damoa-fb351-2157600c6ca0.json`

### 2. HTML 생성 로직
- **Python 기반**: `generate_pages_dana.py`
- **Base64 인코딩**: 모든 이미지를 data URL로 변환하여 HTML에 임베드
- **템플릿 엔진**: f-string 기반 HTML 생성
- **CSS**: 인라인 CSS (별도 파일 없음)
- **폰트**: Google Fonts CDN 사용
  - Cormorant Garamond (Serif)
  - EB Garamond (Serif)
  - Pretendard (Sans-serif)

### 3. 레이아웃 구조

#### Hero Section (히어로 섹션)
- **높이**: 1565px
- **배경**: 메인 이미지 (`background-image`)
- **오버레이**: `rgba(0, 0, 0, 0.2)` (20% 검은색)
- **로고**: 775px × 98px (PNG, base64)
- **서브타이틀**: "- 퀸잇이 제안하는 트렌디 패션 -" (Pretendard 43px, #FEFEFE)
- **푸터**: "queenit made" (Cormorant Garamond 40px, Regular, #FEFEFE, 하단 고정)

#### Product Info Section (제품 정보 섹션)
- **배경**: #E8E4E0 (베이지)
- **제목**: Pretendard SemiBold 70px
- **구분선**: 975.5px × 1px (#000000)
- **소구점**: 01, 02, 03 번호 + 설명 (45px)
- **MD 코멘트**: 35px 중앙 정렬

#### Color Section (컬러 섹션)
- **배경**: #E8E4E0
- **제목**: "COLOR" (Cormorant Garamond Bold 70px)
- **레이아웃**: 가로 스와치 레이아웃
  - 색상 칩: 200px × 200px (회색 배경 279.24px × 279.24px 내)
  - 컬러명: 47px, Pretendard SemiBold
  - 에디터블 모드: 색상 피커 포함

#### Detail Points Section (디테일 포인트)
- **배경**: #D9D3CE (베이지)
- **배지**: "DETAIL POINT" (타원형, 575px × 175px, Cormorant Garamond Bold 70px)
- **레이아웃**: 좌우 분할
  - 이미지: 500px × 600px
  - 텍스트 박스: 550px × 600px (#F8F5F2 배경)
  - 번호: 60px Pretendard SemiBold
  - 설명: 40px Pretendard Regular

#### Gallery Section (갤러리)
- **배경**: #E8E4E0
- **구조**: 컬러별 그룹화 + 로고 삽입
  - 컬러 헤더: 56px Pretendard Bold
  - 이미지 패턴: 1-3 일반 → 4-5 로고그룹1 → 6 일반 → 7-8 로고그룹2 → 9+ 일반
  - 로고 그룹 1: 2×2 Grid (600px × 600px × 2), 45도 회전 로고 2개
  - 로고 그룹 2: 세로 Stack (1200px × 600px × 2), 가로 로고 1개
  - 로고 효과: `filter: invert(1)` (흑백 반전)
  - 컬러별 독립 패턴: 이미지 개수가 달라도 정상 작동

#### Product Shots (제품 컷)
- **배경**: #E8E4E0
- **이미지 너비**: 994.5px
- **컬러 라벨**: 우상단 오버레이 (45px, Pretendard Bold)

#### Fabric Info + Product Info (원단 정보 + 제품 정보)
- **배경**: #FFFFFF
- **Fabric Image Container**: 600px 높이, 배경 이미지
  - "FABRIC" 라벨: EB Garamond 80px, #FFFFFF
  - 원단 구성: Pretendard 28px
- **Description Box**: #031a13 배경, 흰색 텍스트 (50px)
- **Properties Grid**: 4열 × 5행
  - 외곽 테두리: 상하 3px (#000000), 좌우 없음
  - 헤더 셀: 35px Pretendard SemiBold
  - 선택된 셀: #d9d9d9 배경
- **Product Info**: 가로 레이아웃
  - 왼쪽: 사이즈 일러스트레이션 (539px)
  - 오른쪽: 2열 테이블 (라벨 + 값, 40px)

#### Size Table (사이즈표)
- **너비**: 900px
- **헤더**: #e4e4e4 배경, 30px Pretendard SemiBold
- **셀**: 1px solid #E0E0E0 테두리

---

## 🎨 디자인 스펙

### 타이포그래피
| 요소 | 폰트 | 크기 | 굵기 | 색상 |
|------|------|------|------|------|
| 브랜드 로고 (텍스트) | Cormorant Garamond | 40px | Regular | #FEFEFE |
| 히어로 서브타이틀 | Pretendard | 43px | Medium | #FEFEFE |
| 제품명 | Pretendard | 70px | SemiBold | #000000 |
| 소구점 | Pretendard | 45px | Regular | #000000 |
| MD 코멘트 | Pretendard | 35px | Regular | #000000 |
| 섹션 제목 | Cormorant Garamond | 70px | Bold | #000000 |
| 컬러명 (스와치) | Pretendard | 47px | SemiBold | #000000 |
| 컬러명 (상품컷) | Pretendard | 45px | Bold | #000000 |
| 디테일 번호 | Pretendard | 60px | SemiBold | #000000 |
| 디테일 설명 | Pretendard | 40px | Regular | #000000 |
| 원단 라벨 | EB Garamond | 80px | Bold | #FFFFFF |
| 원단 설명 | Pretendard | 50px | Regular | #FFFFFF |
| Fabric 테이블 | Pretendard | 35px | SemiBold | #000000 |
| Product Info | Pretendard | 40px | SemiBold/Medium | #000000 |
| Size Table | Pretendard | 30px | SemiBold/Regular | #000000 |

### 색상 팔레트
| 색상 | Hex Code | 용도 |
|------|----------|------|
| 검은색 | #000000 | 텍스트, 테두리 |
| 흰색 | #FFFFFF | 배경, 텍스트 |
| 오프화이트 | #FEFEFE | 히어로 텍스트 |
| 베이지 | #E8E4E0 | 섹션 배경 |
| 진한 베이지 | #D9D3CE | 디테일 포인트 배경 |
| 밝은 베이지 | #F8F5F2 | 텍스트 박스 배경 |
| 회색 | #d9d9d9 | 선택된 셀 배경 |
| 연한 회색 | #E0E0E0 | 테두리 |
| 짙은 회색 | #666666 | 보조 텍스트 |
| 밝은 회색 | #999999 | 주의사항 |
| 네이비 | #031a13 | 원단 설명 박스 |
| 검은색 오버레이 | rgba(0,0,0,0.2) | 히어로 배경 |

---

## 📋 Figma 레퍼런스

### Figma 링크
- **메인 디자인**: https://www.figma.com/design/xz6yXxIX4r2gA0TUYOkpS5/
- **히어로 섹션** (node-id: 1-144): 로고 + 서브타이틀 중앙 정렬
- **디테일 포인트** (node-id: 1-148): 좌우 레이아웃
- **갤러리** (node-id: 1-145): 세로 스크롤
- **원단/제품 정보** (node-id: 1-147): 통합 섹션
- **히어로 섹션 로고** (node-id: 56-107): 수직 중앙 정렬 스펙
- **Fabric 테이블** (node-id: 53-101): 5행 × 4열 그리드

### 로컬 레퍼런스 파일
- `reference/1.webp` - 히어로 섹션 (메인 이미지 배경)
- `reference/2.webp` - 제품 소개 + 컬러 섹션
- `reference/3.webp` - 디테일 포인트 (좌우 레이아웃)
- `reference/4.webp` - 갤러리 (세로 스크롤)
- `reference/5.webp` - 컬러 단품 이미지
- `reference/6.webp` - FABRIC INFO + PRODUCT INFO
- `reference/7.webp` - FABRIC INFO + PRODUCT INFO (동일)
- `reference/dana&peta_logo.png` - 브랜드 로고 PNG 파일
- `reference/다나앤페타_소재정보.png` - Fabric 테이블 레퍼런스

---

## 📝 실행 명령어

### 1. Google Sheets에서 데이터 로드
```bash
cd /Users/younghoonjung/ai-project/pb_dana_page_builder
python3 scripts/load_from_sheets.py
```
- Google Sheets에서 제품 데이터 및 이미지 URL 추출
- 이미지 자동 다운로드 (Google Drive)
- `data/products.json` 생성

### 2. HTML 페이지 생성 (전체)
```bash
python3 scripts/generate_pages_dana.py
```
- 모든 제품에 대해 HTML 생성
- `output/2025-10-14/원본/` - 원본 HTML
- `output/2025-10-14/에디터블/` - 에디터블 HTML

### 3. 특정 제품만 생성
```bash
python3 scripts/generate_pages_dana.py --product DN25SPT008
```
- 특정 제품 코드만 생성
- 테스트 및 디버깅에 유용

### 4. Flask 서버 시작 (에디터블 모드 + 익스포트)
```bash
python3 scripts/server.py
```
- Port 5001에서 Flask 서버 실행
- 에디터블 HTML 파일 제공
- HTML/JPG 익스포트 엔드포인트 제공
- 브라우저에서 `http://localhost:5001` 접속

**서버 기능:**
- `/` - 에디터블 파일 목록 표시
- `/editable/{product_code}` - 에디터블 HTML 제공
- `/save-html` - HTML 저장 (POST)
- `/save-jpg` - JPG 저장 (POST)

### 5. 브라우저에서 확인

#### 방법 1: Flask 서버 사용 (권장)
```bash
# 서버 실행 후 브라우저에서
http://localhost:5001
```
- 에디터블 파일 목록에서 클릭하여 열기
- 이미지 편집 후 HTML/JPG 익스포트 가능
- `output/날짜/익스포트/` 폴더에 자동 저장

#### 방법 2: 파일 직접 열기
```bash
# macOS
open "/Users/younghoonjung/ai-project/pb_dana_page_builder/output/2025-10-14/에디터블/DN25SPT008_editable.html"

# 또는 원본 버전
open "/Users/younghoonjung/ai-project/pb_dana_page_builder/output/2025-10-14/원본/DN25SPT008.html"
```
- 직접 열 경우 익스포트 기능 사용 불가 (서버 필요)

---

## 🔍 현재 상태

### ✅ 완료된 기능
1. **데이터 로딩**: Google Sheets API 연동 및 하이퍼링크 추출 ✅
2. **이미지 처리**: Google Drive 이미지 다운로드 및 Base64 인코딩 ✅
3. **HTML 생성**: Figma 스펙 기반 픽셀 퍼펙트 레이아웃 ✅
4. **히어로 섹션**: 로고/서브타이틀 수직 중앙 정렬 ✅
5. **컬러 섹션**: 가로 스와치 레이아웃 ✅
6. **디테일 포인트**: 좌우 분할 레이아웃 ✅
7. **갤러리**: 컬러별 그룹화 + 로고 그룹 삽입 패턴 ✅
8. **갤러리 로고 그룹 1**: 좌우 배치 + 45도 회전 로고 2개 ✅
9. **갤러리 로고 그룹 2**: 상하 배치 + 가로 로고 1개 ✅
10. **제품 컷**: 컬러 라벨 오버레이 (45px) ✅
11. **Fabric 정보**: 원단 이미지 + 설명 + 테이블 (전체 너비 1200px) ✅
12. **Fabric 테이블**: 상하 테두리만 3px, 좌우 테두리 없음 ✅
13. **Product 정보**: 가로 레이아웃 (이미지:테이블 = 30:70 비율, 헤더 4글자 한 줄 표시) ✅
14. **사이즈표**: 동적 컬럼 생성 ✅
15. **타이포그래피**: Figma 스펙 정확 반영 ✅
16. **에디터블 모드**: 브라우저 내 수정 기능 ✅
17. **에디터블 - 히어로 이미지**: 표시 수정 + 줌/팬 편집 활성화 ✅
18. **에디터블 - 페이지 줌**: 30-100% 줌 기능 (기본 60%) ✅
19. **에디터블 - 갤러리 ID**: 컬러별 고유 ID 시스템 ✅
20. **에디터블 - 이미지 메뉴**: 전체 컬러 이미지 드롭다운 표시 ✅
21. **에디터블 - 갤러리 기본값**: 각 컬러 첫 이미지 기본 상태 유지 ✅
22. **에디터블 - 사이즈 이미지 선택**: Product Info 이미지 변경 기능 ✅
23. **에디터블 - 여백 자동 조정**: applyPageZoom에서 container height 동적 계산 ✅
24. **다중 제품 생성**: 2개 제품 동시 로드 및 HTML 생성 ✅
25. **이미지 캐싱**: 60개 이미지 캐시로 빠른 재생성 ✅
26. **Flask 로컬 서버**: 에디터블 HTML 제공 및 익스포트 처리 (Port 5001) ✅
27. **HTML 익스포트**: 서버 기반 자동 저장 (`output/날짜/익스포트/`) ✅
28. **JPG 익스포트**: html2canvas 기반 고해상도 이미지 캡처 및 저장 ✅
29. **녹색 테두리 제거**: JPG 익스포트 시 선택 스타일 임시 제거 ✅
30. **파일명 중복 처리**: 자동 suffix 추가 (_1, _2, ...) ✅

### 🎯 품질 검증
- ✅ Figma 디자인 스펙 100% 일치
- ✅ 레퍼런스 이미지와 픽셀 단위 비교 완료
- ✅ 브라우저 렌더링 테스트 완료
- ✅ 에디터블 모드 동작 확인
- ✅ Base64 이미지 인코딩 정상 작동
- ✅ 타이포그래피 정확성 검증
- ✅ 색상 팔레트 정확성 검증
- ✅ 레이아웃 정렬 및 간격 검증

---

## 📊 데이터 구조

### products.json
```json
{
  "products": [
    {
      "productCode": "DN25SPT008",
      "title": "라인 스판 반밴딩 와이드 슬랙스",
      "mdComment": "평소 66반까지 착용하시는 고객분들께 추천드립니다.",
      "sellingPoints": [
        "깔끔하고 캐주얼한 무드의 반팔 니트",
        "감각적인 포인트가 되어주는 영문 레터링",
        "가볍고 부드러운 원단으로 편안한 착용감 선사"
      ],
      "images": {
        "main_single": "../assets/images/DN25SPT008_main.jpg"
      },
      "colors": [
        {"name": "베이지", "hex": "#cccccc"},
        {"name": "핑크", "hex": "#cccccc"}
      ],
      "detailPoints": [
        {
          "image": "../assets/images/DN25SPT008_detail_point_1.jpg",
          "text": "밑단 컬러 배색 포인트"
        }
      ],
      "galleryByColor": {
        "color1": [
          "../assets/images/DN25SPT008_gallery_color1_1.jpg",
          "../assets/images/DN25SPT008_gallery_color1_2.jpg",
          "../assets/images/DN25SPT008_gallery_color1_3.jpg",
          "../assets/images/DN25SPT008_gallery_color1_4.jpg",
          "../assets/images/DN25SPT008_gallery_color1_5.jpg",
          "../assets/images/DN25SPT008_gallery_color1_6.jpg",
          "../assets/images/DN25SPT008_gallery_color1_7.jpg",
          "../assets/images/DN25SPT008_gallery_color1_8.jpg",
          "../assets/images/DN25SPT008_gallery_color1_9.jpg",
          "../assets/images/DN25SPT008_gallery_color1_10.jpg",
          "../assets/images/DN25SPT008_gallery_color1_11.jpg",
          "../assets/images/DN25SPT008_gallery_color1_12.jpg"
        ],
        "color2": [
          "../assets/images/DN25SPT008_gallery_color2_1.jpg",
          "../assets/images/DN25SPT008_gallery_color2_2.jpg",
          "../assets/images/DN25SPT008_gallery_color2_3.jpg",
          "../assets/images/DN25SPT008_gallery_color2_4.jpg",
          "../assets/images/DN25SPT008_gallery_color2_5.jpg"
        ]
      },
      "productShots": [
        "../assets/images/DN25SPT008_shot_color1.jpg",
        "../assets/images/DN25SPT008_shot_color2.jpg"
      ],
      "fabricInfo": {
        "image": "../assets/images/DN25SPT008_fabric.jpg",
        "composition": "폴리에스터100%",
        "description": "인조섬유 중 가장 많이 사용되는 폴리에스터 원단입니다.\n가볍고 부드러우며 구김이 가지 않는 소재입니다.",
        "properties": {
          "transparency": "없음",
          "stretch": "없음",
          "lining": "없음",
          "thickness": "얇음",
          "season": "봄/가을"
        }
      },
      "productInfo": {
        "productName": "라인 스판 반밴딩 와이드 슬랙스",
        "colorName": "베이지, 핑크",
        "sizeName": "FREE",
        "fabric": "",
        "washingInfo": "",
        "origin": ""
      },
      "sizeInfo": {
        "topSizes": [
          {
            "name": "FREE",
            "shoulder": "120",
            "chest": "120",
            "hem": "104",
            "sleeveLength": "19",
            "sleeveOpening": "50",
            "totalLength": "63",
            "optional": ""
          }
        ],
        "bottomSizes": []
      },
      "sizeImage": "상의"
    }
  ],
  "metadata": {
    "totalCount": 1,
    "lastUpdated": "2025-10-14T13:35:38.153062",
    "version": "1.0.0",
    "brand": "DANA&PETA"
  }
}
```

---

## ⚠️ 알려진 이슈 및 제한사항

### 해결 완료
1. ✅ CSV 구조 불일치 (112열 → 102열 수정)
2. ✅ 이미지 URL이 텍스트로만 표시 (하이퍼링크 추출 구현)
3. ✅ JavaScript 문법 오류 (line 442 수정)
4. ✅ HTML 레이아웃이 Figma 디자인과 다름 (완전 재작성)
5. ✅ 히어로 섹션 로고/서브타이틀 정렬 (수직 중앙 정렬)
6. ✅ "queenit made" 폰트 스타일 (이탤릭 제거)
7. ✅ 컬러 라벨 폰트 크기 (16px → 45px)
8. ✅ Fabric 테이블 테두리 (좌우 제거, 상하 3px)
9. ✅ 히어로 이미지 표시 문제 (CSS 우선순위 수정)
10. ✅ 히어로 이미지 편집 불가 (overlay pointer-events 수정)
11. ✅ 갤러리 ID 중복 (컬러별 고유 ID 시스템)
12. ✅ 이미지 메뉴 불완전 (전체 컬러 이미지 표시)
13. ✅ 로고 그룹 레이아웃 깨짐 (CSS 셀렉터 수정)
14. ✅ Fabric 이미지 너비 (padding 제거로 1200px 달성)
15. ✅ Product Info 비율 (30:70 비율 조정)
16. ✅ Product Info 헤더 너비 (4글자 한 줄 표시)
17. ✅ 갤러리 첫 이미지 기본값 (localStorage 로드 제외)

### 현재 제한사항
- 파일 크기: Base64 인코딩으로 인해 HTML 파일 크기가 큼 (약 5-10MB)
  - 해결 방법: 필요 시 이미지를 별도 파일로 분리 가능
- 반응형: 현재 데스크톱(1200px) 고정폭 레이아웃
  - 해결 방법: 필요 시 미디어 쿼리 추가 가능
- 폰트: Google Fonts CDN 의존
  - 해결 방법: 필요 시 로컬 호스팅 가능

---

## 💡 다음 단계 (Optional)

### 1. 데이터 개선
- Google Sheets에서 추가 제품 데이터 입력
- `sizeInfo` 필드 완성 (현재 일부 빈 값)
- `productInfo` 필드 완성 (현재 일부 빈 값)

### 2. 추가 제품 생성
```bash
python3 scripts/generate_pages_dana.py --product [OTHER_PRODUCT_CODE]
```

### 3. 프로덕션 최적화 (필요 시)
- 이미지를 별도 파일로 추출하여 파일 크기 감소
- CSS/HTML 압축 (Minification)
- 폰트 로컬 호스팅 (CDN 의존성 제거)
- 반응형 디자인 추가 (모바일 대응)
- LazyLoading 구현 (이미지 로딩 최적화)

### 4. 자동화 개선
- GitHub Actions 연동 (자동 빌드)
- Google Sheets → HTML 자동 생성 파이프라인
- 이미지 최적화 자동화 (압축, 리사이징)

---

## 📞 리소스 및 연락처

### 프로젝트 정보
- **프로젝트 경로**: `/Users/younghoonjung/ai-project/pb_dana_page_builder`
- **Google Sheets**: https://docs.google.com/spreadsheets/d/1m1f784rij74eSpuHOEOqbAzQu97ZenfLa3QuO-Egjxk
- **Figma 디자인**: https://www.figma.com/design/xz6yXxIX4r2gA0TUYOkpS5/
- **브랜드**: DANA&PETA

### 주요 파일
- **메인 생성기**: `scripts/generate_pages_dana.py`
- **데이터 로더**: `scripts/load_from_sheets.py`
- **설정 파일**: `scripts/config.py`
- **제품 데이터**: `data/products.json`
- **검증 보고서**: `VERIFICATION_REPORT.md`

### 출력 파일 위치
- **원본 HTML**: `output/2025-10-14/원본/DN25SPT008.html`
- **에디터블 HTML**: `output/2025-10-14/에디터블/DN25SPT008_editable.html`

---

## 🎯 성공 기준 (모두 달성 ✅)

HTML 페이지가 레퍼런스 이미지 및 Figma 디자인과 **픽셀 단위로 일치**:
- ✅ 컨테이너 너비 1200px
- ✅ 히어로 섹션 배경 이미지 (1565px, 전체 섹션 채움)
- ✅ 로고 및 서브타이틀 수직 중앙 정렬
- ✅ "queenit made" Regular 폰트 (하단 고정)
- ✅ 컬러 섹션 가로 스와치 레이아웃
- ✅ 디테일 포인트 좌우 분할 레이아웃
- ✅ 갤러리 컬러별 그룹화 + 로고 그룹 패턴
- ✅ 갤러리 로고 그룹 1: 좌우 배치 + 45도 회전 로고 2개
- ✅ 갤러리 로고 그룹 2: 상하 배치 + 가로 로고 1개
- ✅ 컬러별 독립 패턴 (이미지 개수 다르게 지원)
- ✅ 제품 컷 컬러 라벨 (45px)
- ✅ FABRIC INFO + PRODUCT INFO 통합 섹션
- ✅ Fabric 이미지 전체 너비 1200px
- ✅ Fabric 테이블 상하 테두리만 3px
- ✅ Product Info 이미지:테이블 30:70 비율
- ✅ Product Info 헤더 4글자 한 줄 표시
- ✅ 타이포그래피 정확히 적용 (Cormorant Garamond, Pretendard)
- ✅ 색상 팔레트 정확히 적용
- ✅ Base64 이미지 인코딩 정상 작동

에디터블 모드 기능 완성:
- ✅ 히어로 이미지 줌/팬 편집 (패널 + 드래그)
- ✅ 페이지 줌 기능 (30-100%, 기본 60%)
- ✅ 갤러리 컬러별 고유 ID 시스템
- ✅ 전체 컬러 이미지 드롭다운 메뉴
- ✅ 갤러리 첫 이미지 기본값 유지
- ✅ 사이즈 이미지 선택 기능
- ✅ LocalStorage 설정 영속성

---

## 📚 참고 문서

### 내부 문서
- `VERIFICATION_REPORT.md` - HTML 검증 보고서
- `README.md` - 프로젝트 설명서
- `request_form_template.csv` - 102열 CSV 템플릿
- `claude.md` - 프로젝트 상태 문서 (본 파일)

### 외부 리소스
- [Google Sheets API Documentation](https://developers.google.com/sheets/api)
- [Figma Dev Mode](https://www.figma.com/dev-mode/)
- [Google Fonts](https://fonts.google.com/)

---

## 🎨 갤러리 로고 그룹 시각적 설명

### 로고 그룹 1 (이미지 4-5)
```
┌─────────────────────────────┐
│ 이미지 4    │  /로고 (45°) │
│ (600×600)   │               │
├─────────────┼───────────────┤
│  로고 (-45°)│  이미지 5     │
│             │  (600×600)    │
└─────────────┴───────────────┘
```

### 로고 그룹 2 (이미지 7-8)
```
┌─────────────────────────────┐
│      이미지 7 (1200×600)    │
├─────────────────────────────┤
│   ─── 로고 (775×98) ───     │
├─────────────────────────────┤
│      이미지 8 (1200×600)    │
└─────────────────────────────┘
```

---

*이 문서는 다음 세션에서 즉시 작업을 이어갈 수 있도록 최신 상태로 유지됩니다.*
*최종 업데이트: 2025-10-15 (익스포트 플래튼 파이프라인 적용)* 

---

## 📝 에디터블 모드 상세 기능 (2025-10-14 추가)

### 1. 컨트롤 패널 구조
에디터블 HTML에는 우측 상단에 고정된 컨트롤 패널이 있습니다:

```
┌─────────────────────────────┐
│ 🎨 Image Crop Editor        │
├─────────────────────────────┤
│ 🔍 페이지 줌                 │
│ [========|====] 60%          │
├─────────────────────────────┤
│ 📐 사이즈 이미지 선택        │
│ [드롭다운: 상의 ▼]          │
├─────────────────────────────┤
│ 🖼️ 편집할 이미지 선택       │
│ [드롭다운 ▼]                │
├─────────────────────────────┤
│ 📊 이미지 조정 (X/Y/Scale)  │
│ 가로 위치: [====|====] 100% │
│ 세로 위치: [====|====] 100% │
│ 확대/축소: [====|====] 100% │
├─────────────────────────────┤
│ [초기화] [자동저장 ✓]       │
└─────────────────────────────┘
```

### 2. 페이지 줌 기능
- **목적**: 1200px 넓이의 페이지 전체를 축소하여 한 눈에 파악
- **범위**: 30% ~ 100%
- **기본값**: 60% (페이지가 720px로 표시)
- **단축키**: 마우스 휠로도 조절 가능 (Ctrl 누른 상태)
- **저장**: localStorage에 자동 저장
- **실제 픽셀**: 변경되지 않음 (CSS transform만 적용)

### 3. 이미지 편집 기능
각 이미지마다 다음 조작이 가능합니다:

#### 패널 슬라이더 방식
- 가로 위치 슬라이더: 0% ~ 200% (기본 100%)
- 세로 위치 슬라이더: 0% ~ 200% (기본 100%)
- 확대/축소 슬라이더: 10% ~ 300% (기본 100%)

#### 직접 조작 방식
- **드래그**: 이미지 위에서 클릭 + 드래그로 위치 이동
- **휠**: 마우스 휠로 확대/축소

#### 초기화
- "초기화" 버튼 클릭 시 선택된 이미지만 기본값으로 복원
- 히어로, 제품샷, 패브릭, 갤러리 첫 이미지는 항상 기본값

### 4. 갤러리 이미지 ID 규칙
- **히어로**: `hero`
- **디테일 포인트**: `detailPoint1`, `detailPoint2`
- **갤러리**: `gallery_color{컬러번호}_{이미지번호}`
  - 예: `gallery_color1_1` (베이지 첫 번째)
  - 예: `gallery_color2_5` (핑크 다섯 번째)
- **로고 그룹**: 이미지 4,5,7,8은 갤러리 카운트에서 제외
- **제품샷**: `shot1`, `shot2`
- **패브릭**: `fabric`

### 5. 사이즈 이미지 선택 기능
Product Info 섹션의 왼쪽 이미지를 변경할 수 있습니다:

#### 사용 가능한 이미지
1. 상의.png (기본값 예시)
2. 팬츠.png
3. 스커트-H라인.png
4. 스커트-플레어.png
5. 아우터.png
6. 원피스.png
7. 점프수트.png

#### 동작 방식
- 드롭다운에서 선택 → 이미지 즉시 교체
- 선택값은 localStorage에 자동 저장
- 다음 방문 시 마지막 선택 이미지로 복원
- 기본값은 `products.json`의 `sizeImage` 필드

### 6. LocalStorage 저장 구조
```json
{
  "hero": {"x": 100, "y": 100, "scale": 100},
  "detailPoint1": {"x": 120, "y": 80, "scale": 150},
  "gallery_color1_2": {"x": 90, "y": 110, "scale": 90},
  "shot1": {"x": 100, "y": 100, "scale": 100},
  "fabric": {"x": 100, "y": 100, "scale": 100},
  "pageZoom": 60,
  "sizeImage": "상의"
}
```

### 7. 자동 저장
다음 작업 시 자동으로 localStorage에 저장됩니다:
- 슬라이더 조작 (debounce 500ms)
- 드래그 종료
- 휠 스크롤 종료 (debounce 300ms)
- 페이지 줌 변경
- 사이즈 이미지 선택 변경

### 8. 브라우저 호환성
- **권장**: Chrome, Edge (최신 버전)
- **지원**: Firefox, Safari
- **필수**: localStorage 지원 브라우저
- **선택**: Ctrl+휠 줌은 일부 브라우저에서 제한될 수 있음

### 9. 사용 팁
1. **전체 보기**: 페이지 줌을 40-50%로 줄여서 전체 레이아웃 확인
2. **정밀 편집**: 페이지 줌을 100%로 올려서 세부 조정
3. **빠른 복구**: 실수 시 "초기화" 버튼으로 이미지 복원
4. **비교**: 원본 HTML과 에디터블 HTML을 탭으로 열어 비교
5. **저장**: 브라우저 캐시 삭제 전 필요 시 스크린샷 백업

### 10. 익스포트 플래튼 파이프라인 (2025-10-15)
- HTML/JPG 내보내기 시 각 프레임/크롭 설정을 캔버스에 재렌더링해 Base64 PNG로 교체
- html2canvas가 `object-fit`, `translate`, `scale` 조합을 해석하지 못하던 이슈를 우회
- 로고 그룹·히어로·디테일 포인트·패브릭 등 비율 중요 섹션에서도 HTML ⇔ JPG 결과 동일
- 내보내기 후 DOM은 자동 복원되므로 편집 세션, LocalStorage 상태에는 영향 없음

---
