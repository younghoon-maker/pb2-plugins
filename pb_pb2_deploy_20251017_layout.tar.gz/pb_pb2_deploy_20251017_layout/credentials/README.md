# Credentials 폴더

이 폴더는 Google Sheets API 접근에 필요한 서비스 계정 인증 파일을 저장하는 곳입니다.

---

## 📁 파일 위치

```
credentials/
└── service-account.json    # Google Cloud 서비스 계정 키 파일
```

---

## 🔐 서비스 계정 키 파일 생성

### 1. Google Cloud Console에서 다운로드

1. [Google Cloud Console](https://console.cloud.google.com/) 접속
2. **API 및 서비스** → **사용자 인증 정보** 클릭
3. 기존 서비스 계정 선택 (또는 새로 생성)
4. **키** 탭 클릭
5. **키 추가** → **새 키 만들기** → **JSON** 선택
6. 다운로드된 파일을 `service-account.json`으로 이름 변경
7. 이 폴더(`credentials/`)에 복사

**전체 설정 가이드**: [../docs/SETUP_GUIDE.md](../docs/SETUP_GUIDE.md)

### 2. 파일 확인

```bash
# 파일 존재 확인
ls credentials/service-account.json

# 파일 권한 설정 (읽기 전용, 보안 강화)
chmod 600 credentials/service-account.json

# JSON 유효성 검사
python3 -c "import json; print(json.load(open('credentials/service-account.json')))"
```

---

## 📤 Google Sheet 공유 설정

서비스 계정이 Google Sheets에 접근하려면 **반드시 공유 설정**이 필요합니다.

### 1. 서비스 계정 이메일 확인

```bash
# macOS/Linux
grep client_email credentials/service-account.json

# 또는 jq 사용
jq -r '.client_email' credentials/service-account.json
```

**출력 예시**:
```
"pb-pb2-sheets-reader@project-id.iam.gserviceaccount.com"
```

### 2. Google Sheets 공유

1. Google Sheets 문서 열기
2. 우측 상단 **공유** 버튼 클릭
3. 서비스 계정 이메일 입력 (위에서 확인한 이메일)
4. 권한 설정:
   - **뷰어** (읽기 전용) - 권장 ✅
   - **편집자** (읽기/쓰기) - 필요 시에만
5. **전송** 클릭 (알림 전송 체크박스는 해제 가능)

---

## 🔒 보안 권장사항

### ✅ DO (권장사항)

- **Git에서 제외**: `.gitignore`에 `credentials/` 추가 (이미 설정됨)
- **파일 권한 제한**: `chmod 600 service-account.json` (소유자만 읽기/쓰기)
- **최소 권한 원칙**: Google Sheets에는 **뷰어** 권한만 부여
- **정기 키 회전**: 6개월마다 새 키 생성 권장
- **로컬 저장**: 서비스 계정 키는 로컬 컴퓨터에만 보관

### ❌ DON'T (금지사항)

- **Git 커밋 금지**: 서비스 계정 키를 절대 Git에 커밋하지 않음
- **하드코딩 금지**: 소스 코드에 키 내용 복사 금지
- **공개 공유 금지**: 이메일, 메신저로 키 파일 전송 금지
- **공개 폴더 금지**: Dropbox, Google Drive 등 공개 폴더에 저장 금지

---

## 🚨 문제 해결

### 1. `FileNotFoundError: service-account.json`

**원인**: 파일이 없거나 경로가 잘못됨

**해결**:
```bash
# 현재 위치 확인
pwd

# 파일 존재 확인
ls credentials/service-account.json

# 없으면 Google Cloud Console에서 다시 다운로드
```

### 2. `403 Forbidden: The caller does not have permission`

**원인**: Google Sheets가 서비스 계정과 공유되지 않음

**해결**:
1. Google Sheets 문서 열기
2. 우측 상단 **공유** 클릭
3. 서비스 계정 이메일 추가 (뷰어 권한)
4. 전송

### 3. `Invalid JSON in credentials file`

**원인**: JSON 파일이 손상되었거나 잘못된 형식

**해결**:
```bash
# JSON 유효성 검사
python3 -c "import json; print(json.load(open('credentials/service-account.json')))"

# 오류 발생 시 Google Cloud Console에서 새 키 다운로드
```

### 4. `Permission denied when reading file`

**원인**: 파일 권한 문제

**해결**:
```bash
# 파일 권한 확인
ls -l credentials/service-account.json

# 읽기 권한 추가
chmod 600 credentials/service-account.json
```

---

## 📝 환경 변수 설정

`.env` 파일에 서비스 계정 파일 경로 설정:

```bash
# .env
GOOGLE_SERVICE_ACCOUNT_FILE=credentials/service-account.json
```

**상대 경로 사용 권장**: 프로젝트 루트 기준

---

## 🔍 JSON 파일 구조

`service-account.json` 파일은 다음과 같은 구조를 가집니다:

```json
{
  "type": "service_account",
  "project_id": "your-project-id",
  "private_key_id": "xxxxxxxxxx",
  "private_key": "-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n",
  "client_email": "service-account-name@project-id.iam.gserviceaccount.com",
  "client_id": "123456789",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/..."
}
```

**중요 필드**:
- `client_email`: Google Sheets 공유 시 사용할 이메일
- `private_key`: API 인증에 사용되는 비밀키 (절대 공개하지 말 것)

---

## 📚 관련 문서

- **설정 가이드**: [../docs/SETUP_GUIDE.md](../docs/SETUP_GUIDE.md)
- **사용 가이드**: [../docs/USAGE_GUIDE.md](../docs/USAGE_GUIDE.md)
- **Google Sheets API 공식 문서**: https://developers.google.com/sheets/api

---

**최종 업데이트**: 2025-10-16
**작성자**: MoAI-ADK
