# Changelog

All notable changes to pb_pb2_new_page project.

---

## [v0.1.2] - 2025-10-17

### 🎨 Layout Fixes
- **Lifestyle Gallery**: Fixed image height ratio (788px → 1394px)
  - Now matches hero image aspect ratio (1.338 ≈ 4:3)
  - Gallery container width: 1042px
  - Calculated height: 1042px × 1.338 = 1394px
  - Modified: `scripts/generate_final_html.py` lines 343, 352

### 📊 Data Model Enhancements
- **ProductData**: Added `product_description` field with bold formatting support
- **FabricInfo**: Added `fabric_image` field (optional)
- **ModelInfo**: Added `model_image` field (optional)
- Modified: `src/models/product_data.py`

### 🔧 Google Sheets Integration
- **Drive API**: Added Google Drive image download support
  - New method: `SheetsLoader.download_image()`
  - Drive URL parsing: `_extract_drive_file_id()`
  - Scopes updated: `drive.readonly` added
- **Text Formatting**: Extract bold/italic formatting from Google Sheets cells
  - New method: `SheetsLoader.extract_text_formatting()`
  - Returns `textFormatRuns` metadata
- Modified: `src/sheets_loader/loader.py` (+115 lines)

### 🎯 Color Extraction
- **K-means Integration**: Automatic HEX code extraction from color images
  - `ColorExtractor` integration in `ProductDataBuilder`
  - Fallback when HEX code missing in Google Sheets
- Modified: `src/sheets_loader/product_builder.py`

### 🚀 Scripts & Output
- Successfully generated: `VD25FTS002_editable_v4.html` (51.4 MB)
  - Product: 퍼피 프린팅 라운드 티셔츠
  - 2 colors, 10 gallery images, 3 detail points
- Fixed: Editable HTML image default display bug

### 📦 Deployment
- Package: `pb_pb2_deploy_20251017_enhanced.tar.gz`

---

## [v0.1.1] - 2025-10-16

### 🎨 Layout Optimization
- Hero section white background optimized to 300px
- V4.6 changelog documentation

### 📦 Deployment
- Package: `pb_pb2_deploy_20251017_layout.tar.gz`

---

## [v0.1.0] - 2025-10-16

### 🚀 Initial Release
- **SPEC-SHEETS-001**: Google Sheets 292-column data loading (completed)
- **TDD Implementation**: 20 tests passed (GREEN phase)
- **K-means Color Extraction**: `color_extractor.py` implementation
- **Pydantic Models**: ProductData, ColorVariant, DetailPoint, FabricInfo, etc.

### 📋 Data Pipeline
- Google Sheets API v4 integration
- Service Account authentication
- 292 columns → ProductData model transformation
- Hyperlink extraction (`includeGridData=True`)
- Empty value handling (`-`, `N/A`, `#N/A`, `#REF!`)

### 🏗️ Project Structure
- `src/sheets_loader/`: 9 files (loader, builder, mapping, extractor, utils)
- `src/models/`: ProductData and related models
- `templates/`: Jinja2 templates (base + 12 sections)
- `scripts/`: V4 generation scripts (editable, batch, final)

### 📚 Documentation
- README.md: Quick start guide
- SETUP_GUIDE.md: Google Cloud setup
- USAGE_GUIDE.md: 4-step workflow
- GOOGLE_SHEETS_SCHEMA.md: 292 columns structure

### 📦 Deployment
- Initial project setup with MoAI-ADK SPEC-First TDD

---

## Legend

- 🎨 **Layout/Design**: Visual and styling changes
- 📊 **Data**: Data model and structure changes
- 🔧 **Integration**: API and external service integration
- 🎯 **Features**: New functionality
- 🚀 **Scripts**: Script and automation improvements
- 📦 **Deployment**: Package and release
- 📚 **Documentation**: Documentation updates
- 🐛 **Fixes**: Bug fixes

---

**Format**: [Semantic Versioning](https://semver.org/)
- **MAJOR**: Breaking changes
- **MINOR**: New features (backward compatible)
- **PATCH**: Bug fixes and improvements
