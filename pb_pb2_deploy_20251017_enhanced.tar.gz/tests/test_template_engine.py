# @TEST:HTML-001 | SPEC: .moai/specs/SPEC-HTML-001/spec.md

"""TemplateEngine 테스트

Jinja2 템플릿 렌더링을 테스트합니다.
"""

import pytest

from src.models.design_spec import Section


def test_render_base_template() -> None:
    """기본 HTML 골격 템플릿 렌더링 테스트"""
    from src.template_engine import TemplateEngine

    engine = TemplateEngine()
    context = {
        "canvas_width": 1082,
        "canvas_height": 25520,
        "sections_html": "<div>Test</div>",
        "css": "body { margin: 0; }",
    }

    html = engine.render("base.html.jinja2", context)

    assert "<html" in html  # <html lang="ko">도 포함
    assert "<head>" in html
    assert "<body>" in html
    assert "Pretendard" in html  # 웹폰트 확인
    assert "1082" in html  # 캔버스 너비
    assert "25520" in html  # 캔버스 높이


def test_render_section_template() -> None:
    """섹션별 템플릿 렌더링 테스트"""
    from src.template_engine import TemplateEngine

    engine = TemplateEngine()
    section = Section(
        id="1:159",
        name="Product Hero",
        figma_group="Group 10",
        x=24,
        y=180,
        width=1033,
        height=1749,
    )

    html = engine.render_section("product_hero", section)

    assert '<div class="section section--product-hero"' in html
    assert 'data-section-id="1:159"' in html


def test_template_not_found() -> None:
    """존재하지 않는 템플릿 에러 처리"""
    from jinja2.exceptions import TemplateNotFound

    from src.template_engine import TemplateEngine

    engine = TemplateEngine()

    with pytest.raises(TemplateNotFound):
        engine.render("nonexistent.html.jinja2", {})


def test_get_base_template() -> None:
    """기본 템플릿 경로 조회"""
    from src.template_engine import TemplateEngine

    engine = TemplateEngine()

    template_name = engine.get_base_template()

    assert template_name == "base.html.jinja2"


def test_template_engine_custom_directory() -> None:
    """커스텀 템플릿 디렉토리 지정"""
    from src.template_engine import TemplateEngine

    engine = TemplateEngine(template_dir="templates")

    assert engine.template_dir == "templates"
