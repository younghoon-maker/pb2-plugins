# @TEST:HTML-001 | SPEC: .moai/specs/SPEC-HTML-001/spec.md

"""LayoutRenderer 테스트

픽셀 정확도 검증, CSS 생성을 테스트합니다.
"""

from src.models.design_spec import DesignSpec, Section


def test_render_section_css_product_hero() -> None:
    """Product Hero 섹션 CSS 스타일 생성 테스트"""
    from src.layout_renderer import LayoutRenderer

    section = Section(
        id="1:159",
        name="Product Hero",
        figma_group="Group 10",
        x=24,
        y=180,
        width=1033,
        height=1749,
    )
    renderer = LayoutRenderer()

    css = renderer.render_section_css(section)

    assert "position: absolute;" in css
    assert "left: 24px;" in css
    assert "top: 180px;" in css
    assert "width: 1033px;" in css
    assert "height: 1749px;" in css


def test_validate_layout_within_tolerance() -> None:
    """레이아웃 오차가 ±2px 이내이면 None 반환"""
    from src.layout_renderer import LayoutRenderer

    section = Section(
        id="1:159",
        name="Product Hero",
        figma_group="Group 10",
        x=24,
        y=180,
        width=1033,
        height=1749,
    )
    renderer = LayoutRenderer(pixel_tolerance=2)

    # 오차 없음
    error = renderer.validate_layout(section, expected_x=24, expected_y=180)
    assert error is None


def test_validate_layout_exceeds_tolerance() -> None:
    """레이아웃 오차가 ±2px 초과이면 오차 리포트 반환"""
    from src.layout_renderer import LayoutRenderer

    section = Section(
        id="1:159",
        name="Product Hero",
        figma_group="Group 10",
        x=29,  # +5px 오차
        y=185,  # +5px 오차
        width=1033,
        height=1749,
    )
    renderer = LayoutRenderer(pixel_tolerance=2)

    error = renderer.validate_layout(section, expected_x=24, expected_y=180)
    assert error is not None
    assert error["section"] == "Product Hero"
    assert error["diff"] >= 5
    assert error["exceeds_tolerance"] is True


def test_render_css_with_all_sections() -> None:
    """전체 CSS 생성 (10개 섹션)"""
    from src.layout_renderer import LayoutRenderer

    spec = DesignSpec(
        width=1082,
        height=25520,
        sections=[
            Section(
                id="1:159",
                name="Product Hero",
                figma_group="Group 10",
                x=24,
                y=180,
                width=1033,
                height=1749,
            ),
            Section(
                id="1:96",
                name="Color Variants",
                figma_group="Group 1",
                x=0,
                y=1996,
                width=1082,
                height=1159,
            ),
            Section(
                id="1:97",
                name="Lifestyle Gallery",
                figma_group="Group 2",
                x=0,
                y=3222,
                width=1082,
                height=2487,
            ),
            Section(
                id="1:98",
                name="Material Detail",
                figma_group="Group 3",
                x=0,
                y=5776,
                width=1082,
                height=2148,
            ),
            Section(
                id="1:99",
                name="Color Selector",
                figma_group="Group 4",
                x=0,
                y=7991,
                width=1082,
                height=2729,
            ),
            Section(
                id="1:100",
                name="Product Info",
                figma_group="Group 5",
                x=0,
                y=10787,
                width=1082,
                height=4257,
            ),
            Section(
                id="1:101",
                name="Care Instructions",
                figma_group="Group 6",
                x=0,
                y=15111,
                width=1082,
                height=2516,
            ),
            Section(
                id="1:102",
                name="Model Info",
                figma_group="Group 7",
                x=0,
                y=17694,
                width=1082,
                height=1544,
            ),
            Section(
                id="1:103",
                name="Size Guide",
                figma_group="Group 8",
                x=0,
                y=19305,
                width=1082,
                height=2954,
            ),
            Section(
                id="1:104",
                name="Size Chart",
                figma_group="Group 9",
                x=0,
                y=22326,
                width=1082,
                height=3194,
            ),
        ],
    )
    renderer = LayoutRenderer()

    css = renderer.render_css(spec)

    assert ":root {" in css
    assert "--canvas-width: 1082px;" in css
    assert "--canvas-height: 25520px;" in css
    assert ".section--product-hero {" in css
    assert ".section--color-variants {" in css


def test_render_section_css_with_special_characters() -> None:
    """섹션명에 특수문자 포함 시 CSS 클래스명 변환 테스트"""
    from src.layout_renderer import LayoutRenderer

    section = Section(
        id="1:200",
        name="Product Info & Details",  # & 특수문자
        figma_group="Group 11",
        x=0,
        y=0,
        width=1082,
        height=1000,
    )
    renderer = LayoutRenderer()

    css = renderer.render_section_css(section)

    # 특수문자는 하이픈으로 변환되어야 함
    assert ".section--product-info" in css or ".section--product-info-details" in css
