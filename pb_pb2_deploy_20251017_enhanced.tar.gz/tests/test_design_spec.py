# @TEST:FIGMA-001 | SPEC: .moai/specs/SPEC-FIGMA-001/spec.md

"""Section 및 DesignSpec 데이터 모델 테스트

Pydantic 기반 검증 규칙을 테스트합니다:
- 필수 필드 검증
- 좌표/크기 제약 검증 (x, y >= 0, width, height > 0)
- 섹션 개수 검증 (정확히 10개)
- JSON 직렬화
"""

import pytest
from pydantic import ValidationError


def test_section_model_requires_all_fields():
    """Section 모델은 모든 필수 필드를 요구해야 한다"""
    from src.models.design_spec import Section

    with pytest.raises(ValidationError):
        Section(id="1:159")  # name 누락


def test_section_coordinates_must_be_non_negative():
    """Section의 x, y 좌표는 음수일 수 없다"""
    from src.models.design_spec import Section

    with pytest.raises(ValidationError):
        Section(
            id="1:159",
            name="Product Hero",
            figma_group="Group 10",
            x=-10,  # 음수
            y=0,
            width=1033,
            height=1749
        )


def test_section_dimensions_must_be_positive():
    """Section의 width, height는 0보다 커야 한다"""
    from src.models.design_spec import Section

    with pytest.raises(ValidationError):
        Section(
            id="1:159",
            name="Product Hero",
            figma_group="Group 10",
            x=24,
            y=180,
            width=0,  # 0은 불가
            height=1749
        )


def test_design_spec_requires_exactly_10_sections():
    """DesignSpec은 정확히 10개 섹션을 요구해야 한다"""
    from src.models.design_spec import DesignSpec, Section

    with pytest.raises(ValidationError):
        DesignSpec(sections=[])  # 섹션 부족


def test_design_spec_to_json_serialization():
    """DesignSpec은 JSON으로 직렬화 가능해야 한다"""
    from src.models.design_spec import DesignSpec, Section

    sections = [
        Section(
            id=f"1:{i}",
            name=f"Section {i}",
            figma_group=f"Group {i}",
            x=0,
            y=i * 100,
            width=1080,
            height=100
        )
        for i in range(10)
    ]

    spec = DesignSpec(sections=sections)
    json_str = spec.to_json()

    assert isinstance(json_str, str)
    assert "sections" in json_str
