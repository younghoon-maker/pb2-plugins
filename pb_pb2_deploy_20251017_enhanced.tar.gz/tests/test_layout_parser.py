# @TEST:FIGMA-001 | SPEC: .moai/specs/SPEC-FIGMA-001/spec.md

"""LayoutParser 테스트 스위트

TEST-FIGMA-001: Figma JSON 파싱 기능 검증
"""

import json
import pytest
from pathlib import Path
from pydantic import ValidationError

from src.models.design_spec import DesignSpec, Section
from src.parsers.layout_parser import parse_layout


@pytest.fixture
def mock_figma_data():
    """Mock Figma JSON 데이터 로딩"""
    fixture_path = Path(__file__).parent / "fixtures" / "1-95.json"
    with open(fixture_path, "r", encoding="utf-8") as f:
        return json.load(f)


class TestLayoutParser:
    """TEST-FIGMA-001: LayoutParser 기능 검증"""

    def test_parse_layout_returns_design_spec(self, mock_figma_data):
        """TEST-HAPPY-001: parse_layout이 DesignSpec 인스턴스를 반환하는지 확인"""
        result = parse_layout(mock_figma_data)
        assert isinstance(result, DesignSpec)

    def test_parse_layout_extracts_canvas_dimensions(self, mock_figma_data):
        """TEST-HAPPY-002: 캔버스 너비/높이 파싱 확인"""
        result = parse_layout(mock_figma_data)
        assert result.width == 1080
        assert result.height == 25520

    def test_parse_layout_extracts_10_sections(self, mock_figma_data):
        """TEST-EDGE-001: 정확히 10개 섹션 파싱 확인"""
        result = parse_layout(mock_figma_data)
        assert len(result.sections) == 10

    def test_parse_layout_first_section_details(self, mock_figma_data):
        """TEST-HAPPY-003: 첫 번째 섹션 상세 정보 확인"""
        result = parse_layout(mock_figma_data)
        first_section = result.sections[0]

        assert first_section.id == "1:159"
        assert first_section.name == "Product Hero"
        assert first_section.figma_group == "Group 10"
        assert first_section.x == 0
        assert first_section.y == 0
        assert first_section.width == 1033
        assert first_section.height == 1749
        assert first_section.styles["font-family"] == "Pretendard"
        assert first_section.styles["font-weight"] == 400

    def test_parse_layout_last_section_details(self, mock_figma_data):
        """TEST-EDGE-002: 마지막 섹션 상세 정보 확인"""
        result = parse_layout(mock_figma_data)
        last_section = result.sections[-1]

        assert last_section.id == "2:1481"
        assert last_section.name == "Size Chart"
        assert last_section.figma_group == "Group 11"
        assert last_section.y == 22585

    def test_parse_layout_invalid_data_raises_validation_error(self):
        """TEST-ERROR-001: 잘못된 데이터 입력 시 ValidationError 발생"""
        invalid_data = {
            "node_id": "1-95",
            "canvas": {"width": 1080, "height": 25520},
            "sections": []  # 빈 배열 (min_length=10 위반)
        }

        with pytest.raises(ValidationError):
            parse_layout(invalid_data)
