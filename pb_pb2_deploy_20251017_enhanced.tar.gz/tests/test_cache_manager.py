# @TEST:FIGMA-001 | SPEC: .moai/specs/SPEC-FIGMA-001/spec.md

"""CacheManager 테스트

TTL 기반 로컬 캐시 저장/로드 검증
"""

import json
from pathlib import Path

import pytest
from freezegun import freeze_time


def test_save_cache_creates_file() -> None:
    """캐시 저장 시 파일이 생성되어야 한다"""
    from src.utils.cache_manager import CacheManager

    manager = CacheManager()
    test_data = {"nodeId": "1:95", "name": "test"}

    manager.save("1:95", test_data)

    # 파일 생성 확인
    cache_file = Path(".cache/figma/1-95.json")
    assert cache_file.exists()

    # 정리
    cache_file.unlink()


def test_load_cache_returns_data() -> None:
    """캐시 로드 시 저장된 데이터를 반환해야 한다"""
    from src.utils.cache_manager import CacheManager

    manager = CacheManager()
    test_data = {"nodeId": "1:95", "name": "test"}

    manager.save("1:95", test_data)
    result = manager.load("1:95")

    assert result is not None
    assert result["nodeId"] == "1:95"
    assert result["name"] == "test"

    # 정리
    Path(".cache/figma/1-95.json").unlink()


def test_cache_ttl_expired() -> None:
    """TTL 초과 시 캐시가 무효화되어야 한다"""
    from src.utils.cache_manager import CacheManager

    manager = CacheManager(ttl=3600)  # 1시간
    test_data = {"nodeId": "1:95", "name": "test"}

    # 현재 시간에 캐시 저장
    with freeze_time("2025-01-15 10:00:00"):
        manager.save("1:95", test_data)

    # 2시간 후 (TTL 초과)
    with freeze_time("2025-01-15 12:00:01"):
        result = manager.load("1:95")
        assert result is None  # TTL 초과로 무효

    # 정리
    Path(".cache/figma/1-95.json").unlink()


def test_cache_ttl_valid() -> None:
    """TTL 이내에는 캐시가 유효해야 한다"""
    from src.utils.cache_manager import CacheManager

    manager = CacheManager(ttl=3600)  # 1시간
    test_data = {"nodeId": "1:95", "name": "test"}

    # 현재 시간에 캐시 저장
    with freeze_time("2025-01-15 10:00:00"):
        manager.save("1:95", test_data)

    # 30분 후 (TTL 이내)
    with freeze_time("2025-01-15 10:30:00"):
        result = manager.load("1:95")
        assert result is not None
        assert result["nodeId"] == "1:95"

    # 정리
    Path(".cache/figma/1-95.json").unlink()


def test_load_cache_nonexistent() -> None:
    """존재하지 않는 캐시 로드 시 None을 반환해야 한다"""
    from src.utils.cache_manager import CacheManager

    manager = CacheManager()
    result = manager.load("nonexistent-cache-key")

    assert result is None


def test_is_valid_cache() -> None:
    """is_valid() 메서드가 TTL을 정확히 확인해야 한다"""
    from src.utils.cache_manager import CacheManager

    manager = CacheManager(ttl=3600)
    test_data = {"nodeId": "1:95", "name": "test"}

    # 캐시 저장
    with freeze_time("2025-01-15 10:00:00"):
        manager.save("1:95", test_data)
        assert manager.is_valid("1:95") is True

    # 2시간 후 (TTL 초과)
    with freeze_time("2025-01-15 12:00:01"):
        assert manager.is_valid("1:95") is False

    # 정리
    Path(".cache/figma/1-95.json").unlink()
