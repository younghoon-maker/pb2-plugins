# @TEST:FIGMA-001 | SPEC: SPEC-FIGMA-001.md
"""
FigmaClient Mock 테스트 스위트

TDD RED Phase: 실패하는 테스트 작성
- get_metadata() Mock 데이터 로드
- retry 메커니즘 검증
- cache fallback 로직
- 초기화 파라미터 검증
"""

import json
import pytest
from pathlib import Path
from typing import Dict, Any


# === Happy Path Tests ===

def test_should_initialize_figma_client_with_mock_mode():
    """TEST-FIGMA-001-HAPPY-001: Mock 모드로 FigmaClient 초기화"""
    # RED: FigmaClient 클래스가 아직 없음
    from src.clients.figma_client import FigmaClient

    client = FigmaClient(mock_mode=True, use_cache=True, timeout=10)

    assert client.mock_mode is True
    assert client.use_cache is True
    assert client.timeout == 10


def test_should_load_mock_data_from_fixture():
    """TEST-FIGMA-001-HAPPY-002: Fixture에서 Mock 데이터 로드"""
    from src.clients.figma_client import FigmaClient

    client = FigmaClient(mock_mode=True)
    metadata = client.get_metadata("1-95")

    # 10개 섹션 확인
    assert metadata["node_id"] == "1-95"
    assert len(metadata["sections"]) == 10
    assert metadata["canvas"]["width"] == 1080
    assert metadata["canvas"]["height"] == 25520


def test_should_return_correct_section_data():
    """TEST-FIGMA-001-HAPPY-003: 섹션 데이터 구조 검증"""
    from src.clients.figma_client import FigmaClient

    client = FigmaClient(mock_mode=True)
    metadata = client.get_metadata("1-95")

    first_section = metadata["sections"][0]
    assert first_section["id"] == "1:159"
    assert first_section["name"] == "Product Hero"
    assert first_section["figma_group"] == "Group 10"
    assert first_section["width"] == 1033
    assert first_section["height"] == 1749


# === Edge Cases ===

def test_should_raise_error_when_fixture_not_found():
    """TEST-FIGMA-001-EDGE-001: Fixture 파일 없을 때 에러 발생"""
    from src.clients.figma_client import FigmaClient

    client = FigmaClient(mock_mode=True)

    with pytest.raises(FileNotFoundError) as exc_info:
        client.get_metadata("non-existent-node")

    assert "Fixture not found" in str(exc_info.value)


# === Error Cases ===

def test_should_raise_not_implemented_for_real_api_call():
    """TEST-FIGMA-001-ERROR-001: 실제 API 호출 시 NotImplementedError"""
    from src.clients.figma_client import FigmaClient

    client = FigmaClient(mock_mode=False)  # Real API mode

    with pytest.raises(NotImplementedError) as exc_info:
        client.get_metadata("1-95")

    assert "Real Figma MCP API" in str(exc_info.value)


def test_should_fallback_to_cache_when_api_fails():
    """TEST-FIGMA-001-ERROR-002: API 실패 시 캐시 사용"""
    from src.clients.figma_client import FigmaClient

    # Mock 캐시 데이터 준비
    cache_dir = Path("tests/fixtures/.cache")
    cache_dir.mkdir(exist_ok=True)
    cache_file = cache_dir / "1-95.json"

    # 캐시 데이터 작성
    fixture_path = Path("tests/fixtures/1-95.json")
    with open(fixture_path) as f:
        cache_data = json.load(f)

    with open(cache_file, "w") as f:
        json.dump(cache_data, f)

    try:
        # mock_mode=False이지만 캐시 사용 가능
        client = FigmaClient(mock_mode=False, use_cache=True)

        # API 실패 시 캐시 로드 (NotImplementedError 발생하면 캐시 사용)
        metadata = client.get_metadata("1-95")

        assert metadata["node_id"] == "1-95"
        assert len(metadata["sections"]) == 10
    finally:
        # 테스트 후 캐시 정리
        cache_file.unlink(missing_ok=True)
        cache_dir.rmdir()
