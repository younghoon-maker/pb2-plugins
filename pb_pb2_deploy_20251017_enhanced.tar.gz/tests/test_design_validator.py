# @TEST:FIGMA-001 | SPEC: .moai/specs/SPEC-FIGMA-001/spec.md

"""DesignValidator 테스트

필수 섹션 검증, 레이아웃 정확도 검증, 캔버스 크기 검증을 테스트합니다.
"""

import pytest
from src.models.design_spec import DesignSpec, Section
from src.validators.design_validator import DesignValidator
from src.models.exceptions import ValidationError


def test_validate_sections_all_present():
    """10개 섹션이 모두 존재하면 통과해야 한다"""
    validator = DesignValidator()

    # tests/fixtures/1-95.json 기준 10개 섹션 생성
    sections = [
        Section(id="1:159", name="Product Hero", figma_group="Group 10", x=0, y=0, width=1033, height=1749),
        Section(id="1:96", name="Color Variants", figma_group="Group 1", x=0, y=1749, width=1082, height=1159),
        Section(id="1:97", name="Lifestyle Gallery", figma_group="Group 2", x=0, y=2908, width=1042, height=14943),
        Section(id="1:98", name="Material Detail", figma_group="Group 3", x=0, y=17851, width=1042, height=2805),
        Section(id="1:99", name="Color Selector", figma_group="Group 4", x=0, y=20656, width=332, height=89),
        Section(id="1:100", name="Product Info", figma_group="Group 5", x=0, y=20745, width=1044, height=1043),
        Section(id="1:154", name="Care Instructions", figma_group="Group 6", x=0, y=21788, width=939, height=294),
        Section(id="1:155", name="Model Info", figma_group="Group 7", x=0, y=22082, width=730, height=352),
        Section(id="1:156", name="Size Guide", figma_group="Group 8", x=0, y=22434, width=601, height=151),
        Section(id="2:1481", name="Size Chart", figma_group="Group 11", x=0, y=22585, width=679, height=775),
    ]

    spec = DesignSpec(sections=sections)

    # 검증 통과
    assert validator.validate_sections(spec) is True


def test_validate_sections_missing_hero():
    """Product Hero 누락 시 ValidationError를 발생시켜야 한다"""
    validator = DesignValidator()

    # Product Hero 제외한 9개 섹션
    sections = [
        Section(id="1:96", name="Color Variants", figma_group="Group 1", x=0, y=1749, width=1082, height=1159),
        Section(id="1:97", name="Lifestyle Gallery", figma_group="Group 2", x=0, y=2908, width=1042, height=14943),
        Section(id="1:98", name="Material Detail", figma_group="Group 3", x=0, y=17851, width=1042, height=2805),
        Section(id="1:99", name="Color Selector", figma_group="Group 4", x=0, y=20656, width=332, height=89),
        Section(id="1:100", name="Product Info", figma_group="Group 5", x=0, y=20745, width=1044, height=1043),
        Section(id="1:154", name="Care Instructions", figma_group="Group 6", x=0, y=21788, width=939, height=294),
        Section(id="1:155", name="Model Info", figma_group="Group 7", x=0, y=22082, width=730, height=352),
        Section(id="1:156", name="Size Guide", figma_group="Group 8", x=0, y=22434, width=601, height=151),
        Section(id="2:1481", name="Size Chart", figma_group="Group 11", x=0, y=22585, width=679, height=775),
    ]

    # Pydantic이 min_length=10을 검증하므로 먼저 실패
    with pytest.raises(Exception):  # pydantic.ValidationError
        spec = DesignSpec(sections=sections)


def test_validate_layout_accuracy_within_2px():
    """레이아웃 오차가 ±2px 이내이면 에러가 없어야 한다"""
    validator = DesignValidator()

    # 실제 Figma 디자인 기준 정확한 좌표
    sections = [
        Section(id="1:159", name="Product Hero", figma_group="Group 10", x=24, y=180, width=1033, height=1749),
        Section(id="1:96", name="Color Variants", figma_group="Group 1", x=0, y=1996, width=1082, height=1159),
        Section(id="1:97", name="Lifestyle Gallery", figma_group="Group 2", x=24, y=3633, width=1042, height=14943),
        Section(id="1:98", name="Material Detail", figma_group="Group 3", x=19, y=18857, width=1042, height=2805),
        Section(id="1:99", name="Color Selector", figma_group="Group 4", x=36, y=21829, width=332, height=89),
        Section(id="1:100", name="Product Info", figma_group="Group 5", x=20, y=22027, width=1044, height=1043),
        Section(id="1:154", name="Care Instructions", figma_group="Group 6", x=36, y=23260, width=939, height=294),
        Section(id="1:155", name="Model Info", figma_group="Group 7", x=37, y=23737, width=730, height=352),
        Section(id="1:156", name="Size Guide", figma_group="Group 8", x=53, y=24307, width=601, height=151),
        Section(id="2:1481", name="Size Chart", figma_group="Group 11", x=53, y=24581, width=679, height=775),
    ]

    spec = DesignSpec(sections=sections)

    # 레이아웃 정확도 검증 (에러 없음)
    errors = validator.validate_layout_accuracy(spec)
    assert errors == []


def test_validate_layout_accuracy_exceeds_2px():
    """레이아웃 오차가 ±2px 초과이면 에러를 리포트해야 한다"""
    validator = DesignValidator()

    # X, Y 좌표에 +5px 오차 적용 (Product Hero만: 24→29, 180→185)
    sections = [
        Section(id="1:159", name="Product Hero", figma_group="Group 10", x=29, y=185, width=1033, height=1749),  # +5px, +5px 오차
        Section(id="1:96", name="Color Variants", figma_group="Group 1", x=0, y=1996, width=1082, height=1159),
        Section(id="1:97", name="Lifestyle Gallery", figma_group="Group 2", x=24, y=3633, width=1042, height=14943),
        Section(id="1:98", name="Material Detail", figma_group="Group 3", x=19, y=18857, width=1042, height=2805),
        Section(id="1:99", name="Color Selector", figma_group="Group 4", x=36, y=21829, width=332, height=89),
        Section(id="1:100", name="Product Info", figma_group="Group 5", x=20, y=22027, width=1044, height=1043),
        Section(id="1:154", name="Care Instructions", figma_group="Group 6", x=36, y=23260, width=939, height=294),
        Section(id="1:155", name="Model Info", figma_group="Group 7", x=37, y=23737, width=730, height=352),
        Section(id="1:156", name="Size Guide", figma_group="Group 8", x=53, y=24307, width=601, height=151),
        Section(id="2:1481", name="Size Chart", figma_group="Group 11", x=53, y=24581, width=679, height=775),
    ]

    spec = DesignSpec(sections=sections)

    # 레이아웃 정확도 검증 (에러 리포트)
    errors = validator.validate_layout_accuracy(spec)
    assert len(errors) > 0
    assert "Product Hero" in errors[0]


def test_validate_canvas_width():
    """캔버스 너비가 1082px이어야 한다 (실제 Figma 디자인 기준)"""
    validator = DesignValidator()

    sections = [
        Section(id="1:159", name="Product Hero", figma_group="Group 10", x=24, y=180, width=1033, height=1749),
        Section(id="1:96", name="Color Variants", figma_group="Group 1", x=0, y=1996, width=1082, height=1159),
        Section(id="1:97", name="Lifestyle Gallery", figma_group="Group 2", x=24, y=3633, width=1042, height=14943),
        Section(id="1:98", name="Material Detail", figma_group="Group 3", x=19, y=18857, width=1042, height=2805),
        Section(id="1:99", name="Color Selector", figma_group="Group 4", x=36, y=21829, width=332, height=89),
        Section(id="1:100", name="Product Info", figma_group="Group 5", x=20, y=22027, width=1044, height=1043),
        Section(id="1:154", name="Care Instructions", figma_group="Group 6", x=36, y=23260, width=939, height=294),
        Section(id="1:155", name="Model Info", figma_group="Group 7", x=37, y=23737, width=730, height=352),
        Section(id="1:156", name="Size Guide", figma_group="Group 8", x=53, y=24307, width=601, height=151),
        Section(id="2:1481", name="Size Chart", figma_group="Group 11", x=53, y=24581, width=679, height=775),
    ]

    # 1082px 너비
    spec = DesignSpec(width=1082, sections=sections)
    assert validator.validate_canvas_width(spec) is True

    # 잘못된 너비
    spec_invalid = DesignSpec(width=1024, sections=sections)
    with pytest.raises(ValidationError, match="Canvas width must be 1082px"):
        validator.validate_canvas_width(spec_invalid)
