"""
@TEST:SHEETS-001 | SPEC: SPEC-SHEETS-001.md

Google Sheets 로더 테스트
"""

import pytest
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
from src.sheets_loader.loader import SheetsLoader


class TestSheetsLoader:
    """SheetsLoader 클래스 테스트"""

    @pytest.fixture
    def mock_service_account_file(self, tmp_path: Path) -> Path:
        """임시 Service Account JSON 파일 생성"""
        sa_file = tmp_path / "service-account.json"
        # Google Service Account에 필요한 최소 필드 포함
        sa_file.write_text(
            """{
            "type": "service_account",
            "project_id": "test-project",
            "private_key_id": "test-key-id",
            "private_key": "-----BEGIN RSA PRIVATE KEY-----\\nMIIEpAIBAAKCAQEA0Z3VS5JJcds3xfn/ygWyF2yXmL5q1pB4rVXvxUfPZmENQA==\\n-----END RSA PRIVATE KEY-----",
            "client_email": "test@test-project.iam.gserviceaccount.com",
            "client_id": "123456789",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token"
        }"""
        )
        return sa_file

    @pytest.fixture
    def mock_sheets_service(self) -> Mock:
        """Mock Google Sheets API 서비스"""
        service = MagicMock()
        return service

    def test_init_with_valid_service_account(
        self, mock_service_account_file: Path
    ) -> None:
        """유효한 Service Account 파일로 초기화"""
        with patch(
            "src.sheets_loader.loader.service_account.Credentials.from_service_account_file"
        ) as mock_creds:
            with patch("src.sheets_loader.loader.build") as mock_build:
                mock_creds.return_value = MagicMock()
                mock_build.return_value = MagicMock()
                loader = SheetsLoader(mock_service_account_file)
                assert loader is not None
                mock_creds.assert_called_once()
                mock_build.assert_called_once()

    def test_init_with_invalid_service_account(self, tmp_path: Path) -> None:
        """존재하지 않는 Service Account 파일"""
        invalid_file = tmp_path / "nonexistent.json"
        with pytest.raises(FileNotFoundError):
            SheetsLoader(invalid_file)

    def test_load_single_row(
        self, mock_service_account_file: Path, mock_sheets_service: Mock
    ) -> None:
        """단일 행 로드"""
        # Mock API response
        mock_response = {"values": [["Value1", "Value2", "Value3"]]}
        mock_sheets_service.spreadsheets().values().get().execute.return_value = (
            mock_response
        )

        with patch(
            "src.sheets_loader.loader.service_account.Credentials.from_service_account_file"
        ):
            with patch(
                "src.sheets_loader.loader.build", return_value=mock_sheets_service
            ):
                loader = SheetsLoader(mock_service_account_file)
                result = loader.load_row("test_sheet_id", 2)

                assert result == ["Value1", "Value2", "Value3"]
                # API가 호출되었는지 확인 (mock 체이닝으로 인해 assert_called_once는 사용하지 않음)
                assert mock_sheets_service.spreadsheets.called

    def test_load_batch_rows(
        self, mock_service_account_file: Path, mock_sheets_service: Mock
    ) -> None:
        """여러 행 일괄 로드"""
        # Mock API response
        mock_response = {
            "values": [
                ["Row1Col1", "Row1Col2"],
                ["Row2Col1", "Row2Col2"],
                ["Row3Col1", "Row3Col2"],
            ]
        }
        mock_sheets_service.spreadsheets().values().get().execute.return_value = (
            mock_response
        )

        with patch(
            "src.sheets_loader.loader.service_account.Credentials.from_service_account_file"
        ):
            with patch(
                "src.sheets_loader.loader.build", return_value=mock_sheets_service
            ):
                loader = SheetsLoader(mock_service_account_file)
                result = loader.load_rows("test_sheet_id", 2, 4)

                assert len(result) == 3
                assert result[0] == ["Row1Col1", "Row1Col2"]
                assert result[2] == ["Row3Col1", "Row3Col2"]

    def test_extract_hyperlinks(
        self, mock_service_account_file: Path, mock_sheets_service: Mock
    ) -> None:
        """셀 하이퍼링크 추출 (includeGridData=True)"""
        # Mock API response with hyperlinks
        mock_response = {
            "sheets": [
                {
                    "data": [
                        {
                            "rowData": [
                                {
                                    "values": [
                                        {
                                            "formattedValue": "Click here",
                                            "hyperlink": "https://example.com",
                                        },
                                        {
                                            "formattedValue": "Plain text",
                                        },
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        }
        mock_sheets_service.spreadsheets().get().execute.return_value = mock_response

        with patch(
            "src.sheets_loader.loader.service_account.Credentials.from_service_account_file"
        ):
            with patch(
                "src.sheets_loader.loader.build", return_value=mock_sheets_service
            ):
                loader = SheetsLoader(mock_service_account_file)
                result = loader.extract_hyperlinks("test_sheet_id", 2)

                assert len(result) == 2
                assert result[0] == "https://example.com"
                assert result[1] is None

    def test_api_error_handling(
        self, mock_service_account_file: Path, mock_sheets_service: Mock
    ) -> None:
        """API 에러 처리"""
        from googleapiclient.errors import HttpError

        # Mock API error
        mock_sheets_service.spreadsheets().values().get().execute.side_effect = (
            HttpError(Mock(status=500), b"Internal Server Error")
        )

        with patch(
            "src.sheets_loader.loader.service_account.Credentials.from_service_account_file"
        ):
            with patch(
                "src.sheets_loader.loader.build", return_value=mock_sheets_service
            ):
                loader = SheetsLoader(mock_service_account_file)
                with pytest.raises(HttpError):
                    loader.load_row("test_sheet_id", 2)

    def test_empty_sheet_handling(
        self, mock_service_account_file: Path, mock_sheets_service: Mock
    ) -> None:
        """빈 시트 처리"""
        # Mock empty response
        mock_response = {}
        mock_sheets_service.spreadsheets().values().get().execute.return_value = (
            mock_response
        )

        with patch(
            "src.sheets_loader.loader.service_account.Credentials.from_service_account_file"
        ):
            with patch(
                "src.sheets_loader.loader.build", return_value=mock_sheets_service
            ):
                loader = SheetsLoader(mock_service_account_file)
                result = loader.load_row("test_sheet_id", 2)

                assert result == []
