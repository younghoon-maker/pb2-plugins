# @TEST:HTML-001 | SPEC: .moai/specs/SPEC-HTML-001/spec.md

"""HTMLGenerator 통합 테스트

DesignSpec → HTML 전체 파이프라인을 테스트합니다.
"""

import os
from pathlib import Path

import pytest

from src.models.design_spec import DesignSpec, Section
from src.models.exceptions import ValidationError


def create_full_design_spec() -> DesignSpec:
    """10개 섹션을 포함하는 완전한 DesignSpec 생성"""
    return DesignSpec(
        width=1082,
        height=25520,
        sections=[
            Section(
                id="1:159",
                name="Product Hero",
                figma_group="Group 10",
                x=24,
                y=180,
                width=1033,
                height=1749,
            ),
            Section(
                id="1:96",
                name="Color Variants",
                figma_group="Group 1",
                x=0,
                y=1996,
                width=1082,
                height=1159,
            ),
            Section(
                id="1:97",
                name="Lifestyle Gallery",
                figma_group="Group 2",
                x=0,
                y=3222,
                width=1082,
                height=2487,
            ),
            Section(
                id="1:98",
                name="Material Detail",
                figma_group="Group 3",
                x=0,
                y=5776,
                width=1082,
                height=2148,
            ),
            Section(
                id="1:99",
                name="Color Selector",
                figma_group="Group 4",
                x=0,
                y=7991,
                width=1082,
                height=2729,
            ),
            Section(
                id="1:100",
                name="Product Info",
                figma_group="Group 5",
                x=0,
                y=10787,
                width=1082,
                height=4257,
            ),
            Section(
                id="1:101",
                name="Care Instructions",
                figma_group="Group 6",
                x=0,
                y=15111,
                width=1082,
                height=2516,
            ),
            Section(
                id="1:102",
                name="Model Info",
                figma_group="Group 7",
                x=0,
                y=17694,
                width=1082,
                height=1544,
            ),
            Section(
                id="1:103",
                name="Size Guide",
                figma_group="Group 8",
                x=0,
                y=19305,
                width=1082,
                height=2954,
            ),
            Section(
                id="1:104",
                name="Size Chart",
                figma_group="Group 9",
                x=0,
                y=22326,
                width=1082,
                height=3194,
            ),
        ],
    )


def test_generate_html_from_design_spec(tmp_path: Path) -> None:
    """DesignSpec → HTML 전체 파이프라인 테스트"""
    from src.html_generator import HTMLGenerator
    from src.layout_renderer import LayoutRenderer
    from src.template_engine import TemplateEngine

    spec = create_full_design_spec()

    template_engine = TemplateEngine()
    layout_renderer = LayoutRenderer()
    generator = HTMLGenerator(
        template_engine, layout_renderer, output_dir=str(tmp_path)
    )

    output_path = generator.generate(spec)

    assert output_path == str(tmp_path / "original.html")
    assert os.path.exists(output_path)
    assert os.path.getsize(output_path) < 30 * 1024 * 1024  # 30MB 이하

    # HTML 내용 검증
    with open(output_path, "r", encoding="utf-8") as f:
        html_content = f.read()

    assert "<!DOCTYPE html>" in html_content
    assert "Pretendard" in html_content
    assert "1082px" in html_content
    assert "25520px" in html_content


def test_validate_spec_missing_sections() -> None:
    """필수 섹션 누락 시 ValidationError 발생"""
    from pydantic import ValidationError as PydanticValidationError

    # Pydantic이 먼저 검증하므로 DesignSpec 생성 자체가 실패
    with pytest.raises(PydanticValidationError, match="at least 10 items"):
        DesignSpec(
            width=1082,
            height=25520,
            sections=[
                Section(
                    id="1:159",
                    name="Product Hero",
                    figma_group="Group 10",
                    x=24,
                    y=180,
                    width=1033,
                    height=1749,
                ),
                # 나머지 9개 섹션 누락
            ],
        )


def test_validate_spec_invalid_canvas_width() -> None:
    """캔버스 너비 불일치 시 ValidationError 발생"""
    from src.html_generator import HTMLGenerator
    from src.layout_renderer import LayoutRenderer
    from src.template_engine import TemplateEngine

    spec = create_full_design_spec()
    spec.width = 1080  # 잘못된 너비 (1082px 기대)

    generator = HTMLGenerator(TemplateEngine(), LayoutRenderer())

    with pytest.raises(ValidationError, match="Invalid canvas width"):
        generator.validate_spec(spec)


def test_validate_spec_invalid_canvas_height() -> None:
    """캔버스 높이 불일치 시 ValidationError 발생"""
    from src.html_generator import HTMLGenerator
    from src.layout_renderer import LayoutRenderer
    from src.template_engine import TemplateEngine

    spec = create_full_design_spec()
    spec.height = 25000  # 잘못된 높이

    generator = HTMLGenerator(TemplateEngine(), LayoutRenderer())

    with pytest.raises(ValidationError, match="Invalid canvas height"):
        generator.validate_spec(spec)


def test_generate_html_creates_output_directory(tmp_path: Path) -> None:
    """출력 디렉토리가 없으면 자동 생성"""
    from src.html_generator import HTMLGenerator
    from src.layout_renderer import LayoutRenderer
    from src.template_engine import TemplateEngine

    output_dir = tmp_path / "output"
    spec = create_full_design_spec()

    generator = HTMLGenerator(
        TemplateEngine(), LayoutRenderer(), output_dir=str(output_dir)
    )
    output_path = generator.generate(spec)

    assert output_dir.exists()
    assert os.path.exists(output_path)
