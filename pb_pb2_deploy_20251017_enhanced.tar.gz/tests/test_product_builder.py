"""
@TEST:SHEETS-001 | SPEC: SPEC-SHEETS-001.md

ProductDataBuilder 테스트
"""

import pytest
from typing import List
from src.sheets_loader.product_builder import ProductDataBuilder
from src.models.product_data import ProductData


class TestProductDataBuilder:
    """ProductDataBuilder 클래스 테스트"""

    @pytest.fixture
    def builder(self) -> ProductDataBuilder:
        """ProductDataBuilder 인스턴스 생성"""
        return ProductDataBuilder()

    @pytest.fixture
    def sample_row_minimal(self) -> List[str]:
        """최소 데이터 행 (292 컬럼)"""
        row = ["-"] * 292  # 모든 컬럼을 빈 값으로 초기화

        # 기본 정보 (0-2)
        row[0] = "TEST001"  # 상품코드
        row[1] = "Test Product"  # 상품명
        row[2] = "https://example.com/main.jpg"  # 메인이미지

        # 색상 1 (3, 9, 10)
        row[3] = "https://example.com/color1.jpg"  # 색상1_이미지
        row[9] = "Black"  # 색상1_이름
        row[10] = "#000000"  # 색상1_HEX

        # 갤러리 Color 1 (21-32) - 최소 1개
        row[21] = "https://example.com/gallery1.jpg"

        # 포인트 1 (117-118)
        row[117] = "https://example.com/detail1.jpg"  # 포인트1_이미지
        row[118] = "Detail Point 1"  # 포인트1_텍스트

        # 소재 정보 (123-125)
        row[123] = "https://example.com/fabric.jpg"  # 소재_이미지
        row[124] = "100% Cotton"  # 소재_구성
        row[125] = "Machine wash cold"  # 세탁_방법

        # 상의 사이즈 1 (132-139)
        row[132] = "FREE"  # 사이즈명
        row[133] = "40"  # 어깨너비
        row[134] = "100"  # 가슴둘레
        row[136] = "60"  # 소매길이
        row[138] = "65"  # 총장

        return row

    @pytest.fixture
    def sample_row_full(self) -> List[str]:
        """전체 데이터 행 (6 colors, 3 details, 2 models)"""
        row = ["-"] * 292

        # 기본 정보
        row[0] = "FULL001"
        row[1] = "Full Product"
        row[2] = "https://example.com/main.jpg"

        # 색상 6개 (3-20)
        for i in range(6):
            row[3 + i] = f"https://example.com/color{i+1}.jpg"  # 색상 이미지
            row[9 + i * 2] = f"Color{i+1}"  # 색상명
            row[10 + i * 2] = f"#00000{i}"  # HEX

        # 갤러리 Color 1-8 (21-116) - 각 12개씩
        for color in range(8):
            for img in range(12):
                idx = 21 + color * 12 + img
                row[idx] = f"https://example.com/gallery_{color+1}_{img+1}.jpg"

        # 포인트 3개 (117-122)
        for i in range(3):
            row[117 + i * 2] = f"https://example.com/detail{i+1}.jpg"
            row[118 + i * 2] = f"Detail Point {i+1}"

        # 소재 정보
        row[123] = "https://example.com/fabric.jpg"
        row[124] = "100% Cotton"
        row[125] = "Machine wash cold"

        # 체크포인트 (126-127)
        row[126] = "https://example.com/checkpoint.jpg"
        row[127] = "Check sizing guide"

        # 모델 2개 (128-131)
        row[128] = "165cm"  # 모델1_신장
        row[129] = "FREE"  # 모델1_착용사이즈
        row[130] = "175cm"  # 모델2_신장
        row[131] = "FREE"  # 모델2_착용사이즈

        # 상의 사이즈 2개 (132-147)
        for i in range(2):
            base = 132 + i * 8
            row[base] = f"SIZE{i+1}"
            row[base + 1] = str(40 + i * 2)  # 어깨너비
            row[base + 2] = str(100 + i * 5)  # 가슴둘레
            row[base + 4] = str(60 + i * 2)  # 소매길이
            row[base + 6] = str(65 + i * 2)  # 총장

        return row

    def test_build_product_data_minimal(
        self, builder: ProductDataBuilder, sample_row_minimal: List[str]
    ) -> None:
        """최소 데이터로 ProductData 생성"""
        product = builder.build_product_data(sample_row_minimal)

        assert isinstance(product, ProductData)
        assert product.product_code == "TEST001"
        assert product.product_name == "Test Product"
        assert len(product.colors) == 1
        assert product.colors[0].color_name == "Black"
        assert len(product.detail_points) == 1
        assert len(product.gallery_by_color) == 1
        assert product.fabric_info.fabric_composition == "100% Cotton"
        assert len(product.size_info.top) == 1
        assert product.size_info.top[0].size_name == "FREE"

    def test_build_product_data_full(
        self, builder: ProductDataBuilder, sample_row_full: List[str]
    ) -> None:
        """전체 데이터로 ProductData 생성"""
        product = builder.build_product_data(sample_row_full)

        # 6개 색상
        assert len(product.colors) == 6
        assert product.colors[5].color_name == "Color6"

        # 갤러리 8색상 × 12이미지 = 96개 (빈 값 제외하면 실제로는 8개 color key)
        assert len(product.gallery_by_color) == 8
        assert len(product.gallery_by_color["Color1"]) == 12

        # 3개 디테일 포인트
        assert len(product.detail_points) == 3
        assert product.detail_points[2].detail_text == "Detail Point 3"

        # 체크포인트
        assert product.checkpoint is not None
        assert product.checkpoint.checkpoint_text == "Check sizing guide"

        # 2개 모델 정보
        assert len(product.model_info) == 2
        assert product.model_info[0].model_measurements == "165cm"

        # 2개 상의 사이즈
        assert len(product.size_info.top) == 2
        assert product.size_info.top[1].size_name == "SIZE2"

    def test_empty_value_filtering(
        self, builder: ProductDataBuilder
    ) -> None:
        """빈 값 필터링 확인"""
        row = ["-"] * 292

        # 기본 정보만 입력
        row[0] = "EMPTY001"
        row[1] = "Empty Test"
        row[2] = "https://example.com/main.jpg"

        # 색상 1만 입력 (나머지는 빈 값)
        row[3] = "https://example.com/color1.jpg"
        row[9] = "Color1"

        # 갤러리는 모두 빈 값 (21-116)
        # 포인트 1만 입력
        row[117] = "https://example.com/detail1.jpg"
        row[118] = "Detail 1"

        # 소재 정보
        row[124] = "100% Cotton"
        row[125] = "Machine wash cold"

        # 상의 사이즈 1개
        row[132] = "FREE"
        row[133] = "40"
        row[134] = "100"
        row[136] = "60"
        row[138] = "65"

        product = builder.build_product_data(row)

        # 1개 색상만
        assert len(product.colors) == 1

        # 갤러리는 비어있어야 함 (모두 빈 값이므로)
        assert len(product.gallery_by_color) == 0

        # 1개 디테일 포인트만
        assert len(product.detail_points) == 1

    def test_dynamic_color_parsing(
        self, builder: ProductDataBuilder
    ) -> None:
        """동적 색상 파싱 (1-6개)"""
        row = ["-"] * 292

        # 기본 정보
        row[0] = "COLOR001"
        row[1] = "Color Test"
        row[2] = "https://example.com/main.jpg"

        # 색상 3개만 입력 (나머지는 빈 값)
        for i in range(3):
            row[3 + i] = f"https://example.com/color{i+1}.jpg"
            row[9 + i * 2] = f"Color{i+1}"
            row[10 + i * 2] = f"#00000{i}"

        # 필수 필드 (포인트, 소재, 사이즈)
        row[117] = "https://example.com/detail1.jpg"
        row[118] = "Detail 1"
        row[124] = "100% Cotton"
        row[125] = "Machine wash cold"
        row[132] = "FREE"
        row[133] = "40"
        row[134] = "100"
        row[136] = "60"
        row[138] = "65"

        product = builder.build_product_data(row)

        # 3개 색상만 파싱되어야 함
        assert len(product.colors) == 3
        assert product.colors[0].color_name == "Color1"
        assert product.colors[2].color_name == "Color3"
