"""
@TEST:SHEETS-001 | SPEC: SPEC-SHEETS-001.md

Pydantic 데이터 모델 테스트
"""

import pytest
from pydantic import ValidationError
from src.models.product_data import (
    ColorVariant,
    DetailPoint,
    FabricInfo,
    CheckpointInfo,
    ModelInfo,
    TopSize,
    BottomSize,
    SizeInfo,
    ProductData,
)


class TestColorVariant:
    """ColorVariant 모델 테스트"""

    def test_valid_color_variant(self) -> None:
        """유효한 색상 변형 생성"""
        color = ColorVariant(
            color_image="https://example.com/color.jpg",
            color_name="Black",
            color_hex="#000000",
        )
        assert color.color_name == "Black"
        assert color.color_hex == "#000000"

    def test_color_hex_with_prefix(self) -> None:
        """HEX 코드 접두사 자동 추가"""
        color = ColorVariant(
            color_image="https://example.com/color.jpg",
            color_name="Black",
            color_hex="000000",
        )
        assert color.color_hex == "#000000"

    def test_color_hex_optional(self) -> None:
        """HEX 코드는 선택 사항"""
        color = ColorVariant(
            color_image="https://example.com/color.jpg",
            color_name="Black",
        )
        assert color.color_hex is None

    def test_missing_required_fields(self) -> None:
        """필수 필드 누락 시 ValidationError"""
        with pytest.raises(ValidationError):
            ColorVariant()


class TestDetailPoint:
    """DetailPoint 모델 테스트"""

    def test_valid_detail_point(self) -> None:
        """유효한 디테일 포인트 생성"""
        detail = DetailPoint(
            detail_image="https://example.com/detail.jpg",
            detail_text="Premium fabric",
        )
        assert detail.detail_text == "Premium fabric"

    def test_missing_required_fields(self) -> None:
        """필수 필드 누락 시 ValidationError"""
        with pytest.raises(ValidationError):
            DetailPoint(detail_image="https://example.com/detail.jpg")


class TestFabricInfo:
    """FabricInfo 모델 테스트"""

    def test_valid_fabric_info(self) -> None:
        """유효한 소재 정보 생성"""
        fabric = FabricInfo(
            fabric_composition="100% Cotton",
            fabric_care="Machine wash cold",
        )
        assert fabric.fabric_composition == "100% Cotton"

    def test_missing_required_fields(self) -> None:
        """필수 필드 누락 시 ValidationError"""
        with pytest.raises(ValidationError):
            FabricInfo()


class TestCheckpointInfo:
    """CheckpointInfo 모델 테스트"""

    def test_valid_checkpoint_info(self) -> None:
        """유효한 체크포인트 정보 생성"""
        checkpoint = CheckpointInfo(
            checkpoint_image="https://example.com/checkpoint.jpg",
            checkpoint_text="Check sizing guide",
        )
        assert checkpoint.checkpoint_text == "Check sizing guide"

    def test_missing_required_fields(self) -> None:
        """필수 필드 누락 시 ValidationError"""
        with pytest.raises(ValidationError):
            CheckpointInfo(checkpoint_image="https://example.com/checkpoint.jpg")


class TestModelInfo:
    """ModelInfo 모델 테스트"""

    def test_valid_model_info(self) -> None:
        """유효한 모델 정보 생성"""
        model = ModelInfo(
            model_size="M",
            model_measurements="Height: 175cm, Weight: 60kg",
        )
        assert model.model_size == "M"

    def test_missing_required_fields(self) -> None:
        """필수 필드 누락 시 ValidationError"""
        with pytest.raises(ValidationError):
            ModelInfo()


class TestSizeInfo:
    """SizeInfo 모델 테스트"""

    def test_valid_size_info_top(self) -> None:
        """유효한 상의 사이즈 정보 생성"""
        size_info = SizeInfo(
            top=[
                TopSize(size_name="S", chest=90, shoulder=40, sleeve=60, length=65),
                TopSize(size_name="M", chest=95, shoulder=42, sleeve=62, length=67),
            ]
        )
        assert len(size_info.top) == 2
        assert size_info.top[0].size_name == "S"
        assert size_info.bottom is None

    def test_valid_size_info_bottom(self) -> None:
        """유효한 하의 사이즈 정보 생성"""
        size_info = SizeInfo(
            bottom=[
                BottomSize(size_name="S", waist=70, hip=90, thigh=55, rise=25, hem=16),
                BottomSize(size_name="M", waist=75, hip=95, thigh=57, rise=26, hem=17),
            ]
        )
        assert len(size_info.bottom) == 2
        assert size_info.bottom[0].size_name == "S"
        assert size_info.top is None

    def test_size_info_requires_top_or_bottom(self) -> None:
        """top 또는 bottom 중 하나는 필수"""
        with pytest.raises(ValidationError):
            SizeInfo()


class TestProductData:
    """ProductData 메인 모델 테스트"""

    def test_valid_product_data(self) -> None:
        """유효한 상품 데이터 생성"""
        product = ProductData(
            product_code="TEST001",
            product_name="Test Product",
            main_image="https://example.com/main.jpg",
            colors=[
                ColorVariant(
                    color_image="https://example.com/color1.jpg",
                    color_name="Black",
                )
            ],
            gallery_by_color={
                "Black": ["https://example.com/gallery1.jpg"]
            },
            detail_points=[
                DetailPoint(
                    detail_image="https://example.com/detail1.jpg",
                    detail_text="Premium fabric",
                )
            ],
            fabric_info=FabricInfo(
                fabric_composition="100% Cotton",
                fabric_care="Machine wash cold",
            ),
            size_info=SizeInfo(
                top=[
                    TopSize(size_name="S", chest=90, shoulder=40, sleeve=60, length=65)
                ]
            ),
        )
        assert product.product_code == "TEST001"
        assert len(product.colors) == 1
        assert product.checkpoint is None
        assert len(product.model_info) == 0

    def test_product_data_max_colors(self) -> None:
        """최대 6개 색상 제한"""
        colors = [
            ColorVariant(
                color_image=f"https://example.com/color{i}.jpg",
                color_name=f"Color{i}",
            )
            for i in range(7)
        ]
        with pytest.raises(ValidationError) as exc_info:
            ProductData(
                product_code="TEST001",
                product_name="Test Product",
                main_image="https://example.com/main.jpg",
                colors=colors,
                gallery_by_color={},
                detail_points=[
                    DetailPoint(
                        detail_image="https://example.com/detail1.jpg",
                        detail_text="Text",
                    )
                ],
                fabric_info=FabricInfo(
                    fabric_composition="100% Cotton",
                    fabric_care="Machine wash cold",
                ),
                size_info=SizeInfo(
                    top=[
                        TopSize(
                            size_name="S", chest=90, shoulder=40, sleeve=60, length=65
                        )
                    ]
                ),
            )
        assert "colors" in str(exc_info.value)

    def test_product_data_max_detail_points(self) -> None:
        """최대 3개 디테일 포인트 제한"""
        detail_points = [
            DetailPoint(
                detail_image=f"https://example.com/detail{i}.jpg",
                detail_text=f"Detail {i}",
            )
            for i in range(4)
        ]
        with pytest.raises(ValidationError) as exc_info:
            ProductData(
                product_code="TEST001",
                product_name="Test Product",
                main_image="https://example.com/main.jpg",
                colors=[
                    ColorVariant(
                        color_image="https://example.com/color1.jpg",
                        color_name="Black",
                    )
                ],
                gallery_by_color={},
                detail_points=detail_points,
                fabric_info=FabricInfo(
                    fabric_composition="100% Cotton",
                    fabric_care="Machine wash cold",
                ),
                size_info=SizeInfo(
                    top=[
                        TopSize(
                            size_name="S", chest=90, shoulder=40, sleeve=60, length=65
                        )
                    ]
                ),
            )
        assert "detail_points" in str(exc_info.value)

    def test_product_data_max_model_info(self) -> None:
        """최대 2개 모델 정보 제한"""
        model_info = [
            ModelInfo(model_size="S", model_measurements="Height: 170cm"),
            ModelInfo(model_size="M", model_measurements="Height: 175cm"),
            ModelInfo(model_size="L", model_measurements="Height: 180cm"),
        ]
        with pytest.raises(ValidationError) as exc_info:
            ProductData(
                product_code="TEST001",
                product_name="Test Product",
                main_image="https://example.com/main.jpg",
                colors=[
                    ColorVariant(
                        color_image="https://example.com/color1.jpg",
                        color_name="Black",
                    )
                ],
                gallery_by_color={},
                detail_points=[
                    DetailPoint(
                        detail_image="https://example.com/detail1.jpg",
                        detail_text="Text",
                    )
                ],
                fabric_info=FabricInfo(
                    fabric_composition="100% Cotton",
                    fabric_care="Machine wash cold",
                ),
                model_info=model_info,
                size_info=SizeInfo(
                    top=[
                        TopSize(
                            size_name="S", chest=90, shoulder=40, sleeve=60, length=65
                        )
                    ]
                ),
            )
        assert "model_info" in str(exc_info.value)

    def test_product_data_missing_required_fields(self) -> None:
        """필수 필드 누락 시 ValidationError"""
        with pytest.raises(ValidationError):
            ProductData()
