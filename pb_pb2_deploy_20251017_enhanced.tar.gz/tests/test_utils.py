"""
@TEST:SHEETS-001 | SPEC: SPEC-SHEETS-001.md

유틸리티 함수 테스트
"""

import pytest
from src.sheets_loader.utils import is_empty_value


class TestIsEmptyValue:
    """is_empty_value() 함수 테스트"""

    def test_is_empty_value_dash(self) -> None:
        """대시(-)는 빈 값으로 처리"""
        assert is_empty_value("-") is True

    def test_is_empty_value_na(self) -> None:
        """N/A 변형은 빈 값으로 처리"""
        assert is_empty_value("N/A") is True
        assert is_empty_value("#N/A") is True

    def test_is_empty_value_ref_error(self) -> None:
        """REF 에러는 빈 값으로 처리"""
        assert is_empty_value("#REF!") is True

    def test_is_empty_value_whitespace(self) -> None:
        """공백 문자열은 빈 값으로 처리"""
        assert is_empty_value("") is True
        assert is_empty_value("   ") is True
        assert is_empty_value("\t") is True
        assert is_empty_value("\n") is True

    def test_is_empty_value_none(self) -> None:
        """None은 빈 값으로 처리"""
        assert is_empty_value(None) is True

    def test_is_empty_value_valid_string(self) -> None:
        """유효한 문자열은 빈 값이 아님"""
        assert is_empty_value("Valid Text") is False
        assert is_empty_value("0") is False
        assert is_empty_value("false") is False

    def test_is_empty_value_case_insensitive(self) -> None:
        """대소문자 구분 없이 빈 값 검사"""
        assert is_empty_value("n/a") is True
        assert is_empty_value("N/a") is True
        assert is_empty_value("#n/a") is True
        assert is_empty_value("#ref!") is True
