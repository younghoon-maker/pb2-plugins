"""
DANA&PETA Page Builder Configuration
303-column Google Sheets structure (A~KQ)
"""

import os
from pathlib import Path

# Project root directory
PROJECT_ROOT = Path(__file__).parent.parent

# Google Sheets Configuration
SHEET_ID = "1m1f784rij74eSpuHOEOqbAzQu97ZenfLa3QuO-Egjxk"  # DANA&PETA Products Sheet

# Unified Template System: Single "템플릿" tab
SHEET_NAME = "템플릿"  # Unified template tab
SHEET_RANGE = "A2:KQ100"  # 303 columns (A~KQ), up to 100 products

# Unified Template Column Definitions (템플릿 tab - 303 columns, +1 after sellingPoint4 added)
TEMPLATE_COLUMNS = {
    # Basic Info (columns 0-6)
    'productCode': 0,       # A - 상품코드
    'title': 1,             # B - 상품명
    'sellingPoint1': 2,     # C - 설명1
    'sellingPoint2': 3,     # D - 설명2
    'sellingPoint3': 4,     # E - 설명3
    'sellingPoint4': 5,     # F - 설명4 (NEW)
    'mdComment': 6,         # G - 추천 코멘트 (기존 F에서 이동)

    # Main Image (column 7)
    'mainImage': 7,         # H - 메인이미지_url (기존 G에서 이동)

    # Color Names & HEX (columns 8-15)
    'color1Name': 8,        # - 색상1_이름 (+1)
    'color1Hex': 9,         # - 색상1_HEX (+1)
    'color2Name': 10,       # - 색상2_이름 (+1)
    'color2Hex': 11,        # - 색상2_HEX (+1)
    'color3Name': 12,       # - 색상3_이름 (+1)
    'color3Hex': 13,        # - 색상3_HEX (+1)
    'color4Name': 14,       # - 색상4_이름 (+1)
    'color4Hex': 15,        # - 색상4_HEX (+1)

    # Detail Points (columns 16-23)
    'detailPoint1Image': 16,    # - 디테일포인트1_url (+1)
    'detailPoint1Text': 17,     # - 디테일포인트1_설명 (+1)
    'detailPoint2Image': 18,    # - 디테일포인트2_url (+1)
    'detailPoint2Text': 19,     # - 디테일포인트2_설명 (+1)
    'detailPoint3Image': 20,    # - 디테일포인트3_url (+1)
    'detailPoint3Text': 21,     # - 디테일포인트3_설명 (+1)
    'detailPoint4Image': 22,    # - 디테일포인트4_url (+1)
    'detailPoint4Text': 23,     # - 디테일포인트4_설명 (+1)

    # Gallery Images by Color (columns 24-119)
    # Color1-8, each with 12 detail images
    'color1Gallery1': 24,  # - Color1_디테일이미지1 (+1)
    'color1Gallery2': 25,  # - Color1_디테일이미지2 (+1)
    'color1Gallery3': 26,  # - Color1_디테일이미지3 (+1)
    'color1Gallery4': 27,  # - Color1_디테일이미지4 (+1)
    'color1Gallery5': 28,  # - Color1_디테일이미지5 (+1)
    'color1Gallery6': 29,  # - Color1_디테일이미지6 (+1)
    'color1Gallery7': 30,  # - Color1_디테일이미지7 (+1)
    'color1Gallery8': 31,  # - Color1_디테일이미지8 (+1)
    'color1Gallery9': 32,  # - Color1_디테일이미지9 (+1)
    'color1Gallery10': 33,  # - Color1_디테일이미지10 (+1)
    'color1Gallery11': 34,  # - Color1_디테일이미지11 (+1)
    'color1Gallery12': 35,  # - Color1_디테일이미지12 (+1)
    'color2Gallery1': 36,  # - Color2_디테일이미지1 (+1)
    'color2Gallery2': 37,  # - Color2_디테일이미지2 (+1)
    'color2Gallery3': 38,  # - Color2_디테일이미지3 (+1)
    'color2Gallery4': 39,  # - Color2_디테일이미지4 (+1)
    'color2Gallery5': 40,  # - Color2_디테일이미지5 (+1)
    'color2Gallery6': 41,  # - Color2_디테일이미지6 (+1)
    'color2Gallery7': 42,  # - Color2_디테일이미지7 (+1)
    'color2Gallery8': 43,  # - Color2_디테일이미지8 (+1)
    'color2Gallery9': 44,  # - Color2_디테일이미지9 (+1)
    'color2Gallery10': 45,  # - Color2_디테일이미지10 (+1)
    'color2Gallery11': 46,  # - Color2_디테일이미지11 (+1)
    'color2Gallery12': 47,  # - Color2_디테일이미지12 (+1)
    'color3Gallery1': 48,  # - Color3_디테일이미지1 (+1)
    'color3Gallery2': 49,  # - Color3_디테일이미지2 (+1)
    'color3Gallery3': 50,  # - Color3_디테일이미지3 (+1)
    'color3Gallery4': 51,  # - Color3_디테일이미지4 (+1)
    'color3Gallery5': 52,  # - Color3_디테일이미지5 (+1)
    'color3Gallery6': 53,  # - Color3_디테일이미지6 (+1)
    'color3Gallery7': 54,  # - Color3_디테일이미지7 (+1)
    'color3Gallery8': 55,  # - Color3_디테일이미지8 (+1)
    'color3Gallery9': 56,  # - Color3_디테일이미지9 (+1)
    'color3Gallery10': 57,  # - Color3_디테일이미지10 (+1)
    'color3Gallery11': 58,  # - Color3_디테일이미지11 (+1)
    'color3Gallery12': 59,  # - Color3_디테일이미지12 (+1)
    'color4Gallery1': 60,  # - Color4_디테일이미지1 (+1)
    'color4Gallery2': 61,  # - Color4_디테일이미지2 (+1)
    'color4Gallery3': 62,  # - Color4_디테일이미지3 (+1)
    'color4Gallery4': 63,  # - Color4_디테일이미지4 (+1)
    'color4Gallery5': 64,  # - Color4_디테일이미지5 (+1)
    'color4Gallery6': 65,  # - Color4_디테일이미지6 (+1)
    'color4Gallery7': 66,  # - Color4_디테일이미지7 (+1)
    'color4Gallery8': 67,  # - Color4_디테일이미지8 (+1)
    'color4Gallery9': 68,  # - Color4_디테일이미지9 (+1)
    'color4Gallery10': 69,  # - Color4_디테일이미지10 (+1)
    'color4Gallery11': 70,  # - Color4_디테일이미지11 (+1)
    'color4Gallery12': 71,  # - Color4_디테일이미지12 (+1)
    'color5Gallery1': 72,  # - Color5_디테일이미지1 (+1)
    'color5Gallery2': 73,  # - Color5_디테일이미지2 (+1)
    'color5Gallery3': 74,  # - Color5_디테일이미지3 (+1)
    'color5Gallery4': 75,  # - Color5_디테일이미지4 (+1)
    'color5Gallery5': 76,  # - Color5_디테일이미지5 (+1)
    'color5Gallery6': 77,  # - Color5_디테일이미지6 (+1)
    'color5Gallery7': 78,  # - Color5_디테일이미지7 (+1)
    'color5Gallery8': 79,  # - Color5_디테일이미지8 (+1)
    'color5Gallery9': 80,  # - Color5_디테일이미지9 (+1)
    'color5Gallery10': 81,  # - Color5_디테일이미지10 (+1)
    'color5Gallery11': 82,  # - Color5_디테일이미지11 (+1)
    'color5Gallery12': 83,  # - Color5_디테일이미지12 (+1)
    'color6Gallery1': 84,  # - Color6_디테일이미지1 (+1)
    'color6Gallery2': 85,  # - Color6_디테일이미지2 (+1)
    'color6Gallery3': 86,  # - Color6_디테일이미지3 (+1)
    'color6Gallery4': 87,  # - Color6_디테일이미지4 (+1)
    'color6Gallery5': 88,  # - Color6_디테일이미지5 (+1)
    'color6Gallery6': 89,  # - Color6_디테일이미지6 (+1)
    'color6Gallery7': 90,  # - Color6_디테일이미지7 (+1)
    'color6Gallery8': 91,  # - Color6_디테일이미지8 (+1)
    'color6Gallery9': 92,  # - Color6_디테일이미지9 (+1)
    'color6Gallery10': 93,  # - Color6_디테일이미지10 (+1)
    'color6Gallery11': 94,  # - Color6_디테일이미지11 (+1)
    'color6Gallery12': 95,  # - Color6_디테일이미지12 (+1)
    'color7Gallery1': 96,  # - Color7_디테일이미지1 (+1)
    'color7Gallery2': 97,  # - Color7_디테일이미지2 (+1)
    'color7Gallery3': 98,  # - Color7_디테일이미지3 (+1)
    'color7Gallery4': 99,  # - Color7_디테일이미지4 (+1)
    'color7Gallery5': 100,  # - Color7_디테일이미지5 (+1)
    'color7Gallery6': 101,  # - Color7_디테일이미지6 (+1)
    'color7Gallery7': 102,  # - Color7_디테일이미지7 (+1)
    'color7Gallery8': 103,  # - Color7_디테일이미지8 (+1)
    'color7Gallery9': 104,  # - Color7_디테일이미지9 (+1)
    'color7Gallery10': 105,  # - Color7_디테일이미지10 (+1)
    'color7Gallery11': 106,  # - Color7_디테일이미지11 (+1)
    'color7Gallery12': 107,  # - Color7_디테일이미지12 (+1)
    'color8Gallery1': 108,  # - Color8_디테일이미지1 (+1)
    'color8Gallery2': 109,  # - Color8_디테일이미지2 (+1)
    'color8Gallery3': 110,  # - Color8_디테일이미지3 (+1)
    'color8Gallery4': 111,  # - Color8_디테일이미지4 (+1)
    'color8Gallery5': 112,  # - Color8_디테일이미지5 (+1)
    'color8Gallery6': 113,  # - Color8_디테일이미지6 (+1)
    'color8Gallery7': 114,  # - Color8_디테일이미지7 (+1)
    'color8Gallery8': 115,  # - Color8_디테일이미지8 (+1)
    'color8Gallery9': 116,  # - Color8_디테일이미지9 (+1)
    'color8Gallery10': 117,  # - Color8_디테일이미지10 (+1)
    'color8Gallery11': 118,  # - Color8_디테일이미지11 (+1)
    'color8Gallery12': 119,  # - Color8_디테일이미지12 (+1)

    # Product Shots by Color (columns 120-127) - SHIFTED (+1)
    'color1ProductShot': 120,     # - 컬러1_상품컷_url (+1)
    'color2ProductShot': 121,     # - 컬러2_상품컷_url (+1)
    'color3ProductShot': 122,     # - 컬러3_상품컷_url (+1)
    'color4ProductShot': 123,     # - 컬러4_상품컷_url (+1)
    'color5ProductShot': 124,     # - 컬러5_상품컷_url (+1)
    'color6ProductShot': 125,     # - 컬러6_상품컷_url (+1)
    'color7ProductShot': 126,     # - 컬러7_상품컷_url (+1)
    'color8ProductShot': 127,     # - 컬러8_상품컷_url (+1)

    # Fabric Info (columns 128-135) - SHIFTED (+1)
    'fabricImage': 128,       # DY - 소재이미지 (+1)
    'fabricComposition': 129, # DZ - 소재구성 (+1)
    'fabricDesc': 130,        # EA - 소재설명1 (+1)
    'fabricTransparency': 131,  # EB - 비침 (+1)
    'fabricStretch': 132,       # EC - 신축성 (+1)
    'fabricLining': 133,        # ED - 안감 (+1)
    'fabricThickness': 134,     # EE - 두께감 (+1)
    'fabricSeason': 135,        # EF - 계절감 (+1)

    # Size Image (column 136) - SHIFTED (+1)
    'sizeImage': 136,         # EG - 사이즈 이미지 (+1)

    # Product Info (columns 137-142) - SHIFTED (+1)
    'productName': 137,       # EH - 제품명 (+1)
    'colorName': 138,         # EI - 컬러명 (+1)
    'sizeName': 139,          # EJ - 사이즈 (+1)
    'fabric': 140,            # EK - 패브릭 (+1)
    'washingInfo': 141,       # EL - 세탁법 (+1)
    'origin': 142,            # EM - 생산지 (+1)

    # Top Sizes (columns 143-222) - 10 sizes, 8 fields each - SHIFTED (+1)
    'topSize1Name': 143,      # - 상의_사이즈_1 (+1)
    'topSize1Shoulder': 144,  # - 상의_어깨너비_1 (+1)
    'topSize1Chest': 145,     # - 상의_가슴둘레_1 (+1)
    'topSize1Hem': 146,       # - 상의_밑단둘레_1 (+1)
    'topSize1SleeveLength': 147, # - 상의_소매길이_1 (+1)
    'topSize1SleeveOpening': 148, # - 상의_소매통_1 (+1)
    'topSize1TotalLength': 149,  # - 상의_총장_1 (+1)
    'topSize1Optional': 150,     # - 상의_옵셔널Row_1 (+1)
    'topSize2Name': 151,      # - 상의_사이즈_2 (+1)
    'topSize2Shoulder': 152,  # - 상의_어깨너비_2 (+1)
    'topSize2Chest': 153,     # - 상의_가슴둘레_2 (+1)
    'topSize2Hem': 154,       # - 상의_밑단둘레_2 (+1)
    'topSize2SleeveLength': 155, # - 상의_소매길이_2 (+1)
    'topSize2SleeveOpening': 156, # - 상의_소매통_2 (+1)
    'topSize2TotalLength': 157,  # - 상의_총장_2 (+1)
    'topSize2Optional': 158,     # - 상의_옵셔널Row_2 (+1)
    'topSize3Name': 159,      # - 상의_사이즈_3 (+1)
    'topSize3Shoulder': 160,  # - 상의_어깨너비_3 (+1)
    'topSize3Chest': 161,     # - 상의_가슴둘레_3 (+1)
    'topSize3Hem': 162,       # - 상의_밑단둘레_3 (+1)
    'topSize3SleeveLength': 163, # - 상의_소매길이_3 (+1)
    'topSize3SleeveOpening': 164, # - 상의_소매통_3 (+1)
    'topSize3TotalLength': 165,  # - 상의_총장_3 (+1)
    'topSize3Optional': 166,     # - 상의_옵셔널Row_3 (+1)
    'topSize4Name': 167,      # - 상의_사이즈_4 (+1)
    'topSize4Shoulder': 168,  # - 상의_어깨너비_4 (+1)
    'topSize4Chest': 169,     # - 상의_가슴둘레_4 (+1)
    'topSize4Hem': 170,       # - 상의_밑단둘레_4 (+1)
    'topSize4SleeveLength': 171, # - 상의_소매길이_4 (+1)
    'topSize4SleeveOpening': 172, # - 상의_소매통_4 (+1)
    'topSize4TotalLength': 173,  # - 상의_총장_4 (+1)
    'topSize4Optional': 174,     # - 상의_옵셔널Row_4 (+1)
    'topSize5Name': 175,      # - 상의_사이즈_5 (+1)
    'topSize5Shoulder': 176,  # - 상의_어깨너비_5 (+1)
    'topSize5Chest': 177,     # - 상의_가슴둘레_5 (+1)
    'topSize5Hem': 178,       # - 상의_밑단둘레_5 (+1)
    'topSize5SleeveLength': 179, # - 상의_소매길이_5 (+1)
    'topSize5SleeveOpening': 180, # - 상의_소매통_5 (+1)
    'topSize5TotalLength': 181,  # - 상의_총장_5 (+1)
    'topSize5Optional': 182,     # - 상의_옵셔널Row_5 (+1)
    'topSize6Name': 183,      # - 상의_사이즈_6 (+1)
    'topSize6Shoulder': 184,  # - 상의_어깨너비_6 (+1)
    'topSize6Chest': 185,     # - 상의_가슴둘레_6 (+1)
    'topSize6Hem': 186,       # - 상의_밑단둘레_6 (+1)
    'topSize6SleeveLength': 187, # - 상의_소매길이_6 (+1)
    'topSize6SleeveOpening': 188, # - 상의_소매통_6 (+1)
    'topSize6TotalLength': 189,  # - 상의_총장_6 (+1)
    'topSize6Optional': 190,     # - 상의_옵셔널Row_6 (+1)
    'topSize7Name': 191,      # - 상의_사이즈_7 (+1)
    'topSize7Shoulder': 192,  # - 상의_어깨너비_7 (+1)
    'topSize7Chest': 193,     # - 상의_가슴둘레_7 (+1)
    'topSize7Hem': 194,       # - 상의_밑단둘레_7 (+1)
    'topSize7SleeveLength': 195, # - 상의_소매길이_7 (+1)
    'topSize7SleeveOpening': 196, # - 상의_소매통_7 (+1)
    'topSize7TotalLength': 197,  # - 상의_총장_7 (+1)
    'topSize7Optional': 198,     # - 상의_옵셔널Row_7 (+1)
    'topSize8Name': 199,      # - 상의_사이즈_8 (+1)
    'topSize8Shoulder': 200,  # - 상의_어깨너비_8 (+1)
    'topSize8Chest': 201,     # - 상의_가슴둘레_8 (+1)
    'topSize8Hem': 202,       # - 상의_밑단둘레_8 (+1)
    'topSize8SleeveLength': 203, # - 상의_소매길이_8 (+1)
    'topSize8SleeveOpening': 204, # - 상의_소매통_8 (+1)
    'topSize8TotalLength': 205,  # - 상의_총장_8 (+1)
    'topSize8Optional': 206,     # - 상의_옵셔널Row_8 (+1)
    'topSize9Name': 207,      # - 상의_사이즈_9 (+1)
    'topSize9Shoulder': 208,  # - 상의_어깨너비_9 (+1)
    'topSize9Chest': 209,     # - 상의_가슴둘레_9 (+1)
    'topSize9Hem': 210,       # - 상의_밑단둘레_9 (+1)
    'topSize9SleeveLength': 211, # - 상의_소매길이_9 (+1)
    'topSize9SleeveOpening': 212, # - 상의_소매통_9 (+1)
    'topSize9TotalLength': 213,  # - 상의_총장_9 (+1)
    'topSize9Optional': 214,     # - 상의_옵셔널Row_9 (+1)
    'topSize10Name': 215,      # - 상의_사이즈_10 (+1)
    'topSize10Shoulder': 216,  # - 상의_어깨너비_10 (+1)
    'topSize10Chest': 217,     # - 상의_가슴둘레_10 (+1)
    'topSize10Hem': 218,       # - 상의_밑단둘레_10 (+1)
    'topSize10SleeveLength': 219, # - 상의_소매길이_10 (+1)
    'topSize10SleeveOpening': 220, # - 상의_소매통_10 (+1)
    'topSize10TotalLength': 221,  # - 상의_총장_10 (+1)
    'topSize10Optional': 222,     # - 상의_옵셔널Row_10 (+1)

    # Bottom Sizes (columns 223-302) - 10 sizes, 8 fields each - SHIFTED (+1)
    'bottomSize1Name': 223,      # - 하의_사이즈_1 (+1)
    'bottomSize1Waist': 224,     # - 하의_허리둘레_1 (+1)
    'bottomSize1Hip': 225,       # - 하의_엉덩이둘레_1 (+1)
    'bottomSize1Thigh': 226,     # - 하의_허벅지둘레_1 (+1)
    'bottomSize1Hem': 227,       # - 하의_밑단둘레_1 (+1)
    'bottomSize1Rise': 228,      # - 하의_밑위길이_1 (+1)
    'bottomSize1TotalLength': 229,  # - 하의_총장_1 (+1)
    'bottomSize1Optional': 230,     # - 하의_옵셔널Row_1 (+1)
    'bottomSize2Name': 231,      # - 하의_사이즈_2 (+1)
    'bottomSize2Waist': 232,     # - 하의_허리둘레_2 (+1)
    'bottomSize2Hip': 233,       # - 하의_엉덩이둘레_2 (+1)
    'bottomSize2Thigh': 234,     # - 하의_허벅지둘레_2 (+1)
    'bottomSize2Hem': 235,       # - 하의_밑단둘레_2 (+1)
    'bottomSize2Rise': 236,      # - 하의_밑위길이_2 (+1)
    'bottomSize2TotalLength': 237,  # - 하의_총장_2 (+1)
    'bottomSize2Optional': 238,     # - 하의_옵셔널Row_2 (+1)
    'bottomSize3Name': 239,      # - 하의_사이즈_3 (+1)
    'bottomSize3Waist': 240,     # - 하의_허리둘레_3 (+1)
    'bottomSize3Hip': 241,       # - 하의_엉덩이둘레_3 (+1)
    'bottomSize3Thigh': 242,     # - 하의_허벅지둘레_3 (+1)
    'bottomSize3Hem': 243,       # - 하의_밑단둘레_3 (+1)
    'bottomSize3Rise': 244,      # - 하의_밑위길이_3 (+1)
    'bottomSize3TotalLength': 245,  # - 하의_총장_3 (+1)
    'bottomSize3Optional': 246,     # - 하의_옵셔널Row_3 (+1)
    'bottomSize4Name': 247,      # - 하의_사이즈_4 (+1)
    'bottomSize4Waist': 248,     # - 하의_허리둘레_4 (+1)
    'bottomSize4Hip': 249,       # - 하의_엉덩이둘레_4 (+1)
    'bottomSize4Thigh': 250,     # - 하의_허벅지둘레_4 (+1)
    'bottomSize4Hem': 251,       # - 하의_밑단둘레_4 (+1)
    'bottomSize4Rise': 252,      # - 하의_밑위길이_4 (+1)
    'bottomSize4TotalLength': 253,  # - 하의_총장_4 (+1)
    'bottomSize4Optional': 254,     # - 하의_옵셔널Row_4 (+1)
    'bottomSize5Name': 255,      # - 하의_사이즈_5 (+1)
    'bottomSize5Waist': 256,     # - 하의_허리둘레_5 (+1)
    'bottomSize5Hip': 257,       # - 하의_엉덩이둘레_5 (+1)
    'bottomSize5Thigh': 258,     # - 하의_허벅지둘레_5 (+1)
    'bottomSize5Hem': 259,       # - 하의_밑단둘레_5 (+1)
    'bottomSize5Rise': 260,      # - 하의_밑위길이_5 (+1)
    'bottomSize5TotalLength': 261,  # - 하의_총장_5 (+1)
    'bottomSize5Optional': 262,     # - 하의_옵셔널Row_5 (+1)
    'bottomSize6Name': 263,      # - 하의_사이즈_6 (+1)
    'bottomSize6Waist': 264,     # - 하의_허리둘레_6 (+1)
    'bottomSize6Hip': 265,       # - 하의_엉덩이둘레_6 (+1)
    'bottomSize6Thigh': 266,     # - 하의_허벅지둘레_6 (+1)
    'bottomSize6Hem': 267,       # - 하의_밑단둘레_6 (+1)
    'bottomSize6Rise': 268,      # - 하의_밑위길이_6 (+1)
    'bottomSize6TotalLength': 269,  # - 하의_총장_6 (+1)
    'bottomSize6Optional': 270,     # - 하의_옵셔널Row_6 (+1)
    'bottomSize7Name': 271,      # - 하의_사이즈_7 (+1)
    'bottomSize7Waist': 272,     # - 하의_허리둘레_7 (+1)
    'bottomSize7Hip': 273,       # - 하의_엉덩이둘레_7 (+1)
    'bottomSize7Thigh': 274,     # - 하의_허벅지둘레_7 (+1)
    'bottomSize7Hem': 275,       # - 하의_밑단둘레_7 (+1)
    'bottomSize7Rise': 276,      # - 하의_밑위길이_7 (+1)
    'bottomSize7TotalLength': 277,  # - 하의_총장_7 (+1)
    'bottomSize7Optional': 278,     # - 하의_옵셔널Row_7 (+1)
    'bottomSize8Name': 279,      # - 하의_사이즈_8 (+1)
    'bottomSize8Waist': 280,     # - 하의_허리둘레_8 (+1)
    'bottomSize8Hip': 281,       # - 하의_엉덩이둘레_8 (+1)
    'bottomSize8Thigh': 282,     # - 하의_허벅지둘레_8 (+1)
    'bottomSize8Hem': 283,       # - 하의_밑단둘레_8 (+1)
    'bottomSize8Rise': 284,      # - 하의_밑위길이_8 (+1)
    'bottomSize8TotalLength': 285,  # - 하의_총장_8 (+1)
    'bottomSize8Optional': 286,     # - 하의_옵셔널Row_8 (+1)
    'bottomSize9Name': 287,      # - 하의_사이즈_9 (+1)
    'bottomSize9Waist': 288,     # - 하의_허리둘레_9 (+1)
    'bottomSize9Hip': 289,       # - 하의_엉덩이둘레_9 (+1)
    'bottomSize9Thigh': 290,     # - 하의_허벅지둘레_9 (+1)
    'bottomSize9Hem': 291,       # - 하의_밑단둘레_9 (+1)
    'bottomSize9Rise': 292,      # - 하의_밑위길이_9 (+1)
    'bottomSize9TotalLength': 293,  # - 하의_총장_9 (+1)
    'bottomSize9Optional': 294,     # - 하의_옵셔널Row_9 (+1)
    'bottomSize10Name': 295,      # - 하의_사이즈_10 (+1)
    'bottomSize10Waist': 296,     # - 하의_허리둘레_10 (+1)
    'bottomSize10Hip': 297,       # - 하의_엉덩이둘레_10 (+1)
    'bottomSize10Thigh': 298,     # - 하의_허벅지둘레_10 (+1)
    'bottomSize10Hem': 299,       # - 하의_밑단둘레_10 (+1)
    'bottomSize10Rise': 300,      # - 하의_밑위길이_10 (+1)
    'bottomSize10TotalLength': 301,  # - 하의_총장_10 (+1)
    'bottomSize10Optional': 302,     # - 하의_옵셔널Row_10 (+1)
}

SERVICE_ACCOUNT_FILE = PROJECT_ROOT / "credentials" / "service-account.json"

# API Scopes
SCOPES = [
    'https://www.googleapis.com/auth/spreadsheets.readonly',
    'https://www.googleapis.com/auth/drive.readonly'
]

# Output Directories
OUTPUT_DIR = PROJECT_ROOT / "output"
ASSETS_DIR = OUTPUT_DIR / "assets" / "images"
EXPORTS_DIR = PROJECT_ROOT / "exports"
STANDALONE_EXPORTS_DIR = EXPORTS_DIR / "standalone"
IMAGES_EXPORTS_DIR = EXPORTS_DIR / "images"

# Data Files
DATA_DIR = PROJECT_ROOT / "data"
PRODUCTS_DATA_PATH = DATA_DIR / "products.json"
TEMPLATE_PATH = DATA_DIR / "templates" / "dana_product_template.json"

# Logging Configuration
LOG_FILE = PROJECT_ROOT / "dana_page_generation.log"
LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# HTML Template Settings
BRAND_NAME = "DANA&PETA"
BRAND_LOGO_TEXT = "queenit made"

# Image Processing Settings
COLOR_EXTRACTION_CROP_PERCENT = 0.3  # Center crop 30%
COLOR_EXTRACTION_BRIGHTNESS_THRESHOLD = 240  # Filter out bright pixels
COLOR_EXTRACTION_KMEANS_CLUSTERS = 3  # Number of K-means clusters
COLOR_EXTRACTION_KMEANS_ITERATIONS = 10  # Max iterations

# Date format for output folders
DATE_FORMAT = "%Y-%m-%d"
DATETIME_FORMAT = "%Y%m%d_%H%M%S"

# Folder names
ORIGINAL_FOLDER = "원본"
EDITABLE_FOLDER = "에디터블"
EXPORT_FOLDER = "익스포트"

# File naming patterns
ORIGINAL_FILE_PATTERN = "{productCode}.html"
EDITABLE_FILE_PATTERN = "{productCode}_editable.html"
STANDALONE_FILE_PATTERN = "{productCode}_standalone_{timestamp}.html"
IMAGE_FILE_PATTERN = "{productCode}_{timestamp}.jpg"

# Validation settings
REQUIRED_FIELDS = ["productCode", "title", "mainImage"]

# Export settings
STANDALONE_QUALITY = 85  # Base64 quality
IMAGE_QUALITY = 85  # JPG quality for exports
IMAGE_VIEWPORT_WIDTH = 360  # Mobile viewport width

# Version
VERSION = "1.0.0"
