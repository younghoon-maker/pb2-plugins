---
id: PRODUCT-001
version: 0.1.1
status: active
created: 2025-10-15
updated: 2025-10-15
author: @younghoonjung
priority: high
category: feature
labels:
  - figma-to-html
  - page-builder
  - product-detail
---

# pb_pb2_new_page Product Specification

## HISTORY

### v0.1.1 (2025-10-15)
- **CHANGED**: Figma 섹션 구조를 실제 디자인 콘텐츠 기반으로 재정의
- **CHANGED**: 스프레드시트 컬럼 설계를 새 섹션 구조에 맞춰 업데이트
- **AUTHOR**: @younghoonjung
- **REASON**: DANA 레퍼런스 명칭 대신 새 Figma 디자인의 실제 콘텐츠 반영
- **DETAILS**:
  - 10개 섹션 명칭: Product Hero, Color Variants, Lifestyle Gallery, Material Detail, Color Selector, Product Info, Care Instructions, Model Info, Size Guide, Size Chart
  - Figma Group ID 매핑 추가 (추적성 향상)

### v0.1.0 (2025-10-15)
- **INITIAL**: pb_pb2_new_page 프로젝트 Product Discovery 완료
- **AUTHOR**: @younghoonjung
- **SECTIONS**: Mission, Users, Problems, Solutions

---

## @DOC:MISSION-001 핵심 미션

**Figma 디자인을 1:1 픽셀 퍼펙트 HTML로 변환하는 상품 상세페이지 빌더**

### 비전
디자이너가 Figma에서 작성한 상품 상세페이지를 개발자 개입 없이 완벽하게 HTML로 변환하고, 데이터는 Google Spreadsheet로 관리하여 누구나 쉽게 상품페이지를 생성/수정/배포할 수 있는 시스템을 구축한다.

### 핵심 가치
- **픽셀 퍼펙트**: Figma 디자인과 100% 일치하는 HTML 출력
- **데이터 분리**: 디자인(Figma) + 데이터(Spreadsheet) 분리 아키텍처
- **편집 자유도**: 생성된 HTML을 브라우저에서 직접 편집 가능
- **다중 포맷 출력**: HTML, JPG 동시 익스포트

---

## @SPEC:USER-001 주요 사용자층

### 1차 사용자: 프로젝트 오너 (본인)
- **대상**: 프로젝트 오너 (본인)
- **핵심 니즈**:
  - Figma 디자인 제작, 스프레드시트 데이터 입력
  - 페이지 생성/배포 자동화
  - 빠른 반복 작업
- **핵심 시나리오**:
  1. Figma에서 상세페이지 디자인 완성
  2. Google Spreadsheet에 상품 정보 입력
  3. Python 스크립트 실행 → HTML 생성
  4. 브라우저에서 미리보기 → 필요시 편집
  5. JPG/HTML 익스포트 → 배포

### 2차 사용자: 협업자 (로컬 랩탑 사용자)
- **대상**: 협업자 (로컬 랩탑 사용자)
- **핵심 니즈**:
  - 생성된 페이지 편집
  - 이미지 교체
  - 익스포트
- **기술 수준**: 브라우저 사용 가능

---

## @SPEC:PROBLEM-001 해결하는 핵심 문제

### 우선순위 높음 (최우선)

#### 1. Figma → HTML 변환의 픽셀 완벽성

**현황**:
- Figma의 디자인 스펙: 1080×25520px (11개 주요 섹션)
- 기존 도구들의 한계: 자동 변환 시 레이아웃 왜곡, 폰트 불일치, 여백 오차

**요구사항 (EARS)**:

##### Ubiquitous Requirements
- 시스템은 Figma MCP를 통해 디자인 메타데이터를 추출해야 한다
- 시스템은 1080px 기준 레이아웃을 정확히 재현해야 한다
- 시스템은 Pretendard 폰트를 웹폰트로 로드해야 한다

##### Event-driven Requirements
- WHEN Figma 디자인이 업데이트되면, 시스템은 변경사항을 감지하고 재생성을 알려야 한다
- WHEN HTML 생성 시 Figma 노드와 위치/크기가 일치하지 않으면, 시스템은 오차 리포트를 생성해야 한다

##### Constraints
- 생성된 HTML의 레이아웃 오차는 ±2px 이내여야 한다
- 모든 텍스트는 Figma 폰트 스타일(weight, size, line-height)과 일치해야 한다

#### 2. 이미지 편집 및 관리

**현황**:
- 레퍼런스(DANA&PETA)는 이미지 확대/축소/이동 기능 제공
- 단일 HTML 파일로 배포 시 Base64 인코딩 필요

**요구사항 (EARS)**:

##### Ubiquitous Requirements
- 시스템은 에디터블 모드에서 이미지 크롭 영역을 조정할 수 있어야 한다
- 시스템은 이미지를 Base64로 인코딩하여 단일 HTML에 임베드해야 한다

##### Event-driven Requirements
- WHEN 사용자가 이미지 파일을 드래그앤드롭하면, 시스템은 해당 이미지를 교체해야 한다
- WHEN 이미지 크기가 2MB를 초과하면, 시스템은 자동 압축을 제안해야 한다

##### Optional Features
- WHERE 원본 이미지가 제공되면, 시스템은 다양한 크롭 비율을 제안할 수 있다

#### 3. 구글 스프레드시트 데이터 연동

**현황**:
- 레퍼런스는 96개 컬럼 구조 사용
- 신규 Figma 디자인은 다른 데이터 구조 요구

**요구사항 (EARS)**:

##### Ubiquitous Requirements
- 시스템은 Google Sheets API를 통해 데이터를 로드해야 한다
- 시스템은 Figma 섹션별 데이터 매핑 스키마를 정의해야 한다

##### State-driven Requirements
- WHILE 스프레드시트 데이터가 로드 중일 때, 시스템은 로딩 인디케이터를 표시해야 한다
- WHILE 스프레드시트 접근 권한이 없을 때, 시스템은 인증 가이드를 제공해야 한다

##### Constraints
- IF 필수 컬럼이 누락되면, 시스템은 HTML 생성을 중단하고 오류를 표시해야 한다
- 스프레드시트 로드 시간은 5초를 초과하지 않아야 한다

---

## @DOC:STRATEGY-001 차별점 및 강점

### 경쟁 솔루션 대비 강점

#### 1. Figma MCP 기반 픽셀 퍼펙트 변환
- **발휘 시나리오**: 디자이너가 Figma에서 디자인 변경 시 즉시 HTML에 반영
- **기술적 우위**: Figma MCP를 통한 정밀한 메타데이터 추출

#### 2. 데이터와 디자인의 완전 분리
- **발휘 시나리오**: 디자인 변경 없이 상품 데이터만 Spreadsheet에서 수정하여 대량 페이지 생성
- **운영 효율**: 비개발자도 데이터 관리 가능

#### 3. 로컬 환경 완전 자동화
- **발휘 시나리오**: 서버 구축 없이 개인 랩탑에서 즉시 사용
- **보안 우위**: 외부 서버 의존 없음, 데이터 유출 위험 최소화

---

## @SPEC:SUCCESS-001 성공 지표

### 즉시 측정 가능한 KPI

#### 1. 픽셀 정확도
- **목표**: Figma 대비 ±2px 이내 오차
- **측정 방법**: 자동화된 스크린샷 비교 (Figma vs Generated HTML)

#### 2. 페이지 생성 시간
- **목표**: 1페이지당 30초 이내
- **측정 방법**: Python 스크립트 실행 시간 로깅

#### 3. 익스포트 성공률
- **목표**: JPG/HTML 익스포트 100% 성공
- **측정 방법**: 익스포트 오류 로그 모니터링

### 측정 주기
- **일간**: 페이지 생성 횟수, 평균 생성 시간
- **주간**: 픽셀 오차 분석 리포트
- **월간**: 사용자 피드백 수집 및 개선사항 반영

---

## Legacy Context

### 기존 자산 요약

**DANA&PETA 페이지 빌더 (reference/dana/)**:
- **활용 가능 모듈**:
  - Google Sheets 데이터 로더 (`load_from_sheets.py`)
  - Base64 이미지 인코더
  - Flask 익스포트 서버 (Port 5001)
  - 에디터블 HTML 템플릿 (이미지 크롭 UI)

- **아키텍처 패턴**:
  - Python 스크립트 → Jinja2 템플릿 → HTML 생성
  - Original HTML (읽기 전용) + Editable HTML (편집 가능)
  - html2canvas를 통한 JPG 변환

- **주요 학습 포인트**:
  - 96컬럼 스프레드시트 구조 설계
  - Base64 인코딩으로 단일 HTML 파일 생성
  - 브라우저 내 이미지 편집 UI (CSS Transform 활용)

---

## @DOC:FIGMA-SPEC-001 Figma 디자인 스펙

### 전체 캔버스
- **크기**: 1080px × 25520px
- **폰트**: Pretendard (Light, Regular)
- **주요 색상**: #FFFFFF (배경), #353535 (텍스트), #D9D9D9 (보더)

### 섹션별 구조

| 순서 | 섹션명 | Figma Group | 크기 | 설명 |
|------|--------|-------------|------|------|
| 1 | Product Hero | Group 10 (1:159) | 1033×1749px | 메인 상품 이미지 + 타이틀 "Ribbed V Neck Cardigan" |
| 2 | Color Variants | Group 1 (1:96) | 1082×1159px | 6개 컬러 옵션 이미지 (3×2 그리드, Ivory/Gray/Black) |
| 3 | Lifestyle Gallery | Group 2 (1:97) | 1042×14943px | 10개 라이프스타일 이미지 + Beige 컬러 + 모델 정보 |
| 4 | Material Detail | Group 3 (1:98) | 1042×2805px | 소재 디테일 3개 이미지 + "탄탄한 신축성으로..." 설명 텍스트 |
| 5 | Color Selector | Group 4 (1:99) | 332×89px | 컬러 선택 UI |
| 6 | Product Info | Group 5 (1:100) | 1044×1043px | 소재 정보(VISCOSE46%+COTTON54%) + 세탁 방법 |
| 7 | Care Instructions | Group 6 (1:154) | 939×294px | 주의사항 리스트 (Check Point) |
| 8 | Model Info | Group 7 (1:155) | 730×352px | 2명 모델 착용 정보 (An: 170cm/S size) |
| 9 | Size Guide | Group 8 (1:156) | 601×151px | 사이즈 가이드 텍스트 |
| 10 | Size Chart | Group 11 (2:1481) | 679×775px | 상세 사이즈 표 |

### 스프레드시트 컬럼 설계 (신규)

**기본 정보**:
- `product_id`: 상품 고유 ID
- `product_name`: 상품명 (예: "Ribbed V Neck Cardigan")
- `price`: 가격 (선택사항)

**섹션 1: Product Hero**:
- `hero_image_url`: 메인 상품 이미지 URL

**섹션 2: Color Variants**:
- `color_variant_1` ~ `color_variant_6`: 컬러 옵션 이미지 URL
- `color_label_1` ~ `color_label_6`: 컬러 레이블 (예: Ivory, Gray, Black)

**섹션 3: Lifestyle Gallery**:
- `lifestyle_image_1` ~ `lifestyle_image_10`: 라이프스타일 이미지 URL
- `lifestyle_color`: 컬러 표시 (예: Beige)
- `lifestyle_model_info`: 모델 착용 정보 (예: "Model : 170cm / S size")

**섹션 4: Material Detail**:
- `material_detail_image_1` ~ `material_detail_image_3`: 소재 디테일 이미지 URL
- `material_description`: 소재 설명 텍스트 (예: "탄탄한 신축성으로 바디라인을 매끄럽게")

**섹션 5: Color Selector**:
- `color_selector_enabled`: 컬러 선택기 활성화 여부 (true/false)

**섹션 6: Product Info**:
- `fabric_composition`: 소재 구성 (예: "VISCOSE46%+COTTON54%")
- `care_method`: 세탁 방법 텍스트

**섹션 7: Care Instructions**:
- `care_instructions`: 주의사항 텍스트 (멀티라인)

**섹션 8: Model Info**:
- `model_1_info`: 모델 1 정보 (예: "An : 170cm / S size")
- `model_2_info`: 모델 2 정보 (선택사항)

**섹션 9: Size Guide**:
- `size_guide_text`: 사이즈 가이드 설명 텍스트

**섹션 10: Size Chart**:
- `size_chart_data`: 사이즈 표 JSON (행×열 구조)

---

## @DOC:CONSTRAINTS-001 제약사항 및 위험

### 기술적 제약

#### Base64 파일 크기
- **위험**: 이미지 많을 시 HTML 파일이 20MB+ 될 수 있음 → 초기 로드 지연
- **완화**: 이미지 압축 옵션 제공, CDN 업로드 옵션 고려

#### Figma API Rate Limit
- **위험**: 시간당 요청 수 제한
- **완화**: 로컬 캐싱, 배치 처리

#### Cross-browser 호환성
- **위험**: html2canvas의 브라우저별 렌더링 차이
- **완화**: 크롬 기준 개발, 다른 브라우저는 경고 표시

### 운영 제약

#### 로컬 환경 전용
- **특징**: 웹 서버 배포 없이 로컬에서만 실행
- **장점**: 보안, 설치 간편
- **단점**: 다중 사용자 동시 작업 불가

#### Google Sheets 접근 권한
- **요구사항**: 각 사용자가 OAuth 인증 필요
- **완화**: 서비스 계정 사용 옵션 제공

---

## TODO:SPEC-BACKLOG-001 다음 단계 SPEC 후보

### Phase 1: 기본 파이프라인 구축
1. **SPEC-FIGMA-001**: Figma MCP 연동 및 메타데이터 파싱
2. **SPEC-SHEETS-001**: Google Sheets 데이터 로더 구현
3. **SPEC-HTML-001**: HTML 템플릿 생성 (픽셀 퍼펙트 레이아웃)

### Phase 2: 에디터블 모드
4. **SPEC-EDIT-001**: 이미지 크롭 UI 구현
5. **SPEC-EDIT-002**: 이미지 교체 기능
6. **SPEC-EXPORT-001**: JPG/HTML 익스포트 서버

### Phase 3: 최적화 및 검증
7. **SPEC-QA-001**: 픽셀 정확도 자동 검증 시스템
8. **SPEC-PERF-001**: Base64 이미지 최적화
9. **SPEC-DOC-001**: 사용자 가이드 작성

---

_이 문서는 `/alfred:1-spec` 실행 시 SPEC 작성의 기반이 됩니다._
