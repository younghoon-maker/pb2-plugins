---
id: TECH-001
version: 0.1.0
status: active
created: 2025-10-15
updated: 2025-10-15
author: @younghoonjung
priority: high
category: feature
labels:
  - python
  - flask
  - figma-mcp
  - google-sheets
---

# pb_pb2_new_page Technology Stack

## HISTORY

### v0.1.0 (2025-10-15)
- **INITIAL**: pb_pb2_new_page 기술 스택 결정 완료
- **AUTHOR**: @younghoonjung
- **SECTIONS**: Stack, Framework, Quality, Security, Deploy
- **KEY DECISIONS**: Python 3.11+, Flask, Figma MCP, pytest

---

## @DOC:STACK-001 언어 & 런타임

### 주 언어 선택

- **언어**: Python
- **버전**: 3.11+ (권장: 3.11.9 이상)
- **선택 이유**:
  - **DANA&PETA 레퍼런스 활용**: 검증된 코드베이스 재사용
  - **풍부한 생태계**: Google Sheets API, Pillow, Jinja2 등 성숙한 라이브러리
  - **빠른 프로토타이핑**: 스크립트 기반 파이프라인 구축 용이
  - **MCP 지원**: Python MCP SDK 공식 지원
- **패키지 매니저**: Poetry (의존성 관리 및 가상환경)

**트레이드오프**:
- **장점**: 빠른 개발, 레퍼런스 재사용, 로컬 실행 간편
- **단점**: 성능(C/Rust 대비), 패키징 복잡도

### 멀티 플랫폼 지원

| 플랫폼 | 지원 상태 | 검증 도구 | 주요 제약 |
|--------|-----------|-----------|-----------|
| **macOS** | ✅ 1차 지원 | Python 3.11+ 설치 확인 | Figma Desktop App 필수 (MCP) |
| **Windows** | ✅ 2차 지원 | Python 3.11+ 설치 확인 | Figma Desktop App 필수, 경로 구분자 처리 |
| **Linux** | ⚠️ 제한적 | Python 3.11+ 설치 확인 | Figma Desktop App 없을 시 MCP 불가 |

**EARS 요구사항**:

#### Ubiquitous Requirements
- 시스템은 Python 3.11 이상에서 실행되어야 한다

#### Event-driven Requirements
- WHEN Python 버전이 3.11 미만이면, 시스템은 설치를 중단하고 안내 메시지를 표시해야 한다

#### Constraints
- IF Figma Desktop App이 설치되지 않았으면, 시스템은 Figma MCP 기능을 비활성화하고 경고를 표시해야 한다

---

## @DOC:FRAMEWORK-001 핵심 프레임워크 & 라이브러리

### 1. 주요 의존성

```toml
[tool.poetry.dependencies]
python = "^3.11"

# Web Framework
flask = "^3.0.0"                    # Export Server (Port 5001)
flask-cors = "^4.0.0"                # CORS 설정

# Template Engine
jinja2 = "^3.1.0"                    # HTML 템플릿 렌더링

# Image Processing
pillow = "^10.0.0"                   # 이미지 다운로드, 압축, Base64 인코딩

# Google Sheets API
google-api-python-client = "^2.100.0"  # Sheets 데이터 로드
google-auth = "^2.23.0"              # OAuth 2.0 인증
google-auth-oauthlib = "^1.1.0"      # OAuth 플로우
google-auth-httplib2 = "^0.1.1"      # HTTP 클라이언트

# HTTP Client
requests = "^2.31.0"                 # 이미지 다운로드, API 호출
httpx = "^0.25.0"                    # 비동기 HTTP 클라이언트 (선택)

# Data Validation
pydantic = "^2.4.0"                  # JSON 스키마 검증, 타입 안전성

# Utilities
python-dotenv = "^1.0.0"             # .env 파일 로드
rich = "^13.6.0"                     # CLI 출력 포맷팅
typer = "^0.9.0"                     # CLI 인터페이스 (선택)
```

### 2. 개발 도구

```toml
[tool.poetry.group.dev.dependencies]
# Testing
pytest = "^7.4.0"                    # 테스트 프레임워크
pytest-cov = "^4.1.0"                # 커버리지 측정
pytest-mock = "^3.12.0"              # Mock 객체
pytest-asyncio = "^0.21.0"           # 비동기 테스트 (선택)

# Linting & Formatting
ruff = "^0.1.0"                      # 빠른 린터+포매터 (Flake8+Black 대체)
black = "^23.10.0"                   # 코드 포매터 (백업)
isort = "^5.12.0"                    # import 정렬

# Type Checking
mypy = "^1.6.0"                      # 타입 체커
types-requests = "^2.31.0"           # requests 타입 스텁

# Documentation
mkdocs = "^1.5.0"                    # 문서 생성 (선택)
mkdocs-material = "^9.4.0"           # Material 테마 (선택)
```

### 3. 빌드 시스템

- **빌드 도구**: Poetry (패키지 빌드 및 배포)
- **번들링**: 단일 HTML 파일 생성 (Base64 임베딩)
- **타겟**: 로컬 Python 스크립트 실행 (CLI 또는 직접 호출)
- **성능 목표**:
  - 페이지 생성: 30초 이내
  - 테스트 실행: 10초 이내
  - 전체 파이프라인: 1분 이내

**EARS 요구사항**:

#### Ubiquitous Requirements
- 시스템은 Poetry를 통해 의존성을 관리해야 한다

#### Constraints
- 페이지 생성 시간은 30초를 초과하지 않아야 한다
- 테스트 스위트 실행 시간은 10초를 초과하지 않아야 한다

---

## @DOC:QUALITY-001 품질 게이트 & 정책

### 테스트 커버리지

- **목표**: 85% 이상
- **측정 도구**: pytest-cov
- **실패 시 대응**:
  - 커버리지 < 85%: 경고 표시, PR 블록 (team 모드)
  - 커버리지 < 70%: 빌드 실패

**커버리지 실행**:
```bash
pytest --cov=src --cov-report=html --cov-report=term-missing --cov-fail-under=85
```

### 정적 분석

| 도구 | 역할 | 설정 파일 | 실패 시 조치 |
|------|------|-----------|--------------|
| **ruff** | 린터+포매터 (통합) | `pyproject.toml` | 에러 발생 시 커밋 차단 |
| **mypy** | 타입 체커 | `pyproject.toml` | 타입 에러 발생 시 경고 (strict 모드) |
| **pytest** | 테스트 실행 | `pyproject.toml` | 테스트 실패 시 빌드 차단 |

**ruff 설정 (pyproject.toml)**:
```toml
[tool.ruff]
line-length = 100
target-version = "py311"
select = [
    "E",   # pycodestyle errors
    "W",   # pycodestyle warnings
    "F",   # pyflakes
    "I",   # isort
    "B",   # flake8-bugbear
    "C4",  # flake8-comprehensions
    "UP",  # pyupgrade
]
ignore = [
    "E501",  # line too long (handled by formatter)
]

[tool.ruff.per-file-ignores]
"__init__.py" = ["F401"]  # unused imports in __init__.py
```

**mypy 설정 (pyproject.toml)**:
```toml
[tool.mypy]
python_version = "3.11"
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = true
disallow_any_generics = false
no_implicit_optional = true
warn_redundant_casts = true
warn_unused_ignores = true
warn_no_return = true
check_untyped_defs = true
strict_optional = true
```

### 자동화 스크립트

```bash
# 품질 검사 파이프라인
poetry run pytest --cov=src --cov-fail-under=85    # 테스트 + 커버리지
poetry run ruff check src/ tests/                  # 린트 검사
poetry run ruff format src/ tests/                 # 코드 포맷팅
poetry run mypy src/                               # 타입 체크
poetry run python src/main.py --dry-run            # 파이프라인 검증 (Dry-run)
```

**Make 명령 (Makefile)**:
```makefile
.PHONY: test lint format typecheck qa

test:
	poetry run pytest --cov=src --cov-fail-under=85

lint:
	poetry run ruff check src/ tests/

format:
	poetry run ruff format src/ tests/

typecheck:
	poetry run mypy src/

qa: format lint typecheck test
	@echo "✅ 모든 품질 검사 통과!"
```

**EARS 요구사항**:

#### Ubiquitous Requirements
- 시스템은 85% 이상의 테스트 커버리지를 유지해야 한다

#### Event-driven Requirements
- WHEN 코드가 커밋되면, 시스템은 자동으로 ruff 린팅을 실행해야 한다
- WHEN 테스트가 실패하면, 시스템은 커밋을 차단해야 한다

#### Constraints
- IF 테스트 커버리지가 85% 미만이면, 시스템은 경고를 표시해야 한다
- IF 타입 에러가 발견되면, 시스템은 엄격 모드(strict)에서 실패해야 한다

---

## @DOC:SECURITY-001 보안 정책 & 운영

### 비밀 관리

- **정책**: `.env` 파일로 로컬 관리 (Git 제외)
- **도구**: python-dotenv
- **검증**: `.env.example` 템플릿 제공, 설치 시 자동 확인

**.env 예시**:
```bash
# Figma MCP (Figma Desktop App 인증 자동)
FIGMA_FILE_URL="https://www.figma.com/design/wBdUdgAJtuBr5nn7w38LOB/pb2_new_template"
FIGMA_NODE_ID="1-95"

# Google Sheets API
GOOGLE_SHEETS_CREDENTIALS_PATH="./credentials/google_sheets_credentials.json"
SPREADSHEET_ID="your-spreadsheet-id-here"
SHEET_NAME="Sheet1"
SHEET_RANGE="A2:AZ100"

# Export Server
EXPORT_SERVER_PORT=5001

# Development
DEBUG=true
LOG_LEVEL=DEBUG
```

**.gitignore 필수 항목**:
```
.env
credentials/
*.pyc
__pycache__/
.pytest_cache/
.coverage
htmlcov/
.cache/
dist/
build/
*.egg-info/
```

### 의존성 보안

```toml
[tool.poetry.scripts]
audit = "poetry run pip-audit"
```

**보안 정책**:
- **감사 도구**: pip-audit (Poetry 플러그인)
- **업데이트 정책**: 주간 의존성 업데이트 확인, 중대 취약점 발견 시 즉시 패치
- **취약점 임계값**: CRITICAL/HIGH는 즉시 패치, MEDIUM은 주간 업데이트 시 반영

**감사 실행**:
```bash
poetry run pip-audit
```

### 로깅 정책

- **로그 수준**:
  - **DEBUG**: 개발 환경 (파이프라인 각 단계 상세)
  - **INFO**: 테스트/프로덕션 (주요 이벤트만)
  - **WARNING**: 비정상 상황 (Figma API 실패, 이미지 압축 등)
  - **ERROR**: 파이프라인 중단 (필수 필드 누락, API 타임아웃 등)
  - **CRITICAL**: 시스템 장애 (Python 버전 불일치, 권한 문제 등)

- **민감정보 마스킹**:
  - Google Sheets Credentials: 전체 마스킹
  - 이미지 URL: 도메인만 표시 (예: `https://example.com/***`)
  - 사용자 입력: 길이 제한 (1000자 이상 truncate)

- **보존 정책**:
  - 로그 파일: `logs/` 디렉토리, 30일 보존
  - 에러 로그: 90일 보존

**로깅 설정 (Python)**:
```python
import logging
from rich.logging import RichHandler

logging.basicConfig(
    level=logging.DEBUG if DEBUG else logging.INFO,
    format="%(message)s",
    datefmt="[%X]",
    handlers=[RichHandler(rich_tracebacks=True)],
)
```

**EARS 요구사항**:

#### Ubiquitous Requirements
- 시스템은 민감한 정보를 로그에 기록하지 않아야 한다

#### Event-driven Requirements
- WHEN 로그에 credentials가 감지되면, 시스템은 자동으로 마스킹해야 한다

#### Constraints
- IF .env 파일이 Git에 커밋되려고 하면, 시스템은 차단해야 한다

---

## @DOC:DEPLOY-001 배포 채널 & 전략

### 1. 배포 채널

- **주 채널**: 로컬 설치 (`pip install -e .` 또는 Poetry)
- **릴리스 절차**:
  1. 버전 태그 생성 (`git tag v0.1.0`)
  2. Poetry 빌드 (`poetry build`)
  3. 배포 파일 생성 (`dist/pb_pb2_new_page-0.1.0.tar.gz`)
  4. GitHub Release 첨부 (선택)
- **버전 정책**: Semantic Versioning (v0.1.0 → v0.2.0 → v1.0.0)
- **rollback 전략**: Git 태그 기반 체크아웃 (`git checkout v0.1.0`)

### 2. 개발 설치

```bash
# 1. Poetry 설치 (없을 경우)
curl -sSL https://install.python-poetry.org | python3 -

# 2. 프로젝트 클론
git clone <repository-url>
cd pb_pb2_new_page

# 3. 의존성 설치
poetry install

# 4. 환경 변수 설정
cp .env.example .env
# .env 파일 편집 (Figma URL, Spreadsheet ID 등)

# 5. Google Sheets Credentials 설정
# 1) https://console.cloud.google.com 에서 프로젝트 생성
# 2) Google Sheets API 활성화
# 3) OAuth 2.0 Client ID 생성 (Desktop App)
# 4) credentials.json 다운로드 → credentials/ 디렉토리에 저장

# 6. 실행 (Dry-run 모드)
poetry run python src/main.py --dry-run

# 7. 실행 (실제 생성)
poetry run python src/main.py

# 8. Export Server 실행 (별도 터미널)
poetry run python src/export_server.py
```

### 3. CI/CD 파이프라인

**현재**: CI/CD 없음 (로컬 개발 전용)

**향후 계획** (Phase 2+):

| 단계 | 목적 | 사용 도구 | 성공 조건 |
|------|------|-----------|-----------|
| **Lint & Format** | 코드 품질 검사 | GitHub Actions + ruff | 린트 에러 없음 |
| **Type Check** | 타입 안전성 검증 | mypy | 타입 에러 없음 |
| **Test** | 테스트 실행 | pytest | 모든 테스트 통과, 커버리지 ≥ 85% |
| **Build** | 파이프라인 검증 | Poetry | Dry-run 성공 |
| **Security Audit** | 의존성 취약점 검사 | pip-audit | CRITICAL/HIGH 없음 |

**GitHub Actions 예시 (`.github/workflows/ci.yml`)**:
```yaml
name: CI

on:
  push:
    branches: [main, develop]
  pull_request:

jobs:
  quality:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: "3.11"
      - run: pip install poetry
      - run: poetry install
      - run: poetry run ruff check src/ tests/
      - run: poetry run mypy src/
      - run: poetry run pytest --cov=src --cov-fail-under=85
      - run: poetry run pip-audit
```

**EARS 요구사항**:

#### Ubiquitous Requirements
- 시스템은 로컬 환경에서 Poetry를 통해 설치되어야 한다

#### Optional Features
- WHERE CI/CD가 구성되면, 시스템은 자동으로 품질 검사를 수행할 수 있다

---

## 환경별 설정

### 개발 환경 (`dev`)

```bash
export PROJECT_MODE=development
export LOG_LEVEL=DEBUG
export DEBUG=true

# 실행
poetry run python src/main.py --dry-run
poetry run python src/export_server.py
```

### 테스트 환경 (`test`)

```bash
export PROJECT_MODE=test
export LOG_LEVEL=INFO
export DEBUG=false

# 실행
poetry run pytest --cov=src --cov-fail-under=85
```

### 프로덕션 환경 (`production`)

**참고**: 현재는 로컬 실행 전용이므로 프로덕션 배포 없음

```bash
export PROJECT_MODE=production
export LOG_LEVEL=WARNING
export DEBUG=false

# 실행 (프로덕션 모드)
poetry run python src/main.py
```

---

## @CODE:TECH-DEBT-001 기술 부채 관리

### 현재 기술 부채

**없음** (신규 프로젝트)

### 예상 기술 부채 (Phase 1 완료 후)

1. **Figma MCP 캐싱 전략** - 우선순위: 중간
   - 현재: 매번 API 호출
   - 개선: 로컬 캐시 + TTL 설정 (1시간)
   - 예상 시점: Phase 2

2. **이미지 최적화** - 우선순위: 낮음
   - 현재: 단순 JPEG 압축 (품질 85%)
   - 개선: WebP 변환, 반응형 이미지 생성
   - 예상 시점: Phase 3

3. **비동기 처리** - 우선순위: 낮음
   - 현재: 동기 방식 (순차 실행)
   - 개선: asyncio 기반 병렬 이미지 다운로드
   - 예상 시점: Phase 3 (성능 최적화)

### 개선 계획

- **단기 (1개월)**: Phase 1 완료, 기본 파이프라인 안정화
- **중기 (3개월)**: Figma 캐싱, 에러 핸들링 강화
- **장기 (6개월+)**: 비동기 처리, WebP 지원, CI/CD 구축

---

## 코딩 규칙 (TRUST 5원칙 기반)

### 파일 및 함수 제약

- 파일당 300 LOC 이하
- 함수당 50 LOC 이하
- 매개변수 5개 이하
- 복잡도(Cyclomatic Complexity) 10 이하

### 네이밍 컨벤션

- **모듈**: snake_case (예: `figma_parser.py`)
- **클래스**: PascalCase (예: `FigmaClient`)
- **함수/변수**: snake_case (예: `load_sheets_data()`)
- **상수**: UPPER_SNAKE_CASE (예: `MAX_IMAGE_SIZE`)
- **Private**: 언더스코어 접두사 (예: `_internal_method()`)

### 타입 힌트 (필수)

```python
from typing import Dict, List, Optional
from pydantic import BaseModel

class DesignSpec(BaseModel):
    """Figma 디자인 스펙 데이터 모델"""
    width: int
    height: int
    sections: List[Dict[str, any]]

def parse_figma_layout(node_id: str) -> Optional[DesignSpec]:
    """Figma 노드 ID로부터 레이아웃 정보를 파싱합니다.

    Args:
        node_id: Figma 노드 ID (예: "1-95")

    Returns:
        DesignSpec 객체 또는 None (파싱 실패 시)

    Raises:
        FigmaAPIError: API 호출 실패 시
    """
    # 구현...
```

### 에러 핸들링

```python
class PBError(Exception):
    """pb_pb2_new_page 기본 예외"""
    pass

class FigmaAPIError(PBError):
    """Figma MCP API 호출 실패"""
    pass

class SheetsLoadError(PBError):
    """Google Sheets 데이터 로드 실패"""
    pass

# 사용 예시
try:
    design_spec = figma_parser.parse(node_id)
except FigmaAPIError as e:
    logger.error(f"Figma API 실패: {e}")
    design_spec = load_from_cache(node_id)
```

---

_이 기술 스택은 `/alfred:2-build` 실행 시 TDD 도구 선택과 품질 게이트 적용의 기준이 됩니다._
