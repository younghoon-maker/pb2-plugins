---
id: STRUCTURE-001
version: 0.1.0
status: active
created: 2025-10-15
updated: 2025-10-15
author: @younghoonjung
priority: high
category: feature
labels:
  - architecture
  - pipeline
  - modules
---

# pb_pb2_new_page Structure Design

## HISTORY

### v0.1.0 (2025-10-15)
- **INITIAL**: pb_pb2_new_page 시스템 아키텍처 설계 완료
- **AUTHOR**: @younghoonjung
- **SECTIONS**: Architecture, Modules, Integration, Traceability

---

## @DOC:ARCHITECTURE-001 시스템 아키텍처

### 아키텍처 전략

**3-Tier 파이프라인 아키텍처: Input → Processing → Output**

이 시스템은 Figma 디자인을 HTML로 변환하는 **단방향 데이터 파이프라인**을 채택합니다. 각 계층은 명확한 책임을 가지며, 느슨한 결합을 유지합니다.

```
pb_pb2_new_page Architecture
├── Input Layer          # Figma MCP, Google Sheets API
│   ├── Figma Parser     # 디자인 메타데이터 추출
│   └── Sheets Loader    # 상품 데이터 로드
│
├── Processing Layer     # 데이터 변환 및 HTML 생성
│   ├── HTML Generator   # Jinja2 템플릿 렌더링
│   └── Image Encoder    # Base64 인코딩 및 최적화
│
└── Output Layer         # HTML 파일 및 익스포트
    ├── Edit Controller  # 브라우저 내 이미지 편집 UI
    └── Export Server    # Flask 서버 (JPG/HTML 다운로드)
```

**선택 이유**:
- **단방향 파이프라인**: 데이터 흐름이 명확하여 디버깅 용이
- **계층 분리**: 각 계층을 독립적으로 테스트/개선 가능
- **확장성**: 새로운 데이터 소스(예: Notion) 추가 시 Input Layer만 확장
- **레퍼런스 활용**: DANA&PETA 프로젝트의 검증된 아키텍처 패턴 재사용

**트레이드오프**:
- **실시간 업데이트 불가**: Figma/Sheets 변경 시 수동 재생성 필요 (향후 웹훅 추가 가능)
- **로컬 전용**: 멀티 유저 동시 편집 불가 (현재 요구사항에는 부합)

### 아키텍처 EARS 요구사항

#### Ubiquitous Requirements
- 시스템은 파이프라인 각 단계의 성공/실패를 로깅해야 한다
- 시스템은 모듈 간 JSON 형식으로 데이터를 교환해야 한다

#### Event-driven Requirements
- WHEN Figma API 호출이 실패하면, 시스템은 로컬 캐시를 사용하고 경고를 표시해야 한다
- WHEN 이미지 인코딩이 실패하면, 시스템은 해당 이미지를 placeholder로 대체해야 한다

#### State-driven Requirements
- WHILE 개발 모드일 때, 시스템은 각 파이프라인 단계의 중간 결과물을 저장해야 한다

#### Constraints
- 각 모듈의 복잡도는 10 이하를 유지해야 한다
- 파이프라인 전체 실행 시간은 30초를 초과하지 않아야 한다

---

## @DOC:MODULES-001 모듈별 책임 구분

### 1. Figma Parser (Input Layer)

- **책임**: Figma MCP를 통해 디자인 메타데이터 추출 및 정규화
- **입력**: Figma 파일 URL 또는 노드 ID
- **처리**:
  - Figma MCP API 호출 (`get_metadata`, `get_code`, `get_screenshot`)
  - 노드 트리 순회 및 레이아웃 정보 추출
  - 1080px 기준 절대 좌표 계산
- **출력**: 정규화된 디자인 스펙 JSON

| 컴포넌트 | 역할 | 주요 기능 |
|----------|------|-----------|
| `FigmaClient` | MCP API 래퍼 | 인증, 요청/응답 처리, 에러 핸들링 |
| `LayoutParser` | 레이아웃 분석 | 노드 위치/크기, 스타일 추출 |
| `DesignValidator` | 스펙 검증 | 필수 섹션 존재 여부, 크기 제약 확인 |

**EARS 요구사항**:

##### Ubiquitous Requirements
- Figma Parser는 Pretendard 폰트 스타일(weight, size, line-height)을 정확히 추출해야 한다

##### Event-driven Requirements
- WHEN Figma 노드가 1080px 너비를 벗어나면, Figma Parser는 경고를 생성해야 한다

##### Constraints
- IF Figma 응답 시간이 10초를 초과하면, Figma Parser는 타임아웃하고 캐시를 사용해야 한다

### 2. Sheets Loader (Input Layer)

- **책임**: Google Sheets에서 상품 데이터 로드 및 검증
- **입력**: Spreadsheet ID, 시트 이름, 행 범위
- **처리**:
  - Google Sheets API v4 인증
  - 컬럼 매핑 및 데이터 파싱
  - 필수 필드 검증 및 이미지 URL 유효성 확인
- **출력**: 정규화된 상품 데이터 JSON

| 컴포넌트 | 역할 | 주요 기능 |
|----------|------|-----------|
| `SheetsClient` | Google Sheets API 래퍼 | OAuth 인증, 읽기 작업 |
| `DataMapper` | 컬럼 매핑 | Sheets 컬럼 → 내부 데이터 모델 변환 |
| `DataValidator` | 데이터 검증 | 필수 필드, 이미지 URL, 타입 검증 |

**EARS 요구사항**:

##### Ubiquitous Requirements
- Sheets Loader는 컬러 갤러리 이미지 6개와 상세 이미지 10개를 로드해야 한다

##### State-driven Requirements
- WHILE 스프레드시트 접근 권한이 없을 때, Sheets Loader는 OAuth 인증 가이드를 표시해야 한다

##### Constraints
- IF 필수 컬럼(`product_id`, `product_name`, `hero_image_url`)이 누락되면, Sheets Loader는 예외를 발생시켜야 한다

### 3. HTML Generator (Processing Layer)

- **책임**: Figma 스펙과 상품 데이터를 병합하여 픽셀 퍼펙트 HTML 생성
- **입력**: 디자인 스펙 JSON + 상품 데이터 JSON
- **처리**:
  - Jinja2 템플릿 렌더링
  - Figma 레이아웃 → CSS 절대 포지셔닝 변환
  - Pretendard 웹폰트 로드 코드 삽입
  - 섹션별 HTML 조립
- **출력**: Original HTML (읽기 전용) + Editable HTML (편집 가능)

| 컴포넌트 | 역할 | 주요 기능 |
|----------|------|-----------|
| `TemplateEngine` | Jinja2 래퍼 | 템플릿 로드, 렌더링, 에러 핸들링 |
| `LayoutRenderer` | CSS 생성 | Figma 좌표 → CSS absolute positioning |
| `HTMLAssembler` | HTML 조립 | 섹션별 HTML 병합, 메타태그 삽입 |

**EARS 요구사항**:

##### Ubiquitous Requirements
- HTML Generator는 Figma 디자인 대비 ±2px 이내 오차로 레이아웃을 재현해야 한다

##### Event-driven Requirements
- WHEN Figma와 HTML 레이아웃 오차가 2px를 초과하면, HTML Generator는 오차 리포트를 생성해야 한다

##### Constraints
- 생성된 HTML 파일 크기는 단일 파일 30MB를 초과하지 않아야 한다

### 4. Image Encoder (Processing Layer)

- **책임**: 이미지를 Base64로 인코딩하여 HTML에 임베드
- **입력**: 이미지 URL 목록 (Hero, Color Gallery, Detail Images)
- **처리**:
  - 이미지 다운로드 및 캐싱
  - 2MB 초과 이미지 자동 압축 (JPEG 품질 85%)
  - Base64 인코딩 및 Data URI 생성
- **출력**: Base64 인코딩된 이미지 딕셔너리

| 컴포넌트 | 역할 | 주요 기능 |
|----------|------|-----------|
| `ImageDownloader` | 이미지 다운로드 | HTTP 요청, 로컬 캐시 관리 |
| `ImageCompressor` | 이미지 최적화 | Pillow 기반 리사이징, 압축 |
| `Base64Encoder` | 인코딩 | Base64 변환, Data URI 생성 |

**EARS 요구사항**:

##### Ubiquitous Requirements
- Image Encoder는 모든 이미지를 Base64로 인코딩하여 단일 HTML 파일에 임베드해야 한다

##### Event-driven Requirements
- WHEN 이미지 크기가 2MB를 초과하면, Image Encoder는 자동 압축을 수행하고 로그를 남겨야 한다
- WHEN 이미지 다운로드가 실패하면, Image Encoder는 placeholder 이미지를 사용해야 한다

##### Optional Features
- WHERE 원본 이미지 해상도가 표시 크기의 2배 이상이면, Image Encoder는 자동 리사이징을 제안할 수 있다

### 5. Edit Controller (Output Layer)

- **책임**: 브라우저 내 이미지 편집 UI 제공 (Editable HTML 전용)
- **입력**: 사용자 마우스/터치 입력
- **처리**:
  - 이미지 확대/축소/이동 (CSS Transform)
  - 이미지 파일 드래그앤드롭 교체
  - 크롭 영역 실시간 미리보기
- **출력**: 수정된 HTML (로컬 저장)

| 컴포넌트 | 역할 | 주요 기능 |
|----------|------|-----------|
| `CropController` | 크롭 UI | 마우스 드래그, 줌 인/아웃, 위치 조정 |
| `ImageReplacer` | 이미지 교체 | 드래그앤드롭, Base64 재인코딩 |
| `PreviewManager` | 미리보기 | 변경사항 실시간 반영 |

**EARS 요구사항**:

##### Ubiquitous Requirements
- Edit Controller는 에디터블 모드에서 이미지 크롭 영역을 조정할 수 있어야 한다

##### Event-driven Requirements
- WHEN 사용자가 이미지 파일을 드래그앤드롭하면, Edit Controller는 해당 이미지를 Base64로 재인코딩하고 교체해야 한다

##### State-driven Requirements
- WHILE 편집 중일 때, Edit Controller는 변경사항을 브라우저 로컬 스토리지에 자동 저장해야 한다

### 6. Export Server (Output Layer)

- **책임**: HTML → JPG 변환 및 파일 다운로드 서버
- **입력**: HTML 파일 (Original 또는 Editable)
- **처리**:
  - Flask 서버 실행 (Port 5001)
  - html2canvas를 통한 JPG 렌더링
  - 다운로드 엔드포인트 제공 (`/export/jpg`, `/export/html`)
- **출력**: JPG 파일 + HTML 파일

| 컴포넌트 | 역할 | 주요 기능 |
|----------|------|-----------|
| `FlaskServer` | 웹 서버 | 라우팅, CORS 설정 |
| `CanvasRenderer` | JPG 변환 | html2canvas 실행, 이미지 생성 |
| `FileExporter` | 파일 다운로드 | Content-Disposition 헤더 설정 |

**EARS 요구사항**:

##### Ubiquitous Requirements
- Export Server는 JPG와 HTML 형식으로 페이지를 익스포트해야 한다

##### Event-driven Requirements
- WHEN JPG 변환이 실패하면, Export Server는 에러 메시지와 함께 500 응답을 반환해야 한다

##### Constraints
- Export Server는 5001번 포트를 사용해야 하며, 이미 사용 중일 경우 대체 포트를 찾아야 한다

---

## @DOC:INTEGRATION-001 외부 시스템 통합

### Figma MCP 연동

- **인증 방식**: Figma Desktop App 기반 인증 (MCP 서버 자동 인증)
- **데이터 교환**:
  - 요청: 노드 ID (`1-95`)
  - 응답: XML 메타데이터, React 코드, PNG 스크린샷
- **장애 시 대체**:
  - 로컬 캐시 사용 (`.cache/figma/` 디렉토리)
  - 캐시 없을 시 에러 메시지 표시 및 재시도 안내
- **위험도**: 중간
  - **완화**: Figma API Rate Limit 대응 (시간당 100 요청 제한 고려), 로컬 캐시 전략

**EARS 요구사항**:

##### Event-driven Requirements
- WHEN Figma MCP 응답이 10초를 초과하면, 시스템은 로컬 캐시를 사용하고 경고를 표시해야 한다

##### Constraints
- IF Figma MCP가 3회 연속 실패하면, 시스템은 오프라인 모드로 전환해야 한다

### Google Sheets API 연동

- **용도**: 상품 데이터 로드 (상품명, 가격, 이미지 URL, 텍스트 정보)
- **인증 방식**: OAuth 2.0 (서비스 계정 또는 사용자 계정)
- **데이터 교환**:
  - 요청: Spreadsheet ID, 시트 이름, 범위 (예: `Sheet1!A2:AZ100`)
  - 응답: JSON 형식의 2차원 배열
- **의존성 수준**: 높음
  - **대안**: CSV 파일 로드 옵션 제공 (Sheets API 불가용 시)
- **성능 요구사항**:
  - 응답 시간: 5초 이내
  - 처리량: 단일 페이지당 1회 호출

**EARS 요구사항**:

##### State-driven Requirements
- WHILE 스프레드시트 접근 권한이 없을 때, 시스템은 OAuth 인증 가이드를 제공해야 한다

##### Constraints
- IF 스프레드시트 로드 시간이 5초를 초과하면, 시스템은 타임아웃하고 에러를 표시해야 한다

---

## @DOC:TRACEABILITY-001 추적성 전략

### TAG 체계 적용

**TDD 완벽 정렬**: SPEC → 테스트 → 구현 → 문서
- `@SPEC:ID` (.moai/specs/) → `@TEST:ID` (tests/) → `@CODE:ID` (src/) → `@DOC:ID` (docs/)

**구현 세부사항**: @CODE:ID 내부 주석 레벨
- `@CODE:ID:API` - REST API, GraphQL 엔드포인트 (예: Flask `/export/jpg`)
- `@CODE:ID:UI` - 컴포넌트, 뷰, 화면 (예: Edit Controller UI)
- `@CODE:ID:DATA` - 데이터 모델, 스키마, 타입 (예: 디자인 스펙 JSON)
- `@CODE:ID:DOMAIN` - 비즈니스 로직, 도메인 규칙 (예: 픽셀 정확도 검증)
- `@CODE:ID:INFRA` - 인프라, 데이터베이스, 외부 연동 (예: Figma MCP 클라이언트)

### TAG 추적성 관리 (코드 스캔 방식)

- **검증 방법**: `/alfred:3-sync` 실행 시 `rg '@(SPEC|TEST|CODE|DOC):' -n`으로 코드 전체 스캔
- **추적 범위**: 프로젝트 전체 소스코드 (.moai/specs/, tests/, src/, docs/)
- **유지 주기**: 코드 변경 시점마다 실시간 검증
- **CODE-FIRST 원칙**: TAG의 진실은 코드 자체에만 존재

**예상 TAG 구조**:
```
@SPEC:FIGMA-001 → Figma MCP 연동 및 메타데이터 파싱
  ├─ @TEST:FIGMA-001 → tests/test_figma_parser.py
  ├─ @CODE:FIGMA-001 → src/figma_parser.py
  │   ├─ @CODE:FIGMA-001:INFRA → FigmaClient
  │   ├─ @CODE:FIGMA-001:DATA → DesignSpec 데이터 모델
  │   └─ @CODE:FIGMA-001:DOMAIN → 레이아웃 검증 로직
  └─ @DOC:FIGMA-001 → docs/figma-integration.md

@SPEC:HTML-001 → HTML 템플릿 생성 (픽셀 퍼펙트 레이아웃)
  ├─ @TEST:HTML-001 → tests/test_html_generator.py
  ├─ @CODE:HTML-001 → src/html_generator.py
  │   ├─ @CODE:HTML-001:UI → Jinja2 템플릿 (templates/)
  │   └─ @CODE:HTML-001:DOMAIN → 픽셀 정확도 검증
  └─ @DOC:HTML-001 → docs/html-generation.md
```

---

## Legacy Context

### 기존 시스템 현황

**DANA&PETA 페이지 빌더 (reference/dana/)**:

```
reference/dana/
├── load_from_sheets.py         # Google Sheets 데이터 로더
├── generate_pages_dana.py      # HTML 생성 메인 스크립트
├── templates/                   # Jinja2 템플릿
│   ├── original.html           # 읽기 전용 템플릿
│   └── editable.html           # 편집 가능 템플릿
├── server.py                    # Flask 익스포트 서버 (Port 5001)
└── utils/
    ├── image_encoder.py        # Base64 인코더
    └── cache_manager.py        # 로컬 캐시 관리
```

**재사용 가능 모듈**:
- `load_from_sheets.py` → Sheets Loader 기반
- `image_encoder.py` → Image Encoder 기반
- `server.py` → Export Server 기반
- `editable.html` 템플릿 → Edit Controller UI 기반

### 마이그레이션 고려사항

#### 1. Figma MCP 통합
- **계획**: DANA는 수동 디자인 입력, pb_pb2는 Figma MCP 자동 추출
- **우선순위**: Phase 1 (기본 파이프라인 구축)
- **마이그레이션**: 새로운 Figma Parser 모듈 개발 (DANA 구조와 유사한 JSON 스펙 출력)

#### 2. 스프레드시트 구조 변경
- **계획**: DANA 96컬럼 → pb_pb2 신규 컬럼 설계 (product.md 참조)
- **우선순위**: Phase 1
- **마이그레이션**: `DataMapper` 컴포넌트에서 컬럼 매핑 로직 구현

#### 3. 픽셀 정확도 검증
- **계획**: DANA는 검증 없음, pb_pb2는 자동 검증 시스템 추가
- **우선순위**: Phase 3 (최적화 및 검증)
- **마이그레이션**: 새로운 `PixelValidator` 모듈 개발

---

## TODO:STRUCTURE-001 구조 개선 계획

### Phase 1: 기본 파이프라인 구축 (4주)

1. **모듈 간 인터페이스 정의**
   - 각 모듈의 입출력 JSON 스키마 정의
   - Pydantic 모델로 타입 안전성 보장

2. **의존성 관리 전략**
   - Poetry 또는 pipenv로 패키지 관리
   - 개발/프로덕션 의존성 분리

3. **에러 핸들링 표준화**
   - 커스텀 예외 클래스 정의 (`FigmaAPIError`, `SheetsLoadError` 등)
   - 중앙 로깅 시스템 구축

### Phase 2: 확장성 확보 (2주)

1. **플러그인 아키텍처**
   - 새로운 데이터 소스 추가 용이 (Notion, Airtable 등)
   - Export 포맷 확장 가능 (PDF, PNG 등)

2. **캐싱 전략**
   - Figma/Sheets 응답 로컬 캐싱
   - 이미지 다운로드 캐싱

3. **모니터링 및 로깅**
   - 각 파이프라인 단계의 성능 메트릭 수집
   - Sentry 또는 로컬 로그 파일로 에러 추적

---

_이 구조는 `/alfred:2-build` 실행 시 TDD 구현의 가이드라인이 됩니다._
