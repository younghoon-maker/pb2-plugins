---
id: SHEETS-001
version: 0.1.0
status: completed
created: 2025-10-15
updated: 2025-10-16
author: @Alfred
priority: high
category: feature
labels:
  - google-sheets
  - data-loading
  - pydantic
  - k-means
depends_on: []
related_specs:
  - HTML-001
scope:
  packages:
    - src/sheets_loader
    - src/models
---

# @SPEC:SHEETS-001: Google Sheets 데이터 로딩 및 ProductData 모델

## HISTORY

### v0.1.0 (2025-10-16)
- **CHANGED**: TDD 구현 완료 (GREEN 단계, 20개 테스트 통과)
- **CHANGED**: ModelInfo 필드 정의 업데이트 (`height/size` → `model_image/model_size/model_measurements`)
- **CHANGED**: 필드명 명확화 (`image` → `detail_image`, `fabric_image`, `checkpoint_image`)
- **ADDED**: K-means 색상 추출 알고리즘 구현 (`color_extractor.py`)
- **ADDED**: plan.md 및 acceptance.md 작성
- **STATUS**: draft → completed
- **AUTHOR**: @Alfred
- **REASON**: SPEC-SHEETS-001 TDD 구현 완료 및 문서 동기화

### v0.0.1 (2025-10-15)
- **INITIAL**: Google Sheets `new_raw` 탭 데이터 로딩 시스템 명세 작성
- **AUTHOR**: @Alfred
- **REASON**: 실제 상품 데이터를 HTML 생성기에 통합하기 위한 데이터 로딩 파이프라인 구축

---

## 개요

### 목적
Google Sheets의 `new_raw` 탭에서 292개 컬럼의 상품 데이터를 읽어 Pydantic 모델로 변환하고, 기존 HTML 생성기(`SPEC-HTML-001`)와 통합하여 실제 콘텐츠가 포함된 상품 상세 페이지를 생성한다.

### 범위
- Google Sheets API v4를 통한 데이터 읽기
- Service Account 인증
- 292개 컬럼 → Pydantic 모델 변환
- 이미지 URL 하이퍼링크 추출 (`includeGridData=True`)
- 빈 값 처리 (`-`, `N/A`, `#N/A`, `#REF!`)
- 10개 HTML 섹션과 데이터 매핑

### 제외 범위 (초기 SPEC, v0.0.1)
- ~~K-means 색상 추출 (Phase 2)~~ → **v0.1.0에서 구현 완료** (`color_extractor.py`)
- Google Drive 이미지 다운로드 및 Base64 인코딩 (Phase 2, 부분 구현)
- BigQuery 연동 (Phase 3)
- 이미지 캐싱 (Phase 3)

---

## EARS 요구사항

### Ubiquitous Requirements (기본 요구사항)

#### 데이터 로딩
- 시스템은 Google Sheets API v4를 사용하여 `new_raw` 탭의 데이터를 읽어야 한다
- 시스템은 Service Account 인증을 사용하여 스프레드시트에 접근해야 한다
- 시스템은 292개 컬럼의 헤더 행(A1:KP1)과 데이터 행(A2:KP100)을 읽어야 한다

#### 데이터 변환
- 시스템은 스프레드시트 행 데이터를 `ProductData` Pydantic 모델로 변환해야 한다
- 시스템은 최대 6개의 색상 정보를 `ColorVariant` 모델로 변환해야 한다
- 시스템은 최대 8개 컬러 × 12개 이미지 = 96개의 갤러리 이미지를 `gallery_by_color` 딕셔너리로 변환해야 한다
- 시스템은 최대 3개의 디테일 포인트를 `DetailPoint` 모델로 변환해야 한다
- 시스템은 소재 정보를 `FabricInfo` 모델로 변환해야 한다
- 시스템은 체크포인트 정보를 `CheckpointInfo` 모델로 변환해야 한다 (선택)
- 시스템은 최대 2개의 모델 정보를 `ModelInfo` 모델로 변환해야 한다
- 시스템은 상의/하의 사이즈 테이블을 `SizeInfo` 모델로 변환해야 한다 (각 최대 10개)

#### HTML 섹션 매핑
- 시스템은 `ProductData`의 `product_name`, `main_image`를 Product Hero 섹션에 매핑해야 한다 (`product_code`는 내부 식별용으로만 사용)
- 시스템은 `colors[].color_image`를 Color Variants 섹션에 매핑해야 한다
- 시스템은 `gallery_by_color["Color1"]`를 Lifestyle Gallery 섹션에 매핑해야 한다
- 시스템은 `fabric_info`를 Material Detail 섹션에 매핑해야 한다
- 시스템은 `colors[].color_name`, `colors[].color_hex`를 Color Selector 섹션에 매핑해야 한다
- 시스템은 `detail_points[]`를 Product Info 섹션에 매핑해야 한다
- 시스템은 `fabric_info.care_instructions`를 Care Instructions 섹션에 매핑해야 한다
- 시스템은 `model_info[]`를 Model Info 섹션에 매핑해야 한다
- 시스템은 `checkpoint`를 Size Guide 섹션에 매핑해야 한다 (체크포인트 활용)
- 시스템은 `size_info.top_sizes`, `size_info.bottom_sizes`를 Size Chart 섹션에 매핑해야 한다

### Event-driven Requirements (이벤트 기반)

#### API 호출
- WHEN 시스템이 스프레드시트 데이터를 요청하면, Google Sheets API를 호출해야 한다
- WHEN API 호출이 실패하면, 시스템은 명확한 에러 메시지를 반환해야 한다
- WHEN 인증이 실패하면, 시스템은 Service Account 파일 경로를 포함한 에러를 반환해야 한다

#### 하이퍼링크 추출
- WHEN 셀에 하이퍼링크가 포함되어 있으면, 시스템은 `includeGridData=True` 파라미터를 사용하여 하이퍼링크 URL을 추출해야 한다
- WHEN 하이퍼링크가 없고 텍스트만 있으면, 시스템은 `formattedValue`를 사용해야 한다

#### 빈 값 처리
- WHEN 셀 값이 비어있거나 `-`, `N/A`, `#N/A`, `#REF!`이면, 시스템은 해당 필드를 `None` 또는 빈 리스트로 처리해야 한다
- WHEN 색상 이미지나 색상명이 비어있으면, 시스템은 해당 색상을 `colors` 리스트에 포함하지 않아야 한다
- WHEN 갤러리 이미지가 모두 비어있으면, 시스템은 해당 컬러를 `gallery_by_color` 딕셔너리에 포함하지 않아야 한다
- WHEN 사이즈명이 비어있으면, 시스템은 해당 사이즈를 `top_sizes` 또는 `bottom_sizes` 리스트에 포함하지 않아야 한다

#### 유효성 검증
- WHEN Pydantic 모델 변환 중 검증 에러가 발생하면, 시스템은 어떤 필드가 잘못되었는지 명확히 표시해야 한다
- WHEN 필수 필드(`product_code`, `product_name`, `main_image`, `colors`, `fabric_info`)가 누락되면, 시스템은 `ValidationError`를 발생시켜야 한다
- WHEN URL 필드가 유효하지 않은 형식이면, 시스템은 `ValidationError`를 발생시켜야 한다

### State-driven Requirements (상태 기반)

#### 데이터 로딩 상태
- WHILE 데이터 로딩 중일 때, 시스템은 진행 상황을 로깅해야 한다
- WHILE 여러 행을 처리 중일 때, 시스템은 각 행의 처리 결과를 독립적으로 반환해야 한다

#### 캐싱 상태 (Phase 3)
- WHILE 이미지 캐시가 존재할 때, 시스템은 Google Drive API 호출을 생략할 수 있다 (Phase 3 구현)

### Optional Features (선택적 기능)

#### 체크포인트
- WHERE 체크포인트 이미지와 설명이 제공되면, 시스템은 `CheckpointInfo` 모델을 생성할 수 있다
- WHERE 체크포인트가 없으면, 시스템은 `checkpoint` 필드를 `None`으로 설정할 수 있다

#### 모델 정보
- WHERE 모델 정보가 제공되지 않으면, 시스템은 `model_info` 리스트를 빈 리스트로 유지할 수 있다

#### HEX 코드
- WHERE 색상 HEX 코드가 제공되지 않으면, 시스템은 `color_hex` 필드를 `None`으로 설정할 수 있다
- WHERE HEX 코드가 `#` 접두사 없이 제공되면, 시스템은 자동으로 `#`를 추가할 수 있다

#### 사이즈 측정값
- WHERE 사이즈 테이블의 일부 측정값이 누락되면, 시스템은 해당 필드를 `None`으로 설정할 수 있다

### Constraints (제약사항)

#### API 제한
- IF Google Sheets API 할당량을 초과하면, 시스템은 429 에러를 처리하고 재시도 로직을 적용해야 한다
- IF 스프레드시트 ID가 잘못되었거나 접근 권한이 없으면, 시스템은 명확한 에러 메시지를 반환해야 한다

#### 데이터 크기
- 시스템은 최대 100개 행까지 처리할 수 있어야 한다 (`A2:KP100` 범위)
- 시스템은 각 행당 292개 컬럼을 처리할 수 있어야 한다

#### 성능
- 시스템은 단일 행 데이터를 1초 이내에 로딩하고 변환할 수 있어야 한다 (이미지 다운로드 제외)
- 시스템은 100개 행을 10초 이내에 로딩할 수 있어야 한다 (배치 처리 시)

#### 메모리
- 시스템은 100개 행 데이터를 메모리에 로드할 때 500MB를 초과하지 않아야 한다

---

## 데이터 모델 명세

### ProductData (메인 모델)

```python
class ProductData(BaseModel):
    """상품 전체 데이터 모델"""

    # 기본 정보
    product_code: str = Field(..., min_length=1, description="상품코드 (내부 식별용)")
    product_name: str = Field(..., min_length=1, description="상품명")
    main_image: HttpUrl = Field(..., description="메인 이미지 URL")

    # 색상 정보
    colors: List[ColorVariant] = Field(..., min_items=1, max_items=6, description="색상 변형")

    # 갤러리
    gallery_by_color: dict[str, List[HttpUrl]] = Field(..., description="컬러별 갤러리 이미지")

    # 디테일 포인트
    detail_points: List[DetailPoint] = Field(..., min_items=1, max_items=3, description="제품 특징")

    # 소재 정보
    fabric_info: FabricInfo = Field(..., description="소재 정보")

    # 체크포인트 (선택)
    checkpoint: Optional[CheckpointInfo] = Field(None, description="체크포인트 정보")

    # 모델 정보 (선택)
    model_info: List[ModelInfo] = Field(default_factory=list, max_items=2, description="모델 정보")

    # 사이즈 정보
    size_info: SizeInfo = Field(..., description="사이즈 정보")
```

### ColorVariant

```python
class ColorVariant(BaseModel):
    """색상 변형 정보"""

    color_image: HttpUrl = Field(..., description="색상 대표 이미지")
    color_name: str = Field(..., min_length=1, description="색상명")
    color_hex: Optional[str] = Field(None, pattern=r"^#?[0-9A-Fa-f]{6}$", description="HEX 코드")

    @validator("color_hex")
    def ensure_hex_prefix(cls, v):
        """HEX 코드에 # 접두사 추가"""
        if v and not v.startswith("#"):
            return f"#{v}"
        return v
```

### DetailPoint

```python
class DetailPoint(BaseModel):
    """디테일 포인트 (제품 특징)"""

    detail_image: HttpUrl = Field(..., description="디테일 이미지")
    detail_text: str = Field(..., min_length=1, description="디테일 설명 텍스트 (HTML 태그 포함 가능)")
```

**변경 이력** (v0.1.0):
- `image` → `detail_image` (명확한 필드명)
- `text` → `detail_text` (명확한 필드명)

### FabricInfo

```python
class FabricInfo(BaseModel):
    """소재 정보"""

    fabric_image: Optional[HttpUrl] = Field(None, description="소재 이미지")
    fabric_composition: str = Field(..., min_length=1, description="소재 구성")
    fabric_care: str = Field(..., min_length=1, description="세탁 방법")
```

**변경 이력** (v0.1.0):
- `image` → `fabric_image` (명확한 필드명, 선택적으로 변경)
- `composition` → `fabric_composition` (명확한 필드명)
- `care_instructions` → `fabric_care` (간결한 필드명)

### CheckpointInfo

```python
class CheckpointInfo(BaseModel):
    """체크포인트 정보 (주의사항)"""

    checkpoint_image: HttpUrl = Field(..., description="체크포인트 이미지")
    checkpoint_text: str = Field(..., min_length=1, description="체크포인트 설명")
```

**변경 이력** (v0.1.0):
- `image` → `checkpoint_image` (명확한 필드명)
- `description` → `checkpoint_text` (일관성 있는 필드명)

### ModelInfo

```python
class ModelInfo(BaseModel):
    """모델 정보"""

    model_image: Optional[HttpUrl] = Field(None, description="모델 이미지")
    model_size: str = Field(..., min_length=1, description="모델 착용 사이즈")
    model_measurements: str = Field(..., min_length=1, description="모델 신체 정보 (키, 사이즈 등)")
```

**변경 이력** (v0.1.0):
- `height` → `model_measurements` (더 포괄적인 신체 정보 포함)
- `size` → `model_size` (명확한 필드명)
- `model_image` 필드 추가 (선택적)

### SizeInfo, TopSize, BottomSize

```python
class TopSize(BaseModel):
    """상의 사이즈 테이블 (1개 행)"""

    size_name: str = Field(..., min_length=1, description="사이즈명")
    shoulder_width: Optional[str] = None
    chest_width: Optional[str] = None
    hem_width: Optional[str] = None
    sleeve_length: Optional[str] = None
    sleeve_opening: Optional[str] = None
    total_length: Optional[str] = None
    optional_row: Optional[str] = None

class BottomSize(BaseModel):
    """하의 사이즈 테이블 (1개 행)"""

    size_name: str = Field(..., min_length=1, description="사이즈명")
    waist_width: Optional[str] = None
    hip_width: Optional[str] = None
    thigh_width: Optional[str] = None
    hem_width: Optional[str] = None
    rise_length: Optional[str] = None
    total_length: Optional[str] = None
    optional_row: Optional[str] = None

class SizeInfo(BaseModel):
    """사이즈 정보 (상의/하의)"""

    top_sizes: List[TopSize] = Field(default_factory=list, max_items=10)
    bottom_sizes: List[BottomSize] = Field(default_factory=list, max_items=10)
```

---

## 컬럼 매핑 전략

### 컬럼 인덱스 상수 (`src/sheets_loader/column_mapping.py`)

```python
COLUMN_MAPPING = {
    # 기본 정보 (0-2)
    "product_code": 0,
    "product_name": 1,
    "main_image": 2,

    # 색상 이미지 (3-8)
    "color_image": (3, 8),  # range: 3-8

    # 색상 메타데이터 (9-20)
    "color_name": (9, 19, 2),   # start=9, end=19, step=2
    "color_hex": (10, 20, 2),   # start=10, end=20, step=2

    # 갤러리 (21-116)
    "gallery": (21, 116),  # Color1-8 × 12개

    # 디테일 포인트 (117-122)
    "point_image": (117, 121, 2),  # 117, 119, 121
    "point_text": (118, 122, 2),   # 118, 120, 122

    # 소재 정보 (123-125)
    "fabric_image": 123,
    "fabric_composition": 124,
    "care_instructions": 125,

    # 체크포인트 (126-127)
    "checkpoint_image": 126,
    "checkpoint_description": 127,

    # 모델 정보 (128-131)
    "model_height": (128, 130, 2),  # 128, 130
    "model_size": (129, 131, 2),    # 129, 131

    # 상의 사이즈 (132-211)
    "top_size": (132, 211, 8),  # 10개 × 8 필드

    # 하의 사이즈 (212-291)
    "bottom_size": (212, 291, 8),  # 10개 × 8 필드
}
```

### 동적 매핑 로직

#### 색상 정보
```python
def build_colors(row: List[str]) -> List[ColorVariant]:
    colors = []
    for i in range(1, 7):  # Color 1-6
        image_idx = 2 + i
        name_idx = 8 + (i-1)*2
        hex_idx = 9 + (i-1)*2

        if not is_empty_value(row[image_idx]) and not is_empty_value(row[name_idx]):
            colors.append(ColorVariant(
                color_image=row[image_idx],
                color_name=row[name_idx],
                color_hex=row[hex_idx] if not is_empty_value(row[hex_idx]) else None
            ))
    return colors
```

#### 갤러리 이미지
```python
def build_gallery(row: List[str]) -> dict[str, List[HttpUrl]]:
    gallery = {}
    for color_idx in range(1, 9):  # Color 1-8
        base_idx = 21 + (color_idx - 1) * 12
        images = [
            row[base_idx + i]
            for i in range(12)
            if not is_empty_value(row[base_idx + i])
        ]
        if images:
            gallery[f"Color{color_idx}"] = images
    return gallery
```

#### 사이즈 테이블
```python
def build_top_sizes(row: List[str]) -> List[TopSize]:
    sizes = []
    for size_idx in range(10):  # 사이즈 1-10
        base_idx = 132 + size_idx * 8
        if not is_empty_value(row[base_idx]):
            sizes.append(TopSize(
                size_name=row[base_idx],
                shoulder_width=row[base_idx + 1] or None,
                chest_width=row[base_idx + 2] or None,
                hem_width=row[base_idx + 3] or None,
                sleeve_length=row[base_idx + 4] or None,
                sleeve_opening=row[base_idx + 5] or None,
                total_length=row[base_idx + 6] or None,
                optional_row=row[base_idx + 7] or None,
            ))
    return sizes
```

---

## 통합 전략

### 데이터 로딩 파이프라인

```
Google Sheets (new_raw)
    ↓ (Google Sheets API v4)
SheetsLoader.load_product(row_index)
    ↓ (List[str] 292 columns)
ProductDataBuilder.build(row)
    ↓ (Pydantic validation)
ProductData
    ↓
HTMLGenerator.generate(design_spec, product_data)
    ↓
output/product_{product_code}.html
```

### 모듈 구조 (v0.1.0 업데이트)

```
src/
├── sheets_loader/
│   ├── __init__.py
│   ├── loader.py              # SheetsLoader 클래스
│   ├── column_mapping.py      # 컬럼 인덱스 상수
│   ├── product_builder.py     # ProductDataBuilder 클래스
│   ├── utils.py               # is_empty_value 등 유틸리티
│   └── color_extractor.py     # ColorExtractor - K-means 색상 추출 (v0.1.0 추가)
├── models/
│   ├── design_spec.py         # DesignSpec (기존)
│   └── product_data.py        # ProductData (신규)
└── html_generator.py          # HTMLGenerator (수정)

tests/
├── test_loader.py             # SheetsLoader 테스트
├── test_product_builder.py    # ProductDataBuilder 테스트
├── test_product_data.py       # Pydantic 모델 검증 테스트
└── test_utils.py              # 유틸리티 함수 테스트
```

### 인증 설정

```python
# src/sheets_loader/loader.py

from pathlib import Path
from google.oauth2 import service_account
from googleapiclient.discovery import build

SERVICE_ACCOUNT_FILE = Path(__file__).parent.parent.parent / "reference" / "dana" / "credentials" / "service-account.json"

SCOPES = [
    'https://www.googleapis.com/auth/spreadsheets.readonly',
    'https://www.googleapis.com/auth/drive.readonly'
]

credentials = service_account.Credentials.from_service_account_file(
    str(SERVICE_ACCOUNT_FILE),
    scopes=SCOPES
)

sheets_service = build('sheets', 'v4', credentials=credentials)
```

---

## 테스트 시나리오

### 단위 테스트 (`tests/sheets_loader/`)

#### `test_loader.py`
- ✅ Service Account 인증 성공
- ✅ 헤더 행 읽기 성공 (A1:KP1)
- ✅ 데이터 행 읽기 성공 (A2:KP100)
- ✅ 하이퍼링크 추출 성공 (`includeGridData=True`)
- ❌ 잘못된 Spreadsheet ID → 에러 처리
- ❌ Service Account 파일 없음 → 에러 처리
- ❌ API 할당량 초과 → 429 에러 처리

#### `test_product_builder.py`
- ✅ 완전한 행 데이터 → `ProductData` 변환 성공
- ✅ 6개 색상 → `colors` 리스트 변환
- ✅ 빈 색상 필터링 (이미지/이름 없으면 제외)
- ✅ 96개 갤러리 이미지 → `gallery_by_color` 딕셔너리 변환
- ✅ 빈 갤러리 필터링 (모든 이미지 없으면 제외)
- ✅ 3개 디테일 포인트 → `detail_points` 리스트 변환
- ✅ 체크포인트 있음 → `CheckpointInfo` 생성
- ✅ 체크포인트 없음 → `checkpoint=None`
- ✅ 모델 정보 2개 → `model_info` 리스트 변환
- ✅ 모델 정보 없음 → `model_info=[]`
- ✅ 상의/하의 사이즈 → `SizeInfo` 변환
- ✅ 빈 사이즈 필터링 (사이즈명 없으면 제외)
- ❌ 필수 필드 누락 → `ValidationError` 발생
- ❌ 잘못된 URL 형식 → `ValidationError` 발생
- ❌ 잘못된 HEX 코드 → `ValidationError` 발생

#### `test_utils.py`
- ✅ 빈 문자열 → `is_empty_value=True`
- ✅ `-` → `is_empty_value=True`
- ✅ `N/A`, `#N/A`, `#REF!` → `is_empty_value=True`
- ✅ 정상 값 → `is_empty_value=False`

### 통합 테스트 (`tests/integration/`)

#### `test_sheets_to_html.py`
- ✅ 스프레드시트 행 → HTML 전체 파이프라인 성공
- ✅ 샘플 데이터 (VD25FCA004) → HTML 생성
- ✅ Product Hero 섹션에 `product_name`, `main_image` 포함 (`product_code` 제외)
- ✅ Color Variants 섹션에 4개 색상 이미지 포함
- ✅ Lifestyle Gallery 섹션에 5개 갤러리 이미지 포함
- ✅ Material Detail 섹션에 소재 이미지/구성 포함
- ✅ Care Instructions 섹션에 케어 인스트럭션 포함
- ✅ Model Info 섹션에 모델 2명 정보 포함
- ✅ Size Chart 섹션에 상의 1개 사이즈 테이블 포함

---

## 성능 요구사항

### 로딩 성능
- 단일 행 로딩: ≤ 1초 (이미지 다운로드 제외)
- 100개 행 배치 로딩: ≤ 10초

### 메모리 사용
- 100개 행 메모리 사용량: ≤ 500MB

### API 호출 최적화
- 배치 읽기: 단일 API 호출로 100개 행 읽기
- 하이퍼링크 추출: `includeGridData=True` 파라미터로 단일 호출

---

## 보안 요구사항

### Service Account 관리
- Service Account 파일은 `.gitignore`에 포함되어야 함
- 프로덕션 환경에서는 환경 변수 또는 Secret Manager 사용 (Phase 3)

### API 권한
- `spreadsheets.readonly` 스코프만 사용 (쓰기 권한 불필요)
- `drive.readonly` 스코프만 사용 (Phase 2에서 이미지 다운로드용)

---

## 에러 처리

### API 에러
- 403 Forbidden → "Service Account에 스프레드시트 접근 권한이 없습니다"
- 404 Not Found → "스프레드시트 ID가 잘못되었습니다"
- 429 Too Many Requests → "API 할당량 초과, 1분 후 재시도"
- 500 Internal Server Error → "Google Sheets API 서버 오류"

### 검증 에러
- `ValidationError` → 어떤 필드가 잘못되었는지 명확히 표시
- 예시: "colors[0].color_hex: invalid HEX code format (expected #RRGGBB)"

---

## 참고 자료

### 분석 보고서
- `SPEC-SHEETS-001-analysis.md`: 292개 컬럼 상세 분석 및 모델 설계

### 레퍼런스 코드
- `reference/dana/scripts/load_from_sheets.py`: Google Sheets 로더 참조 구현
- `reference/dana/scripts/config.py`: 302개 컬럼 매핑 예시

### 기존 SPEC
- `SPEC-HTML-001`: HTML 생성기 (통합 대상)

---

**작성 완료일**: 2025-10-15
**작성자**: @Alfred (MoAI-ADK SuperAgent)
