---
id: FIGMA-001
version: 0.1.0
status: completed
created: 2025-10-15
updated: 2025-10-15
author: @younghoonjung
priority: high
category: feature
labels:
  - figma-mcp
  - design-parsing
  - input-layer
scope:
  packages:
    - src/figma_parser.py
    - src/models/design_spec.py
  files:
    - figma_parser.py
    - design_spec.py
    - cache_manager.py
---

# @SPEC:FIGMA-001: Figma MCP 연동 및 디자인 메타데이터 파싱

## HISTORY

### v0.1.0 (2025-10-15)
- **COMPLETED**: TDD 구현 완료 (Phase 1-5)
- **TEST**: 28개 테스트 통과, 커버리지 98%
- **CODE**: 528 LOC 구현 + 528 LOC 테스트
- **QUALITY**: ruff, mypy strict 모드 통과
- **STRUCTURE**:
  - INFRA (170 LOC): FigmaClient - MCP API 연동, 타임아웃/재시도 처리
  - INFRA (99 LOC): CacheManager - TTL 기반 캐시 관리
  - DOMAIN (63 LOC): LayoutParser - 레이아웃 파싱, 좌표 계산
  - DOMAIN (122 LOC): DesignValidator - 10개 섹션 검증, ±2px 정확도 검증
  - DATA (51 LOC): DesignSpec/Section - Pydantic 모델, 타입 안전성
- **AUTHOR**: @younghoonjung

### v0.0.1 (2025-10-15)
- **INITIAL**: Figma MCP 연동 및 디자인 메타데이터 파싱 명세 최초 작성
- **AUTHOR**: @younghoonjung
- **SCOPE**: Figma MCP API 연동, 노드 트리 순회, 레이아웃 정보 추출, 디자인 스펙 JSON 출력
- **CONTEXT**: pb_pb2_new_page 프로젝트의 첫 번째 SPEC, 3-Tier 파이프라인 Input Layer 구현
- **PRIORITY**: Phase 1 - 기본 파이프라인 구축의 첫 단계

---

## Environment (환경)

### 필수 환경

- **Figma Desktop App**: macOS 또는 Windows에 설치 필수 (MCP 서버 제공)
- **Python 버전**: 3.11 이상
- **인터넷 연결**: Figma API 호출 필요 (캐시 사용 시 선택)
- **Figma 파일 정보**:
  - URL: `https://www.figma.com/design/wBdUdgAJtuBr5nn7w38LOB/pb2_new_template?node-id=1-95&m=dev`
  - 노드 ID: `1-95`
  - 캔버스 크기: 1080px × 25520px
  - 폰트: Pretendard (Light, Regular)

### 디자인 구조

**10개 섹션 정의** (product.md 기준):

| 순서 | 섹션명 | Figma Group | 크기 | 설명 |
|------|--------|-------------|------|------|
| 1 | Product Hero | Group 10 (1:159) | 1033×1749px | 메인 상품 이미지 + 타이틀 |
| 2 | Color Variants | Group 1 (1:96) | 1082×1159px | 6개 컬러 옵션 이미지 |
| 3 | Lifestyle Gallery | Group 2 (1:97) | 1042×14943px | 10개 라이프스타일 이미지 |
| 4 | Material Detail | Group 3 (1:98) | 1042×2805px | 소재 디테일 이미지 |
| 5 | Color Selector | Group 4 (1:99) | 332×89px | 컬러 선택 UI |
| 6 | Product Info | Group 5 (1:100) | 1044×1043px | 소재 정보 + 세탁 방법 |
| 7 | Care Instructions | Group 6 (1:154) | 939×294px | 주의사항 리스트 |
| 8 | Model Info | Group 7 (1:155) | 730×352px | 모델 착용 정보 |
| 9 | Size Guide | Group 8 (1:156) | 601×151px | 사이즈 가이드 텍스트 |
| 10 | Size Chart | Group 11 (2:1481) | 679×775px | 상세 사이즈 표 |

---

## Assumptions (가정)

### 기술적 가정

1. **Figma Desktop App 실행**: MCP 서버가 정상 작동 중
2. **디자인 표준**: Figma 디자인이 1080px 기준으로 제작됨
3. **네트워크**: 인터넷 연결 가능 (API 호출 필요, 오프라인 시 캐시 사용)
4. **폰트**: Pretendard 폰트가 사용되며, 웹폰트로 로드 가능

### 비즈니스 가정

1. **픽셀 퍼펙트 목표**: HTML 출력 시 ±2px 이내 오차 허용
2. **섹션 구조 고정**: 10개 섹션 구조는 변경되지 않음 (신규 섹션 추가 시 SPEC 업데이트)
3. **로컬 실행**: 서버 배포 없이 로컬 환경에서만 실행

---

## Requirements (요구사항)

### Ubiquitous Requirements (필수 기능)

- 시스템은 Figma MCP를 통해 디자인 메타데이터를 추출해야 한다
  - `get_metadata(node_id)`: XML 형식의 노드 트리 반환
  - `get_code(node_id)`: React + Tailwind 코드 반환
  - `get_screenshot(node_id)`: PNG 스크린샷 반환

- 시스템은 Figma 노드 트리를 순회하여 10개 섹션의 레이아웃 정보를 추출해야 한다
  - 각 섹션의 Figma Group ID, 위치(x, y), 크기(width, height)
  - 1080px 기준 절대 좌표 계산

- 시스템은 Pretendard 폰트 스타일을 정확히 파싱해야 한다
  - font-weight (Light, Regular)
  - font-size (px 단위)
  - line-height (px 또는 비율)

- 시스템은 정규화된 디자인 스펙을 JSON 형식으로 출력해야 한다
  - Pydantic 모델 기반 데이터 검증
  - JSON 직렬화 가능한 형태

### Event-driven Requirements (이벤트 기반)

- WHEN Figma MCP API 호출이 실패하면, 시스템은 다음을 수행해야 한다:
  - 로컬 캐시(`.cache/figma/`)에서 데이터 로드 시도
  - 캐시가 없으면 `FigmaAPIError` 발생
  - 경고 로그 기록: `"Figma API failed, attempting cache: {error}"`

- WHEN Figma 응답 시간이 10초를 초과하면, 시스템은 다음을 수행해야 한다:
  - 타임아웃 처리
  - 로컬 캐시 사용 시도
  - 경고 로그 기록: `"Figma API timeout (>10s), using cache"`

- WHEN Figma 노드가 1080px 너비를 벗어나면, 시스템은 다음을 수행해야 한다:
  - 경고 로그 기록: `"Node {node_id} width {width}px exceeds 1080px"`
  - 레이아웃 오차 리포트에 추가

- WHEN 필수 섹션이 누락되면, 시스템은 다음을 수행해야 한다:
  - `ValidationError` 발생
  - 에러 메시지: `"Missing required section: {section_name}"`

### State-driven Requirements (상태 기반)

- WHILE 개발 모드(`DEBUG=true`)일 때, 시스템은 다음을 수행해야 한다:
  - Figma API 응답을 로컬 캐시에 저장 (`.cache/figma/{node_id}.json`)
  - 중간 파싱 결과를 로그에 상세 기록

- WHILE 오프라인 모드일 때, 시스템은 다음을 수행해야 한다:
  - Figma API 호출 건너뛰기
  - 캐시된 데이터만 사용
  - INFO 로그: `"Offline mode: using cached data only"`

### Optional Features (선택 기능)

- WHERE 캐시가 존재하면, 시스템은 다음을 수행할 수 있다:
  - TTL(1시간) 확인
  - TTL 내이면 캐시 우선 사용
  - TTL 초과 시 API 재호출 및 캐시 갱신

- WHERE API 실패 시, 시스템은 다음을 수행할 수 있다:
  - 최대 3회 재시도 (exponential backoff: 1s, 2s, 4s)
  - 각 재시도 시 로그 기록

### Constraints (제약사항)

- IF Figma 응답 시간이 10초를 초과하면, 시스템은 타임아웃해야 한다

- IF 필수 섹션(Product Hero, Color Variants 등)이 누락되면, 시스템은 검증 실패 에러를 발생시켜야 한다

- IF Figma MCP가 3회 연속 실패하면, 시스템은 오프라인 모드로 전환해야 한다

- 레이아웃 오차는 ±2px 이내여야 한다
  - Figma 좌표와 HTML 렌더링 좌표 비교
  - 오차 초과 시 오차 리포트 생성

- 파이프라인 실행 시간은 30초를 초과하지 않아야 한다
  - Figma Parser 단계: 10초 이내 목표

---

## Components (구성요소)

### FigmaClient (@CODE:FIGMA-001:INFRA)

**책임**: Figma MCP API 래퍼, 인증, 요청/응답 처리, 에러 핸들링

**메서드**:
```python
class FigmaClient:
    def get_metadata(self, node_id: str) -> Dict[str, Any]:
        """Figma 노드의 메타데이터를 추출합니다.

        Args:
            node_id: Figma 노드 ID (예: "1-95")

        Returns:
            Dict: 노드 트리 메타데이터 (XML 파싱 결과)

        Raises:
            FigmaAPIError: API 호출 실패 시
            TimeoutError: 10초 초과 시
        """

    def get_code(self, node_id: str) -> str:
        """Figma 노드의 React 코드를 추출합니다."""

    def get_screenshot(self, node_id: str) -> bytes:
        """Figma 노드의 PNG 스크린샷을 추출합니다."""

    def _call_mcp_api(self, tool_name: str, node_id: str, **kwargs) -> Any:
        """MCP API 호출 내부 메서드 (타임아웃, 재시도 처리)"""
```

**의존성**:
- Figma Desktop App (MCP 서버)
- `requests` 또는 MCP SDK

**에러 처리**:
- `FigmaAPIError`: API 호출 실패
- `TimeoutError`: 10초 초과

---

### LayoutParser (@CODE:FIGMA-001:DOMAIN)

**책임**: 노드 트리 순회, 레이아웃 분석, 좌표 계산

**메서드**:
```python
class LayoutParser:
    def parse_layout(self, metadata: Dict[str, Any]) -> DesignSpec:
        """Figma 메타데이터를 파싱하여 디자인 스펙 객체를 생성합니다.

        Args:
            metadata: FigmaClient.get_metadata()의 반환값

        Returns:
            DesignSpec: 정규화된 디자인 스펙 객체

        Raises:
            ValidationError: 필수 섹션 누락 시
        """

    def calculate_absolute_coords(self, node: Dict[str, Any]) -> Tuple[int, int]:
        """노드의 절대 좌표를 계산합니다 (부모 노드 좌표 포함).

        Args:
            node: Figma 노드 딕셔너리

        Returns:
            Tuple[int, int]: (x, y) 절대 좌표
        """

    def extract_font_styles(self, node: Dict[str, Any]) -> Dict[str, Any]:
        """Pretendard 폰트 스타일을 추출합니다.

        Returns:
            Dict: {
                "font-family": "Pretendard",
                "font-weight": 400,  # Light=300, Regular=400
                "font-size": "16px",
                "line-height": "24px"
            }
        """
```

**로직**:
1. XML 메타데이터 파싱 (ElementTree 또는 xmltodict)
2. 노드 트리 재귀 순회
3. 10개 섹션 Group ID 매칭 (product.md 기준)
4. 부모 노드 좌표 누적 계산 (절대 좌표)
5. Pretendard 폰트 스타일 추출

---

### DesignValidator (@CODE:FIGMA-001:DOMAIN)

**책임**: 스펙 검증, 필수 섹션 확인, 크기 제약 검증

**메서드**:
```python
class DesignValidator:
    REQUIRED_SECTIONS = [
        "Product Hero",
        "Color Variants",
        "Lifestyle Gallery",
        # ... 10개 섹션
    ]

    def validate_sections(self, spec: DesignSpec) -> bool:
        """필수 섹션 10개가 모두 존재하는지 확인합니다.

        Args:
            spec: DesignSpec 객체

        Returns:
            bool: 검증 성공 여부

        Raises:
            ValidationError: 필수 섹션 누락 시
        """

    def validate_layout_accuracy(self, spec: DesignSpec) -> List[str]:
        """레이아웃 오차를 검증합니다 (±2px 기준).

        Args:
            spec: DesignSpec 객체

        Returns:
            List[str]: 오차 리포트 (오차 없으면 빈 리스트)
        """

    def validate_canvas_size(self, spec: DesignSpec) -> bool:
        """캔버스 크기가 1080px 기준인지 확인합니다."""
```

---

### DesignSpec (@CODE:FIGMA-001:DATA)

**책임**: 디자인 스펙 데이터 모델 (Pydantic 기반)

**모델 정의**:
```python
from pydantic import BaseModel, Field
from typing import List, Dict, Any

class Section(BaseModel):
    """섹션 정보"""
    id: str = Field(..., description="Figma 노드 ID (예: 1:159)")
    name: str = Field(..., description="섹션명 (예: Product Hero)")
    figma_group: str = Field(..., description="Figma Group ID (예: Group 10)")
    x: int = Field(..., ge=0, description="X 좌표 (px)")
    y: int = Field(..., ge=0, description="Y 좌표 (px)")
    width: int = Field(..., gt=0, description="너비 (px)")
    height: int = Field(..., gt=0, description="높이 (px)")
    styles: Dict[str, Any] = Field(default_factory=dict, description="폰트 스타일 등")

class DesignSpec(BaseModel):
    """디자인 스펙 최상위 모델"""
    width: int = Field(1080, description="캔버스 너비 (px)")
    height: int = Field(25520, description="캔버스 높이 (px)")
    sections: List[Section] = Field(..., min_items=10, max_items=10)
    font_family: str = Field("Pretendard", description="기본 폰트")

    def to_json(self) -> str:
        """JSON 문자열로 직렬화"""
        return self.model_dump_json(indent=2)
```

---

## Traceability (@TAG)

**TAG 체계**:
- **SPEC**: `@SPEC:FIGMA-001` (`.moai/specs/SPEC-FIGMA-001/spec.md`)
- **TEST**: `@TEST:FIGMA-001` (`tests/test_figma_parser.py`)
- **CODE**: `@CODE:FIGMA-001` (`src/figma_parser.py`)
- **DOC**: `@DOC:FIGMA-001` (`docs/figma-integration.md`)

**TAG 서브 카테고리**:
- `@CODE:FIGMA-001:INFRA` → `FigmaClient` (MCP API 연동)
- `@CODE:FIGMA-001:DOMAIN` → `LayoutParser`, `DesignValidator` (비즈니스 로직)
- `@CODE:FIGMA-001:DATA` → `DesignSpec`, `Section` (Pydantic 모델)

**TAG 검증 방법**:
```bash
# SPEC → TEST → CODE 체인 확인
rg '@SPEC:FIGMA-001' -n .moai/specs/
rg '@TEST:FIGMA-001' -n tests/
rg '@CODE:FIGMA-001' -n src/

# 고아 TAG 탐지
rg '@CODE:FIGMA-001' -n src/          # CODE는 있는데
rg '@SPEC:FIGMA-001' -n .moai/specs/  # SPEC이 없으면 고아
```

---

## Performance & Quality

### 성능 목표

- **Figma API 응답 시간**: 10초 이내 (타임아웃)
- **파싱 시간**: 5초 이내 (XML 파싱 + 좌표 계산)
- **전체 실행 시간**: 15초 이내 (Figma Parser 단계)

### 품질 기준 (TRUST 원칙)

- **Test First**: pytest 커버리지 85% 이상
- **Readable**: 함수 50 LOC 이하, 파일 300 LOC 이하
- **Unified**: Pydantic 타입 안전성, mypy strict 모드
- **Secured**: 민감 정보 로깅 금지, .env 파일 사용
- **Trackable**: @TAG 시스템, CODE-FIRST 원칙

---

## Error Handling

### 커스텀 예외

```python
class FigmaParserError(Exception):
    """Figma Parser 기본 예외"""
    pass

class FigmaAPIError(FigmaParserError):
    """Figma MCP API 호출 실패"""
    pass

class ValidationError(FigmaParserError):
    """디자인 스펙 검증 실패"""
    pass

class CacheError(FigmaParserError):
    """캐시 로드/저장 실패"""
    pass
```

### 에러 핸들링 전략

1. **Figma API 실패**: 캐시 사용 → 캐시 없으면 에러 발생
2. **타임아웃**: 10초 초과 시 즉시 캐시 사용
3. **검증 실패**: ValidationError 발생, 상세 에러 메시지 제공
4. **재시도**: 최대 3회 (exponential backoff)

---

## Dependencies

### 선행 작업
- 없음 (첫 번째 SPEC)

### 후속 SPEC 차단
- `SPEC-HTML-001`: HTML 템플릿 생성 (디자인 스펙 JSON 필요)

### 병렬 개발 가능
- `SPEC-SHEETS-001`: Google Sheets 데이터 로더 (독립적)

### 관련 SPEC (향후)
- `SPEC-CACHE-001`: 캐싱 전략 최적화 (Phase 2)
- `SPEC-QA-001`: 픽셀 정확도 자동 검증 시스템 (Phase 3)

---

## References

- **product.md**: 10개 섹션 정의, 픽셀 퍼펙트 목표
- **structure.md**: 3-Tier 파이프라인, Input Layer 아키텍처
- **tech.md**: Python 3.11+, pytest, ruff, mypy 기준
- **Figma MCP Docs**: https://www.figma.com/developers/mcp

---

_이 SPEC은 `/alfred:2-build SPEC-FIGMA-001` 실행 시 TDD 구현의 기준이 됩니다._
