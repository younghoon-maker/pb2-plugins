# SPEC-FIGMA-001 구현 계획서

> **TDD Red-Green-Refactor 사이클 기반 구현 로드맵**

---

## 📋 구현 개요

**SPEC ID**: FIGMA-001
**목표**: Figma MCP를 통한 디자인 메타데이터 파싱 및 정규화
**예상 기간**: 2-3주 (개발자 1명 기준)
**우선순위**: Phase 1 - 기본 파이프라인 구축

---

## 🎯 구현 단계 (5 Phases)

### Phase 1: 데이터 모델 정의 (1-2일)

**목표**: Pydantic 기반 데이터 모델 및 예외 클래스 정의

**TDD 사이클**:

**RED (테스트 작성)**:
```python
# tests/test_design_spec.py
def test_section_model_validation():
    """Section 모델 필수 필드 검증"""
    with pytest.raises(ValidationError):
        Section(id="1:159")  # name, x, y, width, height 누락

def test_design_spec_requires_10_sections():
    """DesignSpec은 정확히 10개 섹션을 요구"""
    with pytest.raises(ValidationError):
        DesignSpec(sections=[])  # 섹션 부족
```

**GREEN (최소 구현)**:
```python
# src/models/design_spec.py
from pydantic import BaseModel, Field
from typing import List, Dict, Any

class Section(BaseModel):
    id: str
    name: str
    figma_group: str
    x: int = Field(ge=0)
    y: int = Field(ge=0)
    width: int = Field(gt=0)
    height: int = Field(gt=0)
    styles: Dict[str, Any] = Field(default_factory=dict)

class DesignSpec(BaseModel):
    width: int = 1080
    height: int = 25520
    sections: List[Section] = Field(min_items=10, max_items=10)
    font_family: str = "Pretendard"
```

**REFACTOR**:
- 타입 힌트 정확도 개선
- Docstring 추가
- JSON 직렬화 메서드 추가

**예상 산출물**:
- `src/models/design_spec.py` (150 LOC)
- `src/models/exceptions.py` (50 LOC)
- `tests/test_design_spec.py` (100 LOC)

---

### Phase 2: FigmaClient 구현 (3-5일)

**목표**: Figma MCP API 연동, 타임아웃/재시도 처리

**TDD 사이클**:

**RED (테스트 작성)**:
```python
# tests/test_figma_client.py
def test_get_metadata_success(mock_mcp_api):
    """정상적인 메타데이터 추출"""
    client = FigmaClient()
    result = client.get_metadata("1-95")
    assert "width" in result
    assert result["width"] == 1082

def test_get_metadata_timeout(mock_mcp_api):
    """10초 타임아웃 처리"""
    mock_mcp_api.side_effect = Timeout()
    client = FigmaClient()
    with pytest.raises(FigmaAPIError):
        client.get_metadata("1-95")

def test_get_metadata_retry_3_times(mock_mcp_api):
    """3회 재시도 전략"""
    mock_mcp_api.side_effect = [ConnectionError(), ConnectionError(), {"data": "ok"}]
    client = FigmaClient()
    result = client.get_metadata("1-95")
    assert mock_mcp_api.call_count == 3
```

**GREEN (최소 구현)**:
```python
# src/figma_client.py
import requests
from typing import Dict, Any

class FigmaClient:
    TIMEOUT = 10
    MAX_RETRIES = 3

    def get_metadata(self, node_id: str) -> Dict[str, Any]:
        """Figma 노드의 메타데이터를 추출합니다."""
        for attempt in range(self.MAX_RETRIES):
            try:
                # Figma MCP API 호출 (mcp__figma-dev-mode-mcp-server__get_metadata)
                response = self._call_mcp_api("get_metadata", node_id)
                return response
            except (ConnectionError, Timeout) as e:
                if attempt == self.MAX_RETRIES - 1:
                    raise FigmaAPIError(f"Failed after {self.MAX_RETRIES} retries: {e}")
                time.sleep(2 ** attempt)  # Exponential backoff
```

**REFACTOR**:
- 재시도 로직 별도 데코레이터로 분리
- 로깅 추가 (DEBUG 레벨)
- 타임아웃 설정 환경변수로 분리 (`.env`)

**예상 산출물**:
- `src/figma_client.py` (200 LOC)
- `tests/test_figma_client.py` (150 LOC)

---

### Phase 3: LayoutParser 구현 (5-7일)

**목표**: 노드 트리 순회, 좌표 계산, 폰트 스타일 추출

**TDD 사이클**:

**RED (테스트 작성)**:
```python
# tests/test_layout_parser.py
def test_parse_layout_returns_10_sections(sample_metadata):
    """10개 섹션을 정확히 파싱"""
    parser = LayoutParser()
    spec = parser.parse_layout(sample_metadata)
    assert len(spec.sections) == 10
    assert spec.sections[0].name == "Product Hero"

def test_calculate_absolute_coords():
    """부모 노드 좌표를 포함한 절대 좌표 계산"""
    parser = LayoutParser()
    node = {"x": 100, "y": 200, "parent": {"x": 50, "y": 50}}
    x, y = parser.calculate_absolute_coords(node)
    assert (x, y) == (150, 250)

def test_extract_font_styles():
    """Pretendard 폰트 스타일 추출"""
    parser = LayoutParser()
    node = {
        "style": {
            "fontFamily": "Pretendard",
            "fontWeight": 400,
            "fontSize": "16px"
        }
    }
    styles = parser.extract_font_styles(node)
    assert styles["font-family"] == "Pretendard"
    assert styles["font-weight"] == 400
```

**GREEN (최소 구현)**:
```python
# src/layout_parser.py
import xml.etree.ElementTree as ET
from typing import Dict, Any, Tuple, List

class LayoutParser:
    # 10개 섹션 Group ID 매핑 (product.md 기준)
    SECTION_MAPPING = {
        "1:159": "Product Hero",
        "1:96": "Color Variants",
        "1:97": "Lifestyle Gallery",
        # ... 10개
    }

    def parse_layout(self, metadata: Dict[str, Any]) -> DesignSpec:
        """Figma 메타데이터를 파싱하여 DesignSpec 생성"""
        sections = []

        # XML 메타데이터 파싱
        root = ET.fromstring(metadata["xml"])

        # 노드 트리 순회
        for node in root.iter():
            node_id = node.get("id")
            if node_id in self.SECTION_MAPPING:
                section = self._parse_section(node)
                sections.append(section)

        return DesignSpec(sections=sections)

    def calculate_absolute_coords(self, node: Dict[str, Any]) -> Tuple[int, int]:
        """절대 좌표 계산 (재귀적으로 부모 좌표 누적)"""
        x = node.get("x", 0)
        y = node.get("y", 0)

        if "parent" in node:
            parent_x, parent_y = self.calculate_absolute_coords(node["parent"])
            x += parent_x
            y += parent_y

        return (x, y)
```

**REFACTOR**:
- XML 파싱 로직 최적화 (XPath 사용)
- 함수 분리 (50 LOC 이하 준수)
- 복잡도 10 이하 유지 (Cyclomatic Complexity)

**예상 산출물**:
- `src/layout_parser.py` (300 LOC)
- `tests/test_layout_parser.py` (200 LOC)
- `tests/fixtures/sample_metadata.json` (테스트 픽스처)

---

### Phase 4: DesignValidator 구현 (2-3일)

**목표**: 필수 섹션 검증, 레이아웃 오차 검증

**TDD 사이클**:

**RED (테스트 작성)**:
```python
# tests/test_design_validator.py
def test_validate_sections_all_present(valid_design_spec):
    """10개 섹션 모두 존재 시 통과"""
    validator = DesignValidator()
    assert validator.validate_sections(valid_design_spec) is True

def test_validate_sections_missing_hero(incomplete_design_spec):
    """Product Hero 누락 시 ValidationError"""
    validator = DesignValidator()
    with pytest.raises(ValidationError, match="Missing required section: Product Hero"):
        validator.validate_sections(incomplete_design_spec)

def test_validate_layout_accuracy_within_2px(valid_design_spec):
    """레이아웃 오차 ±2px 이내"""
    validator = DesignValidator()
    errors = validator.validate_layout_accuracy(valid_design_spec)
    assert errors == []

def test_validate_layout_accuracy_exceeds_2px(inaccurate_design_spec):
    """레이아웃 오차 ±2px 초과 시 리포트"""
    validator = DesignValidator()
    errors = validator.validate_layout_accuracy(inaccurate_design_spec)
    assert len(errors) > 0
    assert "Section 'Product Hero' position error: +5px" in errors
```

**GREEN (최소 구현)**:
```python
# src/design_validator.py
from typing import List

class DesignValidator:
    REQUIRED_SECTIONS = [
        "Product Hero",
        "Color Variants",
        "Lifestyle Gallery",
        "Material Detail",
        "Color Selector",
        "Product Info",
        "Care Instructions",
        "Model Info",
        "Size Guide",
        "Size Chart",
    ]

    TOLERANCE = 2  # ±2px

    def validate_sections(self, spec: DesignSpec) -> bool:
        """필수 섹션 10개가 모두 존재하는지 확인"""
        section_names = {s.name for s in spec.sections}

        for required in self.REQUIRED_SECTIONS:
            if required not in section_names:
                raise ValidationError(f"Missing required section: {required}")

        return True

    def validate_layout_accuracy(self, spec: DesignSpec) -> List[str]:
        """레이아웃 오차 검증 (±2px 기준)"""
        errors = []

        # Figma 원본 좌표와 비교 (테스트에서 mock)
        for section in spec.sections:
            # 실제 구현 시 Figma API로 원본 좌표 가져와서 비교
            # 현재는 검증 로직만 구현
            pass

        return errors
```

**REFACTOR**:
- 검증 로직 세분화 (각 섹션별 검증)
- 에러 메시지 표준화

**예상 산출물**:
- `src/design_validator.py` (150 LOC)
- `tests/test_design_validator.py` (120 LOC)

---

### Phase 5: 캐싱 전략 구현 (2-3일)

**목표**: 로컬 캐시 저장/로드, TTL 관리

**TDD 사이클**:

**RED (테스트 작성)**:
```python
# tests/test_cache_manager.py
def test_save_cache_creates_file():
    """캐시 저장 시 파일 생성"""
    manager = CacheManager()
    manager.save("1-95", {"data": "test"})
    assert Path(".cache/figma/1-95.json").exists()

def test_load_cache_returns_data():
    """캐시 로드 시 데이터 반환"""
    manager = CacheManager()
    manager.save("1-95", {"data": "test"})
    result = manager.load("1-95")
    assert result["data"] == "test"

def test_cache_ttl_expired():
    """TTL 초과 시 캐시 무효"""
    manager = CacheManager(ttl=3600)  # 1시간
    manager.save("1-95", {"data": "old"})

    # 시간 이동 (2시간 후)
    with freezegun.freeze_time("2 hours later"):
        assert manager.is_valid("1-95") is False
```

**GREEN (최소 구현)**:
```python
# src/utils/cache_manager.py
import json
from pathlib import Path
from datetime import datetime, timedelta

class CacheManager:
    CACHE_DIR = Path(".cache/figma")

    def __init__(self, ttl: int = 3600):  # 1시간
        self.ttl = ttl
        self.CACHE_DIR.mkdir(parents=True, exist_ok=True)

    def save(self, node_id: str, data: Dict[str, Any]) -> None:
        """캐시 저장"""
        cache_file = self.CACHE_DIR / f"{node_id}.json"
        cache_data = {
            "timestamp": datetime.now().isoformat(),
            "data": data
        }
        cache_file.write_text(json.dumps(cache_data, indent=2))

    def load(self, node_id: str) -> Optional[Dict[str, Any]]:
        """캐시 로드"""
        cache_file = self.CACHE_DIR / f"{node_id}.json"

        if not cache_file.exists():
            return None

        cache_data = json.loads(cache_file.read_text())

        # TTL 확인
        if not self.is_valid(node_id):
            return None

        return cache_data["data"]

    def is_valid(self, node_id: str) -> bool:
        """캐시 유효성 확인 (TTL)"""
        cache_file = self.CACHE_DIR / f"{node_id}.json"

        if not cache_file.exists():
            return False

        cache_data = json.loads(cache_file.read_text())
        timestamp = datetime.fromisoformat(cache_data["timestamp"])

        return datetime.now() - timestamp < timedelta(seconds=self.ttl)
```

**REFACTOR**:
- 캐시 디렉토리 환경변수로 분리
- 캐시 정리 기능 추가 (오래된 캐시 삭제)

**예상 산출물**:
- `src/utils/cache_manager.py` (100 LOC)
- `tests/test_cache_manager.py` (100 LOC)

---

## 📦 최종 파일 구조

```
pb_pb2_new_page/
├── src/
│   ├── figma_parser.py           # @CODE:FIGMA-001 (메인 모듈, 200 LOC)
│   ├── figma_client.py           # @CODE:FIGMA-001:INFRA (200 LOC)
│   ├── layout_parser.py          # @CODE:FIGMA-001:DOMAIN (300 LOC)
│   ├── design_validator.py      # @CODE:FIGMA-001:DOMAIN (150 LOC)
│   ├── models/
│   │   ├── __init__.py
│   │   ├── design_spec.py       # @CODE:FIGMA-001:DATA (150 LOC)
│   │   └── exceptions.py        # (50 LOC)
│   └── utils/
│       ├── __init__.py
│       └── cache_manager.py     # @CODE:FIGMA-001:INFRA (100 LOC)
│
├── tests/
│   ├── test_figma_parser.py     # @TEST:FIGMA-001 (통합 테스트, 150 LOC)
│   ├── test_figma_client.py     # (150 LOC)
│   ├── test_layout_parser.py    # (200 LOC)
│   ├── test_design_validator.py # (120 LOC)
│   ├── test_design_spec.py      # (100 LOC)
│   ├── test_cache_manager.py    # (100 LOC)
│   └── fixtures/
│       └── sample_metadata.json # (테스트 데이터)
│
└── .cache/
    └── figma/
        └── 1-95.json            # (캐시 데이터)
```

**총 LOC**: 약 2,070 LOC (구현 1,150 LOC + 테스트 820 LOC + 기타 100 LOC)

---

## ✅ 완료 기준 (Definition of Done)

### 구현 완료 조건

- [ ] 5개 Phase 모두 완료
- [ ] 모든 테스트 통과 (pytest)
- [ ] 커버리지 85% 이상 달성
- [ ] ruff 린트 에러 0개
- [ ] mypy 타입 체크 통과 (strict 모드)

### 품질 기준

- [ ] 파일당 300 LOC 이하
- [ ] 함수당 50 LOC 이하
- [ ] 매개변수 5개 이하
- [ ] 복잡도 10 이하

### 문서화

- [ ] Docstring 100% (모든 public 메서드)
- [ ] `@TAG` 시스템 적용 (SPEC → TEST → CODE)
- [ ] `docs/figma-integration.md` 작성 (@DOC:FIGMA-001)

### 통합 테스트

- [ ] End-to-End 테스트: Figma API 호출 → JSON 출력
- [ ] 캐시 시나리오 테스트: API 실패 → 캐시 사용
- [ ] 검증 시나리오 테스트: 필수 섹션 누락 → ValidationError

---

## 🚀 다음 단계

**SPEC-FIGMA-001 완료 후**:

1. **`/alfred:3-sync`**: 문서 동기화, TAG 체인 검증
2. **`/alfred:1-spec "HTML 템플릿 생성"`**: SPEC-HTML-001 작성
3. **병렬 개발**: `SPEC-SHEETS-001` (Google Sheets 데이터 로더)

**예상 타임라인**:
- Week 1: Phase 1-2 (데이터 모델 + FigmaClient)
- Week 2: Phase 3-4 (LayoutParser + DesignValidator)
- Week 3: Phase 5 + 통합 테스트 + 문서화

---

_이 계획서는 `/alfred:2-build SPEC-FIGMA-001` 실행 시 TDD 구현의 가이드라인이 됩니다._
