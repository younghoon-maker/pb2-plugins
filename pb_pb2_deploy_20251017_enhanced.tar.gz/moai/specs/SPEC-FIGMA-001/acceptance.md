# SPEC-FIGMA-001 인수 기준

> **Given-When-Then (Gherkin) 형식의 인수 테스트 시나리오**

---

## Feature: Figma 메타데이터 추출

**As a** 개발자
**I want to** Figma MCP를 통해 디자인 메타데이터를 추출하고 싶다
**So that** HTML 생성에 필요한 정확한 레이아웃 정보를 얻을 수 있다

---

## Scenario 1: 정상적인 메타데이터 추출

**우선순위**: 높음
**태그**: `@figma-mcp` `@happy-path`

```gherkin
Given Figma Desktop App이 실행 중이고
And Figma 파일 URL "https://www.figma.com/design/wBdUdgAJtuBr5nn7w38LOB/pb2_new_template?node-id=1-95&m=dev"이 제공되었을 때
And 노드 ID "1-95"가 제공되었을 때
When FigmaClient.get_metadata("1-95")를 호출하면
Then 시스템은 10개 섹션의 레이아웃 정보를 JSON으로 반환해야 한다
And 각 섹션은 다음 필수 필드를 포함해야 한다:
  | 필드 | 타입 | 예시 |
  | id | string | "1:159" |
  | name | string | "Product Hero" |
  | figma_group | string | "Group 10" |
  | x | int | 24 |
  | y | int | 180 |
  | width | int | 1033 |
  | height | int | 1749 |
  | styles | object | {"font-family": "Pretendard"} |
And 레이아웃 오차는 ±2px 이내여야 한다
And Pretendard 폰트 스타일 정보가 포함되어야 한다
And 응답 시간은 10초를 초과하지 않아야 한다
```

**검증 방법**:
```python
def test_normal_metadata_extraction():
    client = FigmaClient()
    result = client.get_metadata("1-95")

    # 10개 섹션 확인
    assert len(result["sections"]) == 10

    # 첫 번째 섹션 검증 (Product Hero)
    hero = result["sections"][0]
    assert hero["name"] == "Product Hero"
    assert hero["figma_group"] == "Group 10"
    assert hero["width"] == 1033
    assert hero["height"] == 1749

    # 폰트 스타일 확인
    assert "Pretendard" in hero["styles"]["font-family"]
```

---

## Scenario 2: Figma API 타임아웃 및 캐시 사용

**우선순위**: 높음
**태그**: `@figma-mcp` `@timeout` `@cache`

```gherkin
Given Figma MCP API 응답이 10초를 초과했을 때
And 로컬 캐시에 "1-95" 노드 데이터가 존재할 때 (`.cache/figma/1-95.json`)
When FigmaClient가 타임아웃을 감지하면
Then 시스템은 로컬 캐시에서 데이터를 로드해야 한다
And 경고 로그를 남겨야 한다: "Figma API timeout (>10s), using cached data"
And 캐시된 데이터를 정상적으로 반환해야 한다
And 캐시 데이터는 TTL(1시간) 내에 유효해야 한다
```

**검증 방법**:
```python
def test_timeout_with_cache(mock_mcp_api, caplog):
    # API 타임아웃 시뮬레이션
    mock_mcp_api.side_effect = Timeout("API response exceeded 10 seconds")

    # 캐시 사전 준비
    cache_manager = CacheManager()
    cache_manager.save("1-95", {"sections": [...]})

    # 클라이언트 호출
    client = FigmaClient()
    result = client.get_metadata("1-95")

    # 캐시에서 로드 확인
    assert result is not None
    assert "Figma API timeout" in caplog.text
    assert "using cached data" in caplog.text
```

---

## Scenario 3: 캐시 없을 시 에러 발생

**우선순위**: 높음
**태그**: `@figma-mcp` `@timeout` `@error`

```gherkin
Given Figma MCP API 응답이 10초를 초과했을 때
And 로컬 캐시에 데이터가 없을 때
When FigmaClient가 타임아웃을 감지하면
Then 시스템은 FigmaAPIError를 발생시켜야 한다
And 에러 메시지는 "Timeout and no cache available for node 1-95"를 포함해야 한다
And 에러 로그를 남겨야 한다
```

**검증 방법**:
```python
def test_timeout_without_cache(mock_mcp_api):
    # API 타임아웃 + 캐시 없음
    mock_mcp_api.side_effect = Timeout()

    client = FigmaClient()

    with pytest.raises(FigmaAPIError) as exc_info:
        client.get_metadata("1-95")

    assert "Timeout and no cache available" in str(exc_info.value)
    assert "1-95" in str(exc_info.value)
```

---

## Scenario 4: 필수 섹션 누락 시 검증 실패

**우선순위**: 높음
**태그**: `@validation` `@required-sections`

```gherkin
Given Figma 메타데이터가 추출되었을 때
And "Product Hero" 섹션이 누락되었을 때 (9개 섹션만 존재)
When DesignValidator.validate_sections(design_spec)를 호출하면
Then 시스템은 ValidationError를 발생시켜야 한다
And 에러 메시지는 "Missing required section: Product Hero"를 포함해야 한다
And 누락된 섹션 목록을 로그에 남겨야 한다
```

**검증 방법**:
```python
def test_missing_required_section():
    # Product Hero 제외한 9개 섹션만 포함
    incomplete_spec = DesignSpec(
        sections=[
            Section(name="Color Variants", ...),
            Section(name="Lifestyle Gallery", ...),
            # ... 9개만
        ]
    )

    validator = DesignValidator()

    with pytest.raises(ValidationError) as exc_info:
        validator.validate_sections(incomplete_spec)

    assert "Missing required section: Product Hero" in str(exc_info.value)
```

---

## Scenario 5: 레이아웃 오차 검증 (±2px 이내)

**우선순위**: 중간
**태그**: `@validation` `@pixel-perfect`

```gherkin
Given Figma 메타데이터가 추출되었을 때
And LayoutParser가 10개 섹션의 좌표를 계산했을 때
When DesignValidator.validate_layout_accuracy(design_spec)를 호출하면
Then 시스템은 각 섹션의 Figma 원본 좌표와 비교해야 한다
And 모든 섹션의 오차가 ±2px 이내이면 빈 리스트를 반환해야 한다
And 오차 리포트는 다음 형식이어야 한다:
  | 섹션명 | 원본 좌표 | 계산 좌표 | 오차 |
  | Product Hero | (24, 180) | (24, 180) | 0px |
  | Color Variants | (0, 1996) | (0, 1996) | 0px |
```

**검증 방법**:
```python
def test_layout_accuracy_within_2px(valid_design_spec):
    validator = DesignValidator()
    errors = validator.validate_layout_accuracy(valid_design_spec)

    # 오차 없음
    assert errors == []

def test_layout_accuracy_exceeds_2px(inaccurate_design_spec):
    # Product Hero의 Y 좌표가 +5px 오차
    validator = DesignValidator()
    errors = validator.validate_layout_accuracy(inaccurate_design_spec)

    assert len(errors) > 0
    assert "Product Hero" in errors[0]
    assert "+5px" in errors[0]
```

---

## Scenario 6: Figma API 3회 재시도 전략

**우선순위**: 중간
**태그**: `@figma-mcp` `@retry` `@resilience`

```gherkin
Given Figma MCP API가 일시적으로 불안정한 상태일 때
And 첫 번째 호출이 ConnectionError로 실패했을 때
And 두 번째 호출이 ConnectionError로 실패했을 때
And 세 번째 호출이 성공했을 때
When FigmaClient.get_metadata("1-95")를 호출하면
Then 시스템은 최대 3회 재시도해야 한다
And 재시도 간격은 exponential backoff 전략을 따라야 한다 (1s, 2s, 4s)
And 세 번째 시도에서 정상 응답을 반환해야 한다
And 각 재시도 시도를 로그에 남겨야 한다
```

**검증 방법**:
```python
def test_retry_strategy_succeeds_on_third_attempt(mock_mcp_api, caplog):
    # 첫 2회 실패, 3회 성공
    mock_mcp_api.side_effect = [
        ConnectionError("Network error"),
        ConnectionError("Network error"),
        {"sections": [...]}  # 성공
    ]

    client = FigmaClient()
    result = client.get_metadata("1-95")

    # 3회 호출 확인
    assert mock_mcp_api.call_count == 3

    # 재시도 로그 확인
    assert "Retry 1/3" in caplog.text
    assert "Retry 2/3" in caplog.text

    # 최종 성공
    assert result is not None
```

---

## Scenario 7: 3회 재시도 모두 실패 시 에러

**우선순위**: 중간
**태그**: `@figma-mcp` `@retry` `@error`

```gherkin
Given Figma MCP API가 지속적으로 실패하는 상태일 때
And 첫 번째 호출이 실패했을 때
And 두 번째 호출이 실패했을 때
And 세 번째 호출이 실패했을 때
When FigmaClient.get_metadata("1-95")를 호출하면
Then 시스템은 3회 재시도 후 FigmaAPIError를 발생시켜야 한다
And 에러 메시지는 "Failed after 3 retries"를 포함해야 한다
And 시스템은 오프라인 모드로 전환해야 한다 (후속 호출은 캐시만 사용)
```

**검증 방법**:
```python
def test_retry_strategy_fails_after_3_attempts(mock_mcp_api):
    # 모든 시도 실패
    mock_mcp_api.side_effect = ConnectionError("Persistent network error")

    client = FigmaClient()

    with pytest.raises(FigmaAPIError) as exc_info:
        client.get_metadata("1-95")

    assert mock_mcp_api.call_count == 3
    assert "Failed after 3 retries" in str(exc_info.value)
```

---

## Scenario 8: Pretendard 폰트 스타일 추출

**우선순위**: 중간
**태그**: `@font-parsing` `@pretendard`

```gherkin
Given Figma 메타데이터에 Pretendard 폰트 스타일 정보가 포함되어 있을 때
And 폰트 weight가 Light (300) 또는 Regular (400)일 때
When LayoutParser.extract_font_styles(node)를 호출하면
Then 시스템은 다음 폰트 정보를 반환해야 한다:
  | 속성 | 값 |
  | font-family | "Pretendard" |
  | font-weight | 300 또는 400 |
  | font-size | "16px" 형식 |
  | line-height | "24px" 형식 또는 1.5 비율 |
And CSS 속성 형식으로 변환되어야 한다
```

**검증 방법**:
```python
def test_extract_pretendard_font_styles():
    parser = LayoutParser()

    node = {
        "style": {
            "fontFamily": "Pretendard",
            "fontWeight": 400,
            "fontSize": 16,
            "lineHeight": 24
        }
    }

    styles = parser.extract_font_styles(node)

    assert styles["font-family"] == "Pretendard"
    assert styles["font-weight"] == 400
    assert styles["font-size"] == "16px"
    assert styles["line-height"] == "24px"
```

---

## Scenario 9: 캐시 TTL 만료 후 재호출

**우선순위**: 낮음
**태그**: `@cache` `@ttl`

```gherkin
Given 로컬 캐시에 "1-95" 노드 데이터가 2시간 전에 저장되었을 때
And 캐시 TTL이 1시간으로 설정되어 있을 때
When FigmaClient.get_metadata("1-95")를 호출하면
Then 시스템은 캐시가 만료되었음을 감지해야 한다
And Figma MCP API를 다시 호출해야 한다
And 새로운 응답을 캐시에 저장해야 한다
And INFO 로그를 남겨야 한다: "Cache expired for node 1-95, fetching from API"
```

**검증 방법**:
```python
def test_cache_ttl_expired(mock_mcp_api, freezegun):
    # 캐시 저장 (현재 시간)
    cache_manager = CacheManager(ttl=3600)  # 1시간
    cache_manager.save("1-95", {"old": "data"})

    # 2시간 후로 시간 이동
    freezegun.freeze_time("2 hours later")

    # API 호출 시뮬레이션
    mock_mcp_api.return_value = {"new": "data"}

    client = FigmaClient()
    result = client.get_metadata("1-95")

    # API 재호출 확인
    assert mock_mcp_api.called
    assert result["new"] == "data"

    # 새 캐시 저장 확인
    cached = cache_manager.load("1-95")
    assert cached["new"] == "data"
```

---

## Scenario 10: 개발 모드에서 중간 결과 로깅

**우선순위**: 낮음
**태그**: `@debug` `@logging`

```gherkin
Given 환경변수 DEBUG=true로 설정되어 있을 때
And 개발 모드가 활성화되어 있을 때
When LayoutParser.parse_layout(metadata)를 호출하면
Then 시스템은 다음 중간 결과를 DEBUG 로그에 남겨야 한다:
  - 파싱 시작 시간
  - 각 섹션 파싱 완료 시점
  - 절대 좌표 계산 과정
  - 폰트 스타일 추출 결과
  - 총 파싱 시간
And 로그 레벨은 DEBUG여야 한다
And 민감 정보(API 키)는 마스킹되어야 한다
```

**검증 방법**:
```python
def test_debug_logging_in_dev_mode(caplog):
    os.environ["DEBUG"] = "true"

    parser = LayoutParser()

    with caplog.at_level(logging.DEBUG):
        parser.parse_layout(sample_metadata)

    # DEBUG 로그 확인
    assert "Parsing started" in caplog.text
    assert "Section 'Product Hero' parsed" in caplog.text
    assert "Total parsing time:" in caplog.text
```

---

## 인수 기준 요약

### 필수 시나리오 (통과 필수)

✅ **Scenario 1**: 정상적인 메타데이터 추출
✅ **Scenario 2**: Figma API 타임아웃 및 캐시 사용
✅ **Scenario 3**: 캐시 없을 시 에러 발생
✅ **Scenario 4**: 필수 섹션 누락 시 검증 실패
✅ **Scenario 5**: 레이아웃 오차 검증 (±2px 이내)

### 권장 시나리오 (높은 우선순위)

✅ **Scenario 6**: Figma API 3회 재시도 전략
✅ **Scenario 7**: 3회 재시도 모두 실패 시 에러
✅ **Scenario 8**: Pretendard 폰트 스타일 추출

### 선택 시나리오 (낮은 우선순위)

✅ **Scenario 9**: 캐시 TTL 만료 후 재호출
✅ **Scenario 10**: 개발 모드에서 중간 결과 로깅

---

## 통합 테스트 (End-to-End)

### E2E Scenario: Figma → JSON 전체 파이프라인

```gherkin
Given Figma Desktop App이 실행 중이고
And Figma 파일 URL과 노드 ID가 제공되었을 때
When 전체 파이프라인을 실행하면:
  1. FigmaClient.get_metadata("1-95") 호출
  2. LayoutParser.parse_layout(metadata) 호출
  3. DesignValidator.validate_sections(spec) 호출
  4. DesignSpec.to_json() 직렬화
Then 시스템은 다음을 만족하는 JSON 파일을 생성해야 한다:
  - 10개 섹션 정보 포함
  - 각 섹션의 레이아웃 정보 정확도 ±2px
  - Pretendard 폰트 스타일 정보 포함
  - JSON 유효성 검증 통과
  - 파일 크기 < 1MB
  - 전체 실행 시간 < 15초
```

**검증 방법**:
```python
def test_end_to_end_pipeline():
    # 1. Figma 메타데이터 추출
    client = FigmaClient()
    metadata = client.get_metadata("1-95")

    # 2. 레이아웃 파싱
    parser = LayoutParser()
    spec = parser.parse_layout(metadata)

    # 3. 검증
    validator = DesignValidator()
    assert validator.validate_sections(spec)
    errors = validator.validate_layout_accuracy(spec)
    assert errors == []

    # 4. JSON 직렬화
    json_output = spec.to_json()

    # 검증
    assert len(spec.sections) == 10
    assert json.loads(json_output)  # 유효한 JSON
    assert len(json_output) < 1024 * 1024  # < 1MB
```

---

_이 인수 기준은 `/alfred:2-build SPEC-FIGMA-001` 실행 시 TDD 구현의 검증 기준이 됩니다._
