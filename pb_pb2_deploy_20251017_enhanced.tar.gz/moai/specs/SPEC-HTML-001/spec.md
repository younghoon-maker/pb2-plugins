---
id: HTML-001
version: 0.1.0
status: completed
created: 2025-10-15
updated: 2025-10-15
author: @younghoonjung
priority: high
category: feature
labels:
  - html-generator
  - jinja2
  - pixel-perfect
depends_on:
  - FIGMA-001
scope:
  packages:
    - src/html_generator.py
    - src/template_engine.py
    - src/layout_renderer.py
  files:
    - html_generator.py
    - template_engine.py
    - layout_renderer.py
---

# @SPEC:HTML-001: HTML 템플릿 생성기 - 픽셀 퍼펙트 레이아웃

## HISTORY

### v0.1.0 (2025-10-15)
- **COMPLETED**: HTML 템플릿 생성기 TDD 구현 완료 (`generate_figma_continuous_2x.py`)
- **AUTHOR**: @younghoonjung
- **IMPLEMENTATION**:
  - 동적 컨테이너 높이 계산 (`calculate_actual_content_height()`)
  - 실제 콘텐츠 기반 섹션 배치 (총 높이 35,216px → 24,018px, 32% 감소)
  - CSS Flexbox 레이아웃 (Product Info, Care Instructions, Model Info)
  - VISCOSE 텍스트 이미지 중앙 정렬 (`top: 50%; transform: translateY(-50%)`)
  - 섹션 6-8 오른쪽 콘텐츠 x 좌표 통일 (120px gap)
  - Care Instructions 네스티드 레이아웃 (13px gap, 수직 중앙 정렬)
- **TESTS**: 15개 테스트 통과, 97% 커버리지
- **TAG**: @CODE:HTML-001:DOMAIN → `generate_figma_continuous_2x.py`
- **REASON**: 사용자 피드백 6가지 반영 (빈 공간 제거, 레이아웃 정렬 개선)

### v0.0.1 (2025-10-15)
- **INITIAL**: HTML 템플릿 생성기 명세 최초 작성
- **AUTHOR**: @younghoonjung
- **SCOPE**: DesignSpec JSON → HTML/CSS 변환, Jinja2 템플릿 렌더링, 픽셀 정확도 검증
- **CONTEXT**: pb_pb2_new_page 프로젝트의 두 번째 SPEC, 3-Tier 파이프라인 Processing Layer 구현
- **PRIORITY**: Phase 1 - 기본 파이프라인 구축의 핵심 단계
- **DEPENDS_ON**: SPEC-FIGMA-001 (completed) - DesignSpec JSON 데이터 모델 의존

---

## Environment (환경)

### 필수 환경

- **Python 버전**: 3.11 이상
- **필수 라이브러리**:
  - `jinja2>=3.1.0` - 템플릿 엔진
  - `pydantic>=2.4.0` - 데이터 검증
- **입력 데이터**: DesignSpec JSON (SPEC-FIGMA-001 출력)
- **출력 위치**: `output/` 디렉토리
  - `output/original.html` - 읽기 전용 HTML
  - `output/editable.html` - 편집 가능 HTML (Phase 2)

### 디자인 제약

- **캔버스 크기**: 1082px × 25520px (고정)
- **섹션 구조**: 10개 섹션 (Product Hero → Size Chart)
- **폰트**: Pretendard 웹폰트 (Google Fonts CDN)
- **레이아웃**: CSS absolute positioning 기반
- **픽셀 정확도**: Figma 대비 ±2px 이내

### 템플릿 구조

```
templates/
├── base.html.jinja2           # 기본 HTML 골격
├── sections/
│   ├── product_hero.html.jinja2
│   ├── color_variants.html.jinja2
│   ├── lifestyle_gallery.html.jinja2
│   ├── material_detail.html.jinja2
│   ├── color_selector.html.jinja2
│   ├── product_info.html.jinja2
│   ├── care_instructions.html.jinja2
│   ├── model_info.html.jinja2
│   ├── size_guide.html.jinja2
│   └── size_chart.html.jinja2
└── styles/
    ├── reset.css              # CSS 리셋
    └── layout.css             # 레이아웃 스타일
```

---

## Assumptions (가정)

### 기술적 가정

1. **DesignSpec 유효성**: SPEC-FIGMA-001에서 생성된 DesignSpec JSON이 유효하다고 가정
2. **웹폰트 접근**: Pretendard 웹폰트를 Google Fonts CDN에서 로드 가능
3. **브라우저 타겟**: 크롬 기준 개발, 최신 CSS 지원 (position: absolute, CSS variables)
4. **HTML 크기**: 단일 HTML 파일 크기 30MB 이하 (Base64 이미지 임베딩 포함)

### 비즈니스 가정

1. **픽셀 퍼펙트 목표**: ±2px 오차 허용 (Figma와 HTML 렌더링 차이)
2. **섹션 순서 고정**: 10개 섹션은 순서대로 렌더링 (동적 재배치 없음)
3. **에디터블 모드**: Phase 2에서 구현 (현재는 Original HTML만 생성)
4. **이미지 데이터**: Base64 인코딩은 별도 모듈(Image Encoder)에서 제공

---

## Requirements (요구사항)

### Ubiquitous Requirements (필수 기능)

- 시스템은 DesignSpec JSON을 입력받아 HTML/CSS를 생성해야 한다
  - 입력: `DesignSpec` 객체 (Pydantic 모델)
  - 출력: HTML 파일 경로 (str)

- 시스템은 Figma 레이아웃 대비 ±2px 이내 오차로 재현해야 한다
  - 각 섹션의 x, y, width, height를 CSS로 정확히 변환
  - `position: absolute` 기반 레이아웃

- 시스템은 Pretendard 웹폰트를 로드해야 한다
  - Google Fonts CDN 사용: `https://fonts.googleapis.com/css2?family=Pretendard:wght@300;400&display=swap`
  - `<link>` 태그로 `<head>`에 삽입

- 시스템은 10개 섹션을 순서대로 렌더링해야 한다
  - 섹션 순서: Product Hero → Color Variants → ... → Size Chart
  - 각 섹션은 독립적인 Jinja2 템플릿 파일로 관리

- 시스템은 Jinja2 템플릿 엔진을 사용해야 한다
  - 템플릿 디렉토리: `templates/`
  - 템플릿 파일 확장자: `.html.jinja2`

- 시스템은 반응형 CSS (1082px 기준)를 생성해야 한다
  - CSS 변수 사용: `--canvas-width`, `--section-*`
  - 미디어 쿼리는 Phase 2에서 추가 (현재는 고정 레이아웃)

### Event-driven Requirements (이벤트 기반)

- WHEN DesignSpec JSON이 누락되거나 형식이 잘못되면, 시스템은 `ValidationError`를 발생시켜야 한다
  - 필수 필드 검증: `width`, `height`, `sections` (10개)
  - Pydantic 검증 실패 시 상세 에러 메시지 제공

- WHEN 레이아웃 오차가 ±2px를 초과하면, 시스템은 경고 로그와 함께 오차 리포트를 생성해야 한다
  - 오차 리포트 형식: `{"section": "Product Hero", "expected": {"x": 0, "y": 0}, "actual": {"x": 0, "y": 3}, "diff": 3}`
  - 로그 수준: WARNING
  - 파일 출력: `output/layout_error_report.json`

- WHEN 필수 섹션(10개)이 누락되면, 시스템은 `ValidationError`를 발생시켜야 한다
  - 에러 메시지: `"Missing required section: {section_name}"`
  - 누락된 섹션 목록 포함

- WHEN 웹폰트 로드에 실패하면, 시스템은 시스템 폰트로 폴백해야 한다
  - 폴백 체인: `Pretendard, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`
  - 경고 로그: `"Web font load failed, using fallback fonts"`

### State-driven Requirements (상태 기반)

- WHILE HTML 생성 중일 때, 시스템은 진행률을 로깅해야 한다
  - 로그 형식: `"Rendering section 3/10: Lifestyle Gallery"`
  - 로그 수준: INFO
  - Rich 라이브러리 사용 권장 (프로그레스 바)

- WHILE 템플릿 렌더링 중일 때, 시스템은 각 섹션의 좌표와 크기를 검증해야 한다
  - 검증 시점: 각 섹션 렌더링 직후
  - 검증 항목: x, y, width, height (Figma 스펙과 비교)
  - 오차 허용: ±2px

### Optional Features (선택 기능)

- WHERE 디버그 모드가 활성화되면, 시스템은 각 섹션에 디버그 정보를 표시할 수 있다
  - 디버그 정보: 섹션 ID, 좌표, 크기, Figma Group ID
  - 표시 방법: HTML 주석 또는 `data-*` 속성
  - 활성화 조건: `DEBUG=true` 환경 변수

- WHERE 다크모드 옵션이 제공되면, 시스템은 다크모드 CSS를 생성할 수 있다
  - CSS 변수 오버라이드: `--bg-color`, `--text-color`
  - 활성화 조건: `DARK_MODE=true` 환경 변수 (Phase 2)

### Constraints (제약사항)

- 생성된 HTML 파일 크기는 30MB를 초과하지 않아야 한다
  - 측정 시점: 파일 저장 직후
  - 초과 시 조치: 경고 로그, 파일 생성은 계속

- HTML 생성 시간은 15초를 초과하지 않아야 한다
  - 측정 범위: `HTMLGenerator.generate()` 메서드 전체
  - 초과 시 조치: 경고 로그, 성능 프로파일링 데이터 수집

- IF 캔버스 너비가 1082px가 아니면, 시스템은 `ValidationError`를 발생시켜야 한다
  - 에러 메시지: `"Invalid canvas width: {width}px (expected: 1082px)"`
  - 검증 시점: DesignSpec 로드 직후

- 모든 CSS는 인라인 스타일이 아닌 클래스 기반이어야 한다
  - 클래스 네이밍: BEM 방식 권장 (예: `.section`, `.section__title`, `.section--hero`)
  - 인라인 스타일 금지 (예외: 디버그 모드)

---

## Components (구성요소)

### HTMLGenerator (@CODE:HTML-001:DOMAIN)

**책임**: DesignSpec → HTML 변환 오케스트레이션

**메서드**:
```python
class HTMLGenerator:
    def __init__(
        self,
        template_engine: TemplateEngine,
        layout_renderer: LayoutRenderer,
        output_dir: str = "output",
    ):
        """HTML 생성기 초기화.

        Args:
            template_engine: Jinja2 템플릿 엔진
            layout_renderer: CSS 레이아웃 렌더러
            output_dir: 출력 디렉토리 경로
        """

    def generate(self, design_spec: DesignSpec) -> str:
        """DesignSpec을 HTML로 변환합니다.

        Args:
            design_spec: Figma 디자인 스펙 객체

        Returns:
            str: 생성된 HTML 파일 경로 (예: "output/original.html")

        Raises:
            ValidationError: DesignSpec 검증 실패 시
            TemplateError: 템플릿 렌더링 실패 시
            LayoutError: 레이아웃 오차 초과 시 (경고)
        """

    def validate_spec(self, design_spec: DesignSpec) -> bool:
        """DesignSpec 유효성 검증.

        Args:
            design_spec: 검증할 디자인 스펙

        Returns:
            bool: 검증 성공 여부

        Raises:
            ValidationError: 필수 섹션 누락, 캔버스 크기 불일치 등
        """

    def _render_sections(self, design_spec: DesignSpec) -> List[str]:
        """10개 섹션을 순차적으로 렌더링.

        Args:
            design_spec: 디자인 스펙

        Returns:
            List[str]: 렌더링된 섹션 HTML 목록 (10개)
        """

    def _generate_css(self, design_spec: DesignSpec) -> str:
        """레이아웃 CSS 생성.

        Args:
            design_spec: 디자인 스펙

        Returns:
            str: CSS 코드 (절대 포지셔닝 기반)
        """

    def _save_html(self, html: str, filename: str = "original.html") -> str:
        """HTML 파일 저장.

        Args:
            html: HTML 코드
            filename: 파일명

        Returns:
            str: 저장된 파일 경로
        """
```

**의존성**:
- `TemplateEngine` (Jinja2 래퍼)
- `LayoutRenderer` (CSS 생성)
- `DesignSpec` (Pydantic 모델)

**에러 처리**:
- `ValidationError`: DesignSpec 검증 실패
- `TemplateError`: Jinja2 렌더링 실패
- `LayoutError`: 레이아웃 오차 초과 (경고, 생성 계속)

---

### TemplateEngine (@CODE:HTML-001:UI)

**책임**: Jinja2 템플릿 관리 및 렌더링

**메서드**:
```python
class TemplateEngine:
    def __init__(self, template_dir: str = "templates"):
        """템플릿 엔진 초기화.

        Args:
            template_dir: 템플릿 디렉토리 경로
        """

    def render(self, template_name: str, context: Dict[str, Any]) -> str:
        """템플릿 렌더링.

        Args:
            template_name: 템플릿 파일명 (예: "base.html.jinja2")
            context: 템플릿 컨텍스트 (변수 딕셔너리)

        Returns:
            str: 렌더링된 HTML

        Raises:
            TemplateNotFoundError: 템플릿 파일 없음
            TemplateSyntaxError: 템플릿 문법 오류
        """

    def render_section(self, section_name: str, section: Section) -> str:
        """섹션별 템플릿 렌더링.

        Args:
            section_name: 섹션명 (예: "product_hero")
            section: Section 객체

        Returns:
            str: 렌더링된 섹션 HTML
        """

    def get_base_template(self) -> str:
        """기본 HTML 골격 템플릿 로드.

        Returns:
            str: base.html.jinja2 경로
        """

    def _load_template(self, template_name: str) -> jinja2.Template:
        """Jinja2 템플릿 로드 (내부 메서드).

        Args:
            template_name: 템플릿 파일명

        Returns:
            jinja2.Template: 로드된 템플릿 객체
        """
```

**Jinja2 설정**:
```python
from jinja2 import Environment, FileSystemLoader

env = Environment(
    loader=FileSystemLoader("templates"),
    autoescape=True,  # XSS 방지
    trim_blocks=True,
    lstrip_blocks=True,
)
```

**템플릿 변수**:
- `canvas_width`: 1082
- `canvas_height`: 25520
- `sections`: List[Section]
- `font_family`: "Pretendard"
- `debug_mode`: bool

---

### LayoutRenderer (@CODE:HTML-001:DOMAIN)

**책임**: CSS 레이아웃 계산 및 생성

**메서드**:
```python
class LayoutRenderer:
    def __init__(self, pixel_tolerance: int = 2):
        """레이아웃 렌더러 초기화.

        Args:
            pixel_tolerance: 픽셀 오차 허용 범위 (기본: 2px)
        """

    def render_css(self, design_spec: DesignSpec) -> str:
        """전체 CSS 생성.

        Args:
            design_spec: 디자인 스펙

        Returns:
            str: CSS 코드 (변수 + 섹션별 스타일)
        """

    def render_section_css(self, section: Section) -> str:
        """섹션별 CSS 스타일 생성.

        Args:
            section: Section 객체

        Returns:
            str: CSS 코드 (position: absolute 기반)

        Example:
            .section--product-hero {
                position: absolute;
                left: 0px;
                top: 0px;
                width: 1033px;
                height: 1749px;
            }
        """

    def validate_layout(self, section: Section) -> Optional[Dict[str, Any]]:
        """레이아웃 정확도 검증 (±2px).

        Args:
            section: 검증할 Section 객체

        Returns:
            Optional[Dict[str, Any]]: 오차 발견 시 오차 리포트, 없으면 None

        Example:
            {
                "section": "Product Hero",
                "expected": {"x": 0, "y": 0},
                "actual": {"x": 0, "y": 3},
                "diff": 3,
                "exceeds_tolerance": True
            }
        """

    def _calculate_absolute_position(self, section: Section) -> Dict[str, int]:
        """절대 좌표 계산.

        Args:
            section: Section 객체

        Returns:
            Dict[str, int]: {"x": 0, "y": 0, "width": 1033, "height": 1749}
        """
```

**CSS 변수 생성**:
```css
:root {
  --canvas-width: 1082px;
  --canvas-height: 25520px;
  --font-family: 'Pretendard', sans-serif;

  /* 섹션별 변수 */
  --section-hero-x: 0px;
  --section-hero-y: 0px;
  --section-hero-width: 1033px;
  --section-hero-height: 1749px;
}
```

**픽셀 정확도 검증 로직**:
```python
def validate_layout(self, section: Section) -> Optional[Dict[str, Any]]:
    expected = {"x": section.x, "y": section.y}
    actual = self._calculate_absolute_position(section)

    diff_x = abs(expected["x"] - actual["x"])
    diff_y = abs(expected["y"] - actual["y"])
    max_diff = max(diff_x, diff_y)

    if max_diff > self.pixel_tolerance:
        return {
            "section": section.name,
            "expected": expected,
            "actual": actual,
            "diff": max_diff,
            "exceeds_tolerance": True,
        }
    return None
```

---

## Traceability (@TAG)

**TAG 체계**:
- **SPEC**: `@SPEC:HTML-001` (`.moai/specs/SPEC-HTML-001/spec.md`)
- **TEST**: `@TEST:HTML-001` (`tests/test_html_generator.py`)
- **CODE**: `@CODE:HTML-001` (`src/html_generator.py`)
- **DOC**: `@DOC:HTML-001` (`docs/html-generation.md`)

**TAG 서브 카테고리**:
- `@CODE:HTML-001:DOMAIN` → `HTMLGenerator`, `LayoutRenderer` (비즈니스 로직)
- `@CODE:HTML-001:UI` → `TemplateEngine`, Jinja2 템플릿 (프레젠테이션)
- `@CODE:HTML-001:DATA` → CSS 생성, 레이아웃 계산 (데이터 변환)

**TAG 검증 방법**:
```bash
# SPEC → TEST → CODE 체인 확인
rg '@SPEC:HTML-001' -n .moai/specs/
rg '@TEST:HTML-001' -n tests/
rg '@CODE:HTML-001' -n src/

# 고아 TAG 탐지
rg '@CODE:HTML-001' -n src/          # CODE는 있는데
rg '@SPEC:HTML-001' -n .moai/specs/  # SPEC이 없으면 고아
```

**의존성 그래프**:
```
@SPEC:FIGMA-001 (completed)
    ↓
@SPEC:HTML-001 (draft)
    ↓
@SPEC:EDIT-001 (pending) - 에디터블 모드
```

---

## Performance & Quality

### 성능 목표

- **HTML 생성 시간**: 15초 이내
  - DesignSpec 검증: 1초 이내
  - 템플릿 렌더링: 10초 이내 (10개 섹션)
  - CSS 생성: 2초 이내
  - 파일 저장: 2초 이내

- **파일 크기**: 30MB 이하 (Base64 이미지 포함)
  - HTML 구조: ~100KB
  - CSS: ~50KB
  - Base64 이미지: ~29MB (Image Encoder에서 제공)

- **메모리 사용량**: 500MB 이하
  - DesignSpec 로드: ~10MB
  - 템플릿 렌더링: ~100MB
  - HTML 문자열: ~30MB

### 품질 기준 (TRUST 원칙)

- **Test First**: pytest 커버리지 85% 이상
  - 단위 테스트: `HTMLGenerator`, `TemplateEngine`, `LayoutRenderer`
  - 통합 테스트: 전체 파이프라인 (DesignSpec → HTML)
  - 픽셀 정확도 테스트: ±2px 검증

- **Readable**: 함수 50 LOC 이하, 파일 300 LOC 이하
  - `html_generator.py`: ~200 LOC
  - `template_engine.py`: ~150 LOC
  - `layout_renderer.py`: ~200 LOC

- **Unified**: Pydantic 타입 안전성, mypy strict 모드
  - 모든 함수에 타입 힌트 필수
  - Pydantic 모델 검증 (DesignSpec, Section)

- **Secured**: XSS 방지, 민감 정보 로깅 금지
  - Jinja2 autoescape 활성화
  - 사용자 입력 없음 (DesignSpec은 내부 데이터)

- **Trackable**: @TAG 시스템, CODE-FIRST 원칙
  - 모든 클래스/함수에 @TAG 주석 추가
  - TAG 체인: SPEC → TEST → CODE → DOC

---

## Error Handling

### 커스텀 예외

```python
class HTMLGeneratorError(Exception):
    """HTML Generator 기본 예외"""
    pass

class ValidationError(HTMLGeneratorError):
    """DesignSpec 검증 실패"""
    pass

class TemplateError(HTMLGeneratorError):
    """Jinja2 템플릿 렌더링 실패"""
    pass

class LayoutError(HTMLGeneratorError):
    """레이아웃 오차 초과 (경고)"""
    pass

class FileSizeError(HTMLGeneratorError):
    """HTML 파일 크기 초과 (경고)"""
    pass
```

### 에러 핸들링 전략

1. **DesignSpec 검증 실패**: `ValidationError` 발생, 상세 에러 메시지 제공
   - 필수 섹션 누락 → 누락된 섹션 목록 포함
   - 캔버스 크기 불일치 → 기대값 vs 실제값 표시

2. **템플릿 렌더링 실패**: `TemplateError` 발생, 템플릿 파일명 및 라인 번호 포함
   - Jinja2 예외 래핑 → 사용자 친화적 메시지로 변환

3. **레이아웃 오차 초과**: `LayoutError` 발생 (경고), HTML 생성은 계속
   - 오차 리포트 JSON 파일 저장 (`output/layout_error_report.json`)

4. **파일 크기 초과**: `FileSizeError` 발생 (경고), 파일 저장은 계속
   - 로그 메시지: `"HTML file size exceeds 30MB: {size}MB"`

### 로깅 전략

```python
import logging
from rich.logging import RichHandler

logger = logging.getLogger(__name__)

# 성공 로그
logger.info("Rendering section 3/10: Lifestyle Gallery")

# 경고 로그
logger.warning(f"Layout accuracy: {max_diff}px exceeds tolerance (2px)")

# 에러 로그
logger.error(f"Template not found: {template_name}")
```

---

## Dependencies

### 선행 작업
- **SPEC-FIGMA-001**: 완료 (v0.1.0) - DesignSpec JSON 필수

### 후속 SPEC 차단
- **SPEC-EDIT-001**: 에디터블 모드 구현 (Editable HTML 생성 필요)
- **SPEC-EXPORT-001**: JPG/HTML 익스포트 서버 (생성된 HTML 필요)

### 병렬 개발 가능
- **SPEC-SHEETS-001**: Google Sheets 데이터 로더 (독립적, 이미지 데이터 제공)

### 관련 SPEC (향후)
- **SPEC-IMAGE-001**: Image Encoder (Base64 인코딩) - Phase 1
- **SPEC-QA-001**: 픽셀 정확도 자동 검증 시스템 - Phase 3

---

## References

- **product.md**: 10개 섹션 정의, 픽셀 퍼펙트 목표 (±2px)
- **structure.md**: 3-Tier 파이프라인, Processing Layer 아키텍처
- **tech.md**: Python 3.11+, Jinja2, pytest, ruff 기준
- **SPEC-FIGMA-001/spec.md**: DesignSpec 데이터 모델 (Section, DesignSpec)
- **Jinja2 Documentation**: https://jinja.palletsprojects.com/
- **CSS absolute positioning**: https://developer.mozilla.org/en-US/docs/Web/CSS/position

---

_이 SPEC은 `/alfred:2-build SPEC-HTML-001` 실행 시 TDD 구현의 기준이 됩니다._
