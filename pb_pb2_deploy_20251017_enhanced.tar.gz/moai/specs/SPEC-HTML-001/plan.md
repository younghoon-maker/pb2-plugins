# @SPEC:HTML-001 구현 계획

> **TDD 구현 전략**: RED → GREEN → REFACTOR 사이클 기반

---

## 📋 구현 개요

### 목표
- DesignSpec JSON → HTML/CSS 변환 엔진 구현
- Figma 레이아웃 대비 ±2px 픽셀 정확도 달성
- Jinja2 템플릿 기반 10개 섹션 렌더링
- 15초 이내 HTML 생성 성능 보장

### 우선순위 기준
1. **1차 목표**: 기본 HTML 생성 (Original HTML만)
2. **2차 목표**: 픽셀 정확도 검증 (±2px)
3. **3차 목표**: 최적화 및 에러 핸들링

---

## Phase 1: 기본 HTML 생성 (TDD)

### 1.1 DesignSpec 데이터 모델 검증

**목표**: SPEC-FIGMA-001의 DesignSpec 모델 재사용 확인

**작업**:
- [ ] `src/models/design_spec.py` 확인
- [ ] `DesignSpec`, `Section` 클래스 존재 여부 검증
- [ ] Pydantic 검증 로직 확인 (10개 섹션, 1082px 너비)

**테스트**:
```python
# tests/test_design_spec.py
def test_design_spec_validation_10_sections():
    """DesignSpec은 정확히 10개 섹션을 요구해야 한다"""
    # Given: 9개 섹션만 포함된 데이터
    # When: DesignSpec 생성 시도
    # Then: ValidationError 발생

def test_design_spec_canvas_width_1082px():
    """캔버스 너비는 1082px이어야 한다"""
    # Given: 1080px 너비 데이터
    # When: DesignSpec 생성 시도
    # Then: ValidationError 발생
```

**완료 조건**:
- DesignSpec 모델이 존재하고, 10개 섹션 검증 로직이 작동함
- 테스트 커버리지 100% (모델 검증)

---

### 1.2 TemplateEngine 구현 (Jinja2 래퍼)

**목표**: Jinja2 템플릿 로드 및 렌더링 래퍼 클래스 구현

**작업**:
- [ ] `src/template_engine.py` 생성
- [ ] `TemplateEngine` 클래스 구현
  - `__init__(template_dir: str)`
  - `render(template_name: str, context: Dict) -> str`
  - `render_section(section_name: str, section: Section) -> str`
  - `_load_template(template_name: str) -> jinja2.Template`
- [ ] Jinja2 Environment 설정 (autoescape, trim_blocks)

**TDD 사이클**:

**RED**: 실패하는 테스트 작성
```python
# tests/test_template_engine.py
def test_template_engine_loads_base_template():
    """TemplateEngine은 base.html.jinja2를 로드해야 한다"""
    # Given: 템플릿 디렉토리 경로
    engine = TemplateEngine(template_dir="templates")

    # When: base.html.jinja2 렌더링 시도
    html = engine.render("base.html.jinja2", {})

    # Then: HTML 문자열 반환
    assert "<html>" in html

def test_template_engine_renders_section():
    """TemplateEngine은 섹션별 템플릿을 렌더링해야 한다"""
    # Given: Product Hero 섹션 데이터
    section = Section(id="1:159", name="Product Hero", ...)

    # When: product_hero.html.jinja2 렌더링
    html = engine.render_section("product_hero", section)

    # Then: 섹션 HTML 반환
    assert '<div class="section--product-hero">' in html

def test_template_engine_raises_error_if_template_not_found():
    """존재하지 않는 템플릿 요청 시 TemplateNotFoundError 발생"""
    # Given: 잘못된 템플릿명
    # When: 렌더링 시도
    # Then: TemplateNotFoundError 발생
```

**GREEN**: 최소 구현
```python
# src/template_engine.py
from jinja2 import Environment, FileSystemLoader, TemplateNotFoundError
from typing import Dict, Any

class TemplateEngine:
    def __init__(self, template_dir: str = "templates"):
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=True,
            trim_blocks=True,
            lstrip_blocks=True,
        )

    def render(self, template_name: str, context: Dict[str, Any]) -> str:
        template = self._load_template(template_name)
        return template.render(**context)

    def render_section(self, section_name: str, section: Section) -> str:
        template_name = f"sections/{section_name}.html.jinja2"
        context = {"section": section}
        return self.render(template_name, context)

    def _load_template(self, template_name: str) -> jinja2.Template:
        return self.env.get_template(template_name)
```

**REFACTOR**: 코드 품질 개선
- 타입 힌트 추가
- docstring 작성
- 에러 메시지 개선

**완료 조건**:
- 모든 테스트 통과 (3개)
- 커버리지 90% 이상
- mypy strict 모드 통과

---

### 1.3 LayoutRenderer 구현 (CSS 생성)

**목표**: Section 객체 → CSS absolute positioning 변환

**작업**:
- [ ] `src/layout_renderer.py` 생성
- [ ] `LayoutRenderer` 클래스 구현
  - `render_css(design_spec: DesignSpec) -> str`
  - `render_section_css(section: Section) -> str`
  - `_calculate_absolute_position(section: Section) -> Dict`

**TDD 사이클**:

**RED**: 실패하는 테스트 작성
```python
# tests/test_layout_renderer.py
def test_layout_renderer_generates_css_variables():
    """LayoutRenderer는 CSS 변수를 생성해야 한다"""
    # Given: DesignSpec 객체
    design_spec = DesignSpec(width=1082, height=25520, ...)

    # When: CSS 생성
    renderer = LayoutRenderer()
    css = renderer.render_css(design_spec)

    # Then: CSS 변수 포함
    assert "--canvas-width: 1082px;" in css
    assert "--canvas-height: 25520px;" in css

def test_layout_renderer_generates_section_css():
    """LayoutRenderer는 섹션별 absolute positioning CSS를 생성해야 한다"""
    # Given: Product Hero 섹션 (x=0, y=0, width=1033, height=1749)
    section = Section(id="1:159", name="Product Hero", x=0, y=0, width=1033, height=1749)

    # When: 섹션 CSS 생성
    css = renderer.render_section_css(section)

    # Then: position: absolute 스타일 포함
    assert "position: absolute;" in css
    assert "left: 0px;" in css
    assert "top: 0px;" in css
    assert "width: 1033px;" in css
    assert "height: 1749px;" in css

def test_layout_renderer_calculates_absolute_coords():
    """LayoutRenderer는 절대 좌표를 정확히 계산해야 한다"""
    # Given: 부모 좌표 포함된 섹션
    section = Section(x=24, y=100, width=1033, height=1749)

    # When: 절대 좌표 계산
    coords = renderer._calculate_absolute_position(section)

    # Then: 부모 좌표 누적
    assert coords["x"] == 24
    assert coords["y"] == 100
```

**GREEN**: 최소 구현
```python
# src/layout_renderer.py
from typing import Dict, Any

class LayoutRenderer:
    def __init__(self, pixel_tolerance: int = 2):
        self.pixel_tolerance = pixel_tolerance

    def render_css(self, design_spec: DesignSpec) -> str:
        css_lines = [":root {"]
        css_lines.append(f"  --canvas-width: {design_spec.width}px;")
        css_lines.append(f"  --canvas-height: {design_spec.height}px;")
        css_lines.append("}")

        for section in design_spec.sections:
            css_lines.append(self.render_section_css(section))

        return "\n".join(css_lines)

    def render_section_css(self, section: Section) -> str:
        css_class = f".section--{section.name.lower().replace(' ', '-')}"
        return f"""{css_class} {{
  position: absolute;
  left: {section.x}px;
  top: {section.y}px;
  width: {section.width}px;
  height: {section.height}px;
}}"""

    def _calculate_absolute_position(self, section: Section) -> Dict[str, int]:
        return {
            "x": section.x,
            "y": section.y,
            "width": section.width,
            "height": section.height,
        }
```

**REFACTOR**: 코드 품질 개선
- CSS 템플릿 분리 (문자열 대신 템플릿 사용)
- 네이밍 일관성 (snake_case → kebab-case)

**완료 조건**:
- 모든 테스트 통과 (3개)
- 커버리지 90% 이상
- CSS 문법 검증 (생성된 CSS가 유효함)

---

### 1.4 HTMLGenerator 구현 (오케스트레이션)

**목표**: TemplateEngine + LayoutRenderer 통합, HTML 생성

**작업**:
- [ ] `src/html_generator.py` 생성
- [ ] `HTMLGenerator` 클래스 구현
  - `generate(design_spec: DesignSpec) -> str`
  - `validate_spec(design_spec: DesignSpec) -> bool`
  - `_render_sections(design_spec: DesignSpec) -> List[str]`
  - `_generate_css(design_spec: DesignSpec) -> str`
  - `_save_html(html: str, filename: str) -> str`

**TDD 사이클**:

**RED**: 실패하는 테스트 작성
```python
# tests/test_html_generator.py
def test_html_generator_validates_design_spec():
    """HTMLGenerator는 DesignSpec 유효성을 검증해야 한다"""
    # Given: 잘못된 DesignSpec (9개 섹션)
    invalid_spec = DesignSpec(sections=[...])  # 9개

    # When: HTML 생성 시도
    generator = HTMLGenerator()

    # Then: ValidationError 발생
    with pytest.raises(ValidationError):
        generator.validate_spec(invalid_spec)

def test_html_generator_renders_10_sections():
    """HTMLGenerator는 10개 섹션을 순서대로 렌더링해야 한다"""
    # Given: 유효한 DesignSpec (10개 섹션)
    design_spec = create_valid_design_spec()

    # When: 섹션 렌더링
    generator = HTMLGenerator(template_engine, layout_renderer)
    sections_html = generator._render_sections(design_spec)

    # Then: 10개 섹션 HTML 반환
    assert len(sections_html) == 10
    assert '<div class="section--product-hero">' in sections_html[0]

def test_html_generator_generates_complete_html():
    """HTMLGenerator는 완전한 HTML 파일을 생성해야 한다"""
    # Given: 유효한 DesignSpec
    design_spec = create_valid_design_spec()

    # When: HTML 생성
    output_path = generator.generate(design_spec)

    # Then: HTML 파일 저장 확인
    assert Path(output_path).exists()
    html_content = Path(output_path).read_text()
    assert "<html>" in html_content
    assert "Pretendard" in html_content  # 웹폰트 확인

def test_html_generator_raises_error_if_canvas_width_invalid():
    """캔버스 너비가 1082px가 아니면 ValidationError 발생"""
    # Given: 잘못된 캔버스 너비 (1080px)
    design_spec = DesignSpec(width=1080, ...)

    # When: 검증 시도
    # Then: ValidationError 발생
    with pytest.raises(ValidationError, match="Invalid canvas width"):
        generator.validate_spec(design_spec)
```

**GREEN**: 최소 구현
```python
# src/html_generator.py
from pathlib import Path
from typing import List

class HTMLGenerator:
    def __init__(
        self,
        template_engine: TemplateEngine,
        layout_renderer: LayoutRenderer,
        output_dir: str = "output",
    ):
        self.template_engine = template_engine
        self.layout_renderer = layout_renderer
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)

    def generate(self, design_spec: DesignSpec) -> str:
        self.validate_spec(design_spec)

        sections_html = self._render_sections(design_spec)
        css = self._generate_css(design_spec)

        context = {
            "canvas_width": design_spec.width,
            "canvas_height": design_spec.height,
            "css": css,
            "sections": sections_html,
            "font_family": "Pretendard",
        }

        html = self.template_engine.render("base.html.jinja2", context)
        return self._save_html(html)

    def validate_spec(self, design_spec: DesignSpec) -> bool:
        if len(design_spec.sections) != 10:
            raise ValidationError(f"Expected 10 sections, got {len(design_spec.sections)}")

        if design_spec.width != 1082:
            raise ValidationError(f"Invalid canvas width: {design_spec.width}px (expected: 1082px)")

        return True

    def _render_sections(self, design_spec: DesignSpec) -> List[str]:
        sections_html = []
        for i, section in enumerate(design_spec.sections, start=1):
            logger.info(f"Rendering section {i}/10: {section.name}")
            section_name = section.name.lower().replace(" ", "_")
            html = self.template_engine.render_section(section_name, section)
            sections_html.append(html)
        return sections_html

    def _generate_css(self, design_spec: DesignSpec) -> str:
        return self.layout_renderer.render_css(design_spec)

    def _save_html(self, html: str, filename: str = "original.html") -> str:
        output_path = self.output_dir / filename
        output_path.write_text(html, encoding="utf-8")
        logger.info(f"HTML saved: {output_path}")
        return str(output_path)
```

**REFACTOR**: 코드 품질 개선
- 진행률 로깅 추가 (Rich 프로그레스 바)
- 파일 크기 검증 추가 (30MB 제한)
- 타임아웃 처리 추가 (15초 제한)

**완료 조건**:
- 모든 테스트 통과 (4개)
- 통합 테스트 성공 (실제 HTML 생성)
- 커버리지 85% 이상

---

### 1.5 Jinja2 템플릿 작성

**목표**: 10개 섹션별 템플릿 파일 생성

**작업**:
- [ ] `templates/base.html.jinja2` 작성
- [ ] `templates/sections/` 디렉토리 생성
- [ ] 10개 섹션 템플릿 작성:
  - `product_hero.html.jinja2`
  - `color_variants.html.jinja2`
  - `lifestyle_gallery.html.jinja2`
  - `material_detail.html.jinja2`
  - `color_selector.html.jinja2`
  - `product_info.html.jinja2`
  - `care_instructions.html.jinja2`
  - `model_info.html.jinja2`
  - `size_guide.html.jinja2`
  - `size_chart.html.jinja2`
- [ ] CSS 리셋 파일 작성 (`templates/styles/reset.css`)

**base.html.jinja2 구조**:
```html
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{{ product_name | default("Product Detail Page") }}</title>

  <!-- Pretendard 웹폰트 로드 -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Pretendard:wght@300;400&display=swap" rel="stylesheet">

  <style>
    /* CSS 리셋 */
    {{ reset_css }}

    /* 레이아웃 CSS */
    {{ css }}
  </style>
</head>
<body>
  <div class="canvas" style="width: {{ canvas_width }}px; height: {{ canvas_height }}px; position: relative;">
    {% for section_html in sections %}
      {{ section_html | safe }}
    {% endfor %}
  </div>
</body>
</html>
```

**섹션 템플릿 예시 (product_hero.html.jinja2)**:
```html
<div class="section section--product-hero" data-section-id="{{ section.id }}">
  <!-- 섹션 내용: 이미지, 타이틀 등 -->
  {% if debug_mode %}
    <!-- 디버그 정보 -->
    <!--
      Section: {{ section.name }}
      Figma Group: {{ section.figma_group }}
      Position: ({{ section.x }}, {{ section.y }})
      Size: {{ section.width }}×{{ section.height }}
    -->
  {% endif %}
</div>
```

**완료 조건**:
- 11개 템플릿 파일 생성 (base + 10개 섹션)
- HTML 문법 검증 통과
- Jinja2 렌더링 에러 없음

---

## Phase 2: 픽셀 정확도 검증 (±2px)

### 2.1 LayoutRenderer 검증 로직 추가

**목표**: Figma 좌표 vs HTML 렌더링 좌표 비교

**작업**:
- [ ] `LayoutRenderer.validate_layout(section: Section)` 메서드 구현
- [ ] 오차 계산 로직 (diff_x, diff_y, max_diff)
- [ ] ±2px 임계값 검증

**TDD 사이클**:

**RED**: 실패하는 테스트 작성
```python
# tests/test_layout_renderer.py (추가)
def test_layout_renderer_validates_pixel_accuracy():
    """LayoutRenderer는 ±2px 이내 정확도를 검증해야 한다"""
    # Given: 정확한 섹션 (오차 0px)
    section = Section(x=0, y=0, width=1033, height=1749)

    # When: 검증 수행
    error_report = renderer.validate_layout(section)

    # Then: 오차 없음
    assert error_report is None

def test_layout_renderer_detects_layout_error_exceeding_2px():
    """LayoutRenderer는 2px 초과 오차를 감지해야 한다"""
    # Given: 3px 오차 섹션
    section = Section(x=0, y=3, ...)  # 3px 오차 시뮬레이션

    # When: 검증 수행
    error_report = renderer.validate_layout(section)

    # Then: 오차 리포트 반환
    assert error_report is not None
    assert error_report["diff"] == 3
    assert error_report["exceeds_tolerance"] is True
```

**GREEN**: 최소 구현
```python
# src/layout_renderer.py (추가)
def validate_layout(self, section: Section) -> Optional[Dict[str, Any]]:
    expected = {"x": section.x, "y": section.y}
    actual = self._calculate_absolute_position(section)

    diff_x = abs(expected["x"] - actual["x"])
    diff_y = abs(expected["y"] - actual["y"])
    max_diff = max(diff_x, diff_y)

    if max_diff > self.pixel_tolerance:
        return {
            "section": section.name,
            "expected": expected,
            "actual": actual,
            "diff": max_diff,
            "exceeds_tolerance": True,
        }
    return None
```

**완료 조건**:
- 테스트 통과 (2개 추가)
- 오차 계산 로직 검증

---

### 2.2 HTMLGenerator 오차 리포트 생성

**목표**: 레이아웃 오차 발견 시 JSON 리포트 저장

**작업**:
- [ ] `HTMLGenerator._validate_layout_accuracy()` 메서드 추가
- [ ] 오차 리포트 수집 (List[Dict])
- [ ] JSON 파일 저장 (`output/layout_error_report.json`)

**TDD 사이클**:

**RED**: 실패하는 테스트 작성
```python
# tests/test_html_generator.py (추가)
def test_html_generator_generates_layout_error_report():
    """HTMLGenerator는 레이아웃 오차 발견 시 리포트를 생성해야 한다"""
    # Given: 3px 오차 포함 DesignSpec
    design_spec = create_design_spec_with_layout_error()

    # When: HTML 생성
    generator.generate(design_spec)

    # Then: 오차 리포트 파일 생성
    report_path = Path("output/layout_error_report.json")
    assert report_path.exists()

    report = json.loads(report_path.read_text())
    assert len(report) == 1
    assert report[0]["diff"] == 3

def test_html_generator_logs_warning_on_layout_error():
    """HTMLGenerator는 레이아웃 오차 발견 시 경고 로그를 남겨야 한다"""
    # Given: 3px 오차 포함 DesignSpec
    # When: HTML 생성
    # Then: WARNING 로그 기록 확인 (caplog 사용)
```

**GREEN**: 최소 구현
```python
# src/html_generator.py (추가)
def generate(self, design_spec: DesignSpec) -> str:
    self.validate_spec(design_spec)

    sections_html = self._render_sections(design_spec)
    css = self._generate_css(design_spec)

    # 레이아웃 검증 추가
    layout_errors = self._validate_layout_accuracy(design_spec)
    if layout_errors:
        self._save_layout_error_report(layout_errors)

    # ... (이하 동일)

def _validate_layout_accuracy(self, design_spec: DesignSpec) -> List[Dict[str, Any]]:
    errors = []
    for section in design_spec.sections:
        error = self.layout_renderer.validate_layout(section)
        if error:
            logger.warning(f"Layout accuracy: {error['diff']}px exceeds tolerance (2px)")
            errors.append(error)
    return errors

def _save_layout_error_report(self, errors: List[Dict[str, Any]]) -> None:
    report_path = self.output_dir / "layout_error_report.json"
    report_path.write_text(json.dumps(errors, indent=2))
    logger.info(f"Layout error report saved: {report_path}")
```

**완료 조건**:
- 테스트 통과 (2개 추가)
- JSON 리포트 생성 확인

---

## Phase 3: 최적화 및 문서화

### 3.1 성능 최적화

**목표**: HTML 생성 시간 15초 이내 달성

**작업**:
- [ ] 성능 프로파일링 (`cProfile` 또는 `py-spy`)
- [ ] 병목 지점 식별 (템플릿 렌더링, CSS 생성)
- [ ] 캐싱 추가 (템플릿 캐싱, CSS 캐싱)

**측정 방법**:
```python
import time

start_time = time.time()
generator.generate(design_spec)
elapsed = time.time() - start_time

assert elapsed < 15, f"HTML generation took {elapsed}s (expected < 15s)"
```

**최적화 전략**:
1. Jinja2 템플릿 컴파일 캐싱 (Environment 재사용)
2. CSS 생성 병렬화 (섹션별 독립적)
3. 파일 I/O 최소화 (메모리 버퍼 사용)

**완료 조건**:
- 생성 시간 15초 이내
- 성능 테스트 추가

---

### 3.2 에러 핸들링 강화

**목표**: 모든 예외 케이스 처리 및 사용자 친화적 에러 메시지

**작업**:
- [ ] 커스텀 예외 클래스 정의 (`ValidationError`, `TemplateError`, `LayoutError`)
- [ ] 에러 메시지 개선 (구체적인 원인 제시)
- [ ] 로깅 레벨 조정 (DEBUG, INFO, WARNING, ERROR)

**에러 시나리오**:
1. DesignSpec 검증 실패 → ValidationError + 상세 메시지
2. 템플릿 파일 없음 → TemplateError + 템플릿명
3. 레이아웃 오차 초과 → LayoutError (경고) + 오차 리포트
4. 파일 크기 초과 → FileSizeError (경고) + 실제 크기

**완료 조건**:
- 모든 에러 시나리오 테스트
- 커버리지 85% 이상

---

### 3.3 @DOC:HTML-001 문서화

**목표**: HTML Generator 사용 가이드 및 API 문서 작성

**작업**:
- [ ] `docs/html-generation.md` 작성
- [ ] API 문서 (클래스/메서드 설명)
- [ ] 사용 예시 (코드 스니펫)
- [ ] 트러블슈팅 가이드

**문서 구조**:
```markdown
# HTML Generator 사용 가이드

## 개요
- HTML Generator의 역할 및 아키텍처

## 설치
- 의존성 설치 (Poetry)

## 사용법
- 기본 사용 예시
- DesignSpec → HTML 생성

## API 레퍼런스
- HTMLGenerator 클래스
- TemplateEngine 클래스
- LayoutRenderer 클래스

## 트러블슈팅
- 레이아웃 오차 해결 방법
- 템플릿 오류 디버깅
```

**완료 조건**:
- 문서 작성 완료 (1000단어 이상)
- 코드 예시 검증 (실행 가능)

---

## 기술적 접근 방법

### 아키텍처 설계 방향

**3계층 구조**:
```
HTMLGenerator (오케스트레이션)
    ├─ TemplateEngine (Jinja2 래퍼)
    └─ LayoutRenderer (CSS 생성)
```

**의존성 주입**:
- HTMLGenerator는 TemplateEngine, LayoutRenderer를 생성자 주입받음
- 테스트 시 Mock 객체 주입 가능

**단방향 데이터 흐름**:
```
DesignSpec → HTMLGenerator → [TemplateEngine, LayoutRenderer] → HTML 파일
```

---

### 리스크 및 대응 방안

#### 리스크 1: Jinja2 템플릿 렌더링 성능
- **영향**: 10개 섹션 렌더링 시간 증가
- **완화**: 템플릿 컴파일 캐싱, 템플릿 단순화
- **대응**: 병렬 렌더링 (asyncio) - Phase 2+

#### 리스크 2: 레이아웃 오차 정확도
- **영향**: Figma vs HTML 좌표 차이
- **완화**: CSS absolute positioning 사용, 브라우저 렌더링 차이 최소화
- **대응**: 브라우저 스크린샷 비교 도구 (Phase 3)

#### 리스크 3: HTML 파일 크기
- **영향**: Base64 이미지 임베딩 시 30MB 초과
- **완화**: 이미지 압축 (Image Encoder), 크기 제한 경고
- **대응**: CDN 업로드 옵션 (Phase 3)

---

## 다음 단계 안내

### Phase 1 완료 후
- **검증**: `/alfred:3-sync`로 TAG 체인 무결성 확인
- **다음 SPEC**: `SPEC-SHEETS-001` (Google Sheets 데이터 로더) 또는 `SPEC-IMAGE-001` (Image Encoder)

### Phase 2 완료 후
- **검증**: 픽셀 정확도 자동 테스트 실행
- **문서화**: 오차 리포트 가이드 작성

### Phase 3 완료 후
- **배포**: Living Document 업데이트 (`/alfred:3-sync`)
- **PR 생성**: `feature/SPEC-HTML-001` → `develop` (Team 모드)

---

_이 계획서는 `/alfred:2-build SPEC-HTML-001` 실행 시 TDD 구현의 가이드라인입니다._
