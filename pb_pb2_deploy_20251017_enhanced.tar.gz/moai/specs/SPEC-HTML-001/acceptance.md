# @SPEC:HTML-001 수락 기준

> **Given-When-Then 형식의 상세한 테스트 시나리오**

---

## 📋 수락 기준 개요

### 검증 범위
- DesignSpec → HTML 변환 정확성
- Figma 레이아웃 재현 정확도 (±2px)
- 10개 섹션 렌더링 완전성
- 성능 기준 (15초 이내)
- 에러 핸들링 견고성

### 검증 방법
- 자동화된 pytest 테스트
- 수동 브라우저 렌더링 확인
- 성능 프로파일링
- 레이아웃 오차 리포트 분석

---

## Scenario 1: 픽셀 퍼펙트 HTML 생성

### 시나리오 설명
DesignSpec JSON을 입력받아 Figma 디자인과 ±2px 이내로 일치하는 HTML을 생성한다.

### Given (전제 조건)
- DesignSpec JSON이 유효하다:
  - 캔버스 크기: 1082px × 25520px
  - 섹션 개수: 10개
  - 각 섹션에 id, name, x, y, width, height 필드 존재
- `templates/` 디렉토리에 11개 템플릿 파일 존재 (base + 10개 섹션)
- `output/` 디렉토리가 쓰기 가능

### When (실행 조건)
```python
from src.html_generator import HTMLGenerator
from src.models.design_spec import DesignSpec

# DesignSpec 로드
design_spec = DesignSpec.parse_file("tests/fixtures/valid_design_spec.json")

# HTML Generator 초기화
generator = HTMLGenerator(
    template_engine=TemplateEngine(),
    layout_renderer=LayoutRenderer(pixel_tolerance=2),
    output_dir="output"
)

# HTML 생성
output_path = generator.generate(design_spec)
```

### Then (기대 결과)

#### 1. HTML 파일 생성 확인
```python
def test_html_file_created():
    """HTML 파일이 output/ 디렉토리에 생성되어야 한다"""
    assert Path(output_path).exists()
    assert output_path == "output/original.html"
```

#### 2. HTML 구조 검증
```python
def test_html_structure():
    """생성된 HTML이 올바른 구조를 가져야 한다"""
    html_content = Path(output_path).read_text()

    # 기본 HTML 구조
    assert "<!DOCTYPE html>" in html_content
    assert "<html lang=\"ko\">" in html_content
    assert "<head>" in html_content
    assert "<body>" in html_content

    # 캔버스 div
    assert '<div class="canvas"' in html_content
    assert 'width: 1082px' in html_content
    assert 'height: 25520px' in html_content
```

#### 3. Pretendard 웹폰트 로드 확인
```python
def test_pretendard_font_loaded():
    """Pretendard 웹폰트가 로드되어야 한다"""
    html_content = Path(output_path).read_text()

    assert "https://fonts.googleapis.com/css2?family=Pretendard" in html_content
    assert "font-family: 'Pretendard'" in html_content
```

#### 4. 10개 섹션 렌더링 확인
```python
def test_all_sections_rendered():
    """10개 섹션이 모두 렌더링되어야 한다"""
    html_content = Path(output_path).read_text()

    expected_sections = [
        "section--product-hero",
        "section--color-variants",
        "section--lifestyle-gallery",
        "section--material-detail",
        "section--color-selector",
        "section--product-info",
        "section--care-instructions",
        "section--model-info",
        "section--size-guide",
        "section--size-chart",
    ]

    for section_class in expected_sections:
        assert f'class="{section_class}"' in html_content
```

#### 5. 픽셀 정확도 검증 (±2px)
```python
def test_pixel_accuracy():
    """각 섹션이 ±2px 이내 정확도로 배치되어야 한다"""
    html_content = Path(output_path).read_text()

    # Product Hero 섹션 CSS 검증 (예시)
    assert "left: 0px;" in html_content  # x=0 (허용 범위: -2~2px)
    assert "top: 0px;" in html_content   # y=0 (허용 범위: -2~2px)
    assert "width: 1033px;" in html_content  # 정확히 1033px
    assert "height: 1749px;" in html_content  # 정확히 1749px

    # 레이아웃 오차 리포트 없음 확인
    report_path = Path("output/layout_error_report.json")
    assert not report_path.exists()  # 오차 없으면 리포트 생성 안 됨
```

#### 6. 생성 시간 검증 (15초 이내)
```python
def test_generation_time():
    """HTML 생성 시간이 15초를 초과하지 않아야 한다"""
    import time

    start_time = time.time()
    generator.generate(design_spec)
    elapsed = time.time() - start_time

    assert elapsed < 15, f"Generation took {elapsed:.2f}s (expected < 15s)"
```

#### 7. 파일 크기 검증 (30MB 이하)
```python
def test_file_size():
    """생성된 HTML 파일 크기가 30MB를 초과하지 않아야 한다"""
    file_size_mb = Path(output_path).stat().st_size / (1024 * 1024)
    assert file_size_mb <= 30, f"HTML file size: {file_size_mb:.2f}MB (expected ≤ 30MB)"
```

---

## Scenario 2: 레이아웃 오차 검증

### 시나리오 설명
Figma 좌표와 HTML 렌더링 좌표 간 오차가 ±2px를 초과하면 경고 로그와 오차 리포트를 생성한다.

### Given (전제 조건)
- DesignSpec JSON에 3px 오차가 있는 섹션 포함:
  ```json
  {
    "id": "1:159",
    "name": "Product Hero",
    "x": 0,
    "y": 3,  // 3px 오차 시뮬레이션
    "width": 1033,
    "height": 1749
  }
  ```
- LayoutRenderer의 pixel_tolerance=2

### When (실행 조건)
```python
design_spec = DesignSpec.parse_file("tests/fixtures/design_spec_with_layout_error.json")
generator = HTMLGenerator(layout_renderer=LayoutRenderer(pixel_tolerance=2))

with pytest.warns(UserWarning):
    output_path = generator.generate(design_spec)
```

### Then (기대 결과)

#### 1. 경고 로그 기록
```python
def test_layout_error_logged(caplog):
    """레이아웃 오차 발견 시 WARNING 로그가 기록되어야 한다"""
    with caplog.at_level(logging.WARNING):
        generator.generate(design_spec)

    assert "Layout accuracy: 3px exceeds tolerance (2px)" in caplog.text
```

#### 2. 오차 리포트 생성
```python
def test_layout_error_report_generated():
    """오차 리포트 JSON 파일이 생성되어야 한다"""
    generator.generate(design_spec)

    report_path = Path("output/layout_error_report.json")
    assert report_path.exists()

    report = json.loads(report_path.read_text())
    assert len(report) == 1
    assert report[0]["section"] == "Product Hero"
    assert report[0]["diff"] == 3
    assert report[0]["exceeds_tolerance"] is True
```

#### 3. HTML 생성은 계속
```python
def test_html_generated_despite_layout_error():
    """레이아웃 오차가 있어도 HTML은 생성되어야 한다 (경고만)"""
    output_path = generator.generate(design_spec)
    assert Path(output_path).exists()
```

---

## Scenario 3: DesignSpec 검증 실패

### 시나리오 설명
DesignSpec JSON이 잘못되면 ValidationError를 발생시키고 HTML 생성을 중단한다.

### Given (전제 조건)
- DesignSpec JSON에 필수 필드 누락 또는 잘못된 값:
  - 케이스 1: 섹션 개수 9개 (필수 10개)
  - 케이스 2: 캔버스 너비 1080px (필수 1082px)
  - 케이스 3: 필수 섹션 "Product Hero" 누락

### When & Then (실행 및 기대 결과)

#### 케이스 1: 섹션 개수 불일치
```python
def test_validation_error_on_missing_section():
    """섹션이 9개이면 ValidationError가 발생해야 한다"""
    # Given: 9개 섹션 DesignSpec
    design_spec = DesignSpec(
        width=1082,
        height=25520,
        sections=[...]  # 9개
    )

    # When: HTML 생성 시도
    generator = HTMLGenerator()

    # Then: ValidationError 발생
    with pytest.raises(ValidationError, match="Expected 10 sections, got 9"):
        generator.generate(design_spec)
```

#### 케이스 2: 캔버스 너비 불일치
```python
def test_validation_error_on_invalid_canvas_width():
    """캔버스 너비가 1082px가 아니면 ValidationError가 발생해야 한다"""
    # Given: 1080px 너비 DesignSpec
    design_spec = DesignSpec(width=1080, height=25520, sections=[...])

    # When: HTML 생성 시도
    # Then: ValidationError 발생
    with pytest.raises(ValidationError, match="Invalid canvas width: 1080px"):
        generator.generate(design_spec)
```

#### 케이스 3: 필수 섹션 누락
```python
def test_validation_error_on_missing_required_section():
    """필수 섹션이 누락되면 ValidationError가 발생해야 한다"""
    # Given: "Product Hero" 섹션 없는 DesignSpec
    design_spec = DesignSpec(
        width=1082,
        height=25520,
        sections=[
            Section(name="Color Variants", ...),
            # Product Hero 누락
            ...
        ]
    )

    # When: HTML 생성 시도
    # Then: ValidationError 발생
    with pytest.raises(ValidationError, match="Missing required section: Product Hero"):
        generator.validate_spec(design_spec)
```

---

## Scenario 4: 템플릿 렌더링 에러 처리

### 시나리오 설명
Jinja2 템플릿 파일이 없거나 문법 오류가 있으면 TemplateError를 발생시킨다.

### Given (전제 조건)
- 케이스 1: `templates/sections/product_hero.html.jinja2` 파일 없음
- 케이스 2: 템플릿에 Jinja2 문법 오류 (`{{ section.name }` 괄호 누락)

### When & Then (실행 및 기대 결과)

#### 케이스 1: 템플릿 파일 없음
```python
def test_template_not_found_error():
    """템플릿 파일이 없으면 TemplateError가 발생해야 한다"""
    # Given: product_hero.html.jinja2 삭제
    template_path = Path("templates/sections/product_hero.html.jinja2")
    template_path.unlink()

    # When: HTML 생성 시도
    generator = HTMLGenerator()

    # Then: TemplateError 발생
    with pytest.raises(TemplateError, match="Template not found: sections/product_hero.html.jinja2"):
        generator.generate(design_spec)
```

#### 케이스 2: 템플릿 문법 오류
```python
def test_template_syntax_error():
    """템플릿 문법 오류가 있으면 TemplateError가 발생해야 한다"""
    # Given: 잘못된 Jinja2 문법 템플릿
    template_path = Path("templates/sections/test_section.html.jinja2")
    template_path.write_text("{{ section.name }")  # 괄호 누락

    # When: 렌더링 시도
    engine = TemplateEngine()

    # Then: TemplateError 발생
    with pytest.raises(TemplateError, match="Syntax error in template"):
        engine.render("sections/test_section.html.jinja2", {})
```

---

## Scenario 5: 디버그 모드 활성화

### 시나리오 설명
DEBUG=true 환경 변수 설정 시 각 섹션에 디버그 정보(ID, 좌표, 크기)를 HTML 주석으로 표시한다.

### Given (전제 조건)
- 환경 변수 `DEBUG=true` 설정
- DesignSpec JSON 유효

### When (실행 조건)
```python
import os
os.environ["DEBUG"] = "true"

generator = HTMLGenerator()
output_path = generator.generate(design_spec)
```

### Then (기대 결과)

#### 1. 디버그 정보 포함 확인
```python
def test_debug_info_included_when_debug_mode():
    """DEBUG=true일 때 HTML 주석에 디버그 정보가 포함되어야 한다"""
    os.environ["DEBUG"] = "true"
    generator = HTMLGenerator()
    output_path = generator.generate(design_spec)

    html_content = Path(output_path).read_text()

    # Product Hero 섹션 디버그 정보
    assert "<!-- Section: Product Hero -->" in html_content
    assert "<!-- Figma Group: Group 10 (1:159) -->" in html_content
    assert "<!-- Position: (0, 0) -->" in html_content
    assert "<!-- Size: 1033×1749 -->" in html_content
```

#### 2. 디버그 모드 비활성화 시 정보 없음
```python
def test_no_debug_info_when_debug_mode_off():
    """DEBUG=false일 때 디버그 정보가 없어야 한다"""
    os.environ["DEBUG"] = "false"
    generator = HTMLGenerator()
    output_path = generator.generate(design_spec)

    html_content = Path(output_path).read_text()
    assert "<!-- Section:" not in html_content
```

---

## Scenario 6: 성능 기준 검증

### 시나리오 설명
HTML 생성 시간이 15초를 초과하지 않고, 파일 크기가 30MB를 넘지 않는다.

### Given (전제 조건)
- DesignSpec JSON 유효 (10개 섹션)
- Base64 이미지 데이터 포함 (Image Encoder에서 제공)

### When (실행 조건)
```python
import time

start_time = time.time()
output_path = generator.generate(design_spec)
elapsed = time.time() - start_time
```

### Then (기대 결과)

#### 1. 생성 시간 15초 이내
```python
def test_generation_time_under_15_seconds():
    """HTML 생성 시간이 15초를 초과하지 않아야 한다"""
    assert elapsed < 15, f"Generation took {elapsed:.2f}s (expected < 15s)"
```

#### 2. 파일 크기 30MB 이하
```python
def test_file_size_under_30mb():
    """HTML 파일 크기가 30MB를 초과하지 않아야 한다"""
    file_size_mb = Path(output_path).stat().st_size / (1024 * 1024)
    assert file_size_mb <= 30, f"File size: {file_size_mb:.2f}MB (expected ≤ 30MB)"
```

#### 3. 파일 크기 초과 시 경고 로그
```python
def test_warning_logged_when_file_size_exceeds_30mb(caplog):
    """파일 크기가 30MB를 초과하면 WARNING 로그가 기록되어야 한다"""
    # Given: 35MB HTML (시뮬레이션)
    large_design_spec = create_large_design_spec()

    with caplog.at_level(logging.WARNING):
        generator.generate(large_design_spec)

    assert "HTML file size exceeds 30MB: 35.0MB" in caplog.text
```

---

## Scenario 7: 웹폰트 로드 실패 폴백

### 시나리오 설명
Pretendard 웹폰트 로드 실패 시 시스템 폰트로 폴백하고 경고 로그를 남긴다.

### Given (전제 조건)
- 네트워크 오류 또는 Google Fonts CDN 장애 시뮬레이션
- DesignSpec JSON 유효

### When (실행 조건)
```python
# 네트워크 오프라인 시뮬레이션 (Mock)
with mock.patch("requests.get", side_effect=requests.ConnectionError):
    output_path = generator.generate(design_spec)
```

### Then (기대 결과)

#### 1. 시스템 폰트로 폴백
```python
def test_fallback_to_system_font_on_webfont_failure():
    """웹폰트 로드 실패 시 시스템 폰트로 폴백해야 한다"""
    html_content = Path(output_path).read_text()

    # 폴백 체인 포함 확인
    assert "font-family: 'Pretendard', -apple-system, BlinkMacSystemFont" in html_content
```

#### 2. 경고 로그 기록
```python
def test_warning_logged_on_webfont_failure(caplog):
    """웹폰트 로드 실패 시 WARNING 로그가 기록되어야 한다"""
    with caplog.at_level(logging.WARNING):
        with mock.patch("requests.get", side_effect=requests.ConnectionError):
            generator.generate(design_spec)

    assert "Web font load failed, using fallback fonts" in caplog.text
```

---

## 품질 게이트 기준 (Definition of Done)

### 기능 완성도
- ✅ 10개 섹션이 모두 렌더링됨
- ✅ Pretendard 웹폰트가 로드됨
- ✅ ±2px 이내 픽셀 정확도 달성
- ✅ 15초 이내 HTML 생성 시간
- ✅ 30MB 이하 파일 크기

### 테스트 커버리지
- ✅ 단위 테스트 커버리지 85% 이상
- ✅ 통합 테스트 5개 이상
- ✅ 에러 시나리오 테스트 3개 이상

### 코드 품질
- ✅ ruff 린팅 통과 (0개 에러)
- ✅ mypy 타입 체크 통과 (strict 모드)
- ✅ 함수 50 LOC 이하, 파일 300 LOC 이하
- ✅ 복잡도 10 이하 (Cyclomatic Complexity)

### 문서화
- ✅ @TAG 주석 추가 (SPEC → TEST → CODE)
- ✅ docstring 작성 (모든 public 메서드)
- ✅ API 문서 작성 (`docs/html-generation.md`)
- ✅ 트러블슈팅 가이드 작성

### 성능
- ✅ 생성 시간 프로파일링 완료
- ✅ 메모리 사용량 500MB 이하
- ✅ 병목 지점 최적화 완료

---

## 수동 검증 체크리스트

### 브라우저 렌더링 확인
- [ ] 크롬 브라우저에서 `output/original.html` 열기
- [ ] 캔버스 크기 1082px × 25520px 확인 (개발자 도구)
- [ ] 10개 섹션이 순서대로 렌더링 확인
- [ ] Pretendard 폰트 적용 확인 (개발자 도구 → Computed → font-family)
- [ ] 레이아웃 오차 시각 확인 (Figma 디자인과 비교)

### 파일 시스템 확인
- [ ] `output/original.html` 파일 존재 확인
- [ ] 파일 크기 확인 (`ls -lh output/original.html`)
- [ ] 레이아웃 오차 리포트 확인 (`output/layout_error_report.json` - 오차 있을 경우)

### 로그 확인
- [ ] INFO 로그: "Rendering section X/10: {section_name}"
- [ ] WARNING 로그: "Layout accuracy: Xpx exceeds tolerance (2px)" (오차 있을 경우)
- [ ] ERROR 로그: 없음 (정상 케이스)

---

## 실패 조건 (자동 빌드 차단)

### Critical Failures (빌드 실패)
- ❌ DesignSpec 검증 실패 (ValidationError)
- ❌ 템플릿 파일 없음 (TemplateError)
- ❌ 테스트 커버리지 85% 미만
- ❌ mypy 타입 에러 (strict 모드)
- ❌ 생성 시간 15초 초과

### Warning (빌드 성공, 경고)
- ⚠️ 레이아웃 오차 ±2px 초과 (LayoutError)
- ⚠️ 파일 크기 30MB 초과 (FileSizeError)
- ⚠️ 웹폰트 로드 실패 (폴백 사용)

---

_이 수락 기준은 `/alfred:2-build SPEC-HTML-001` 실행 시 TDD 구현의 검증 기준입니다._
